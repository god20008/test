/*****************************************************************************
 *               Copyright Generalplus Corp. All Rights Reserved.      
 *                                                                     
 * FileName:       gplib_calendar.c
 * Author:         Lichuanyue  
 * Description:    Created
 * Version:        1.0 
 * Function List:  
 *                 Null
 * History:        
 *                 1>. 2008/07/02 Created
 *****************************************************************************/

#ifndef __GPLIB_GRAPHIC_CALENDAR_H__
#define __GPLIB_GRAPHIC_CALENDAR_H__

#include "gplib.h"


#endif

