/*
* Purpose: XDC interface of File system 
*
* Author:
*
* Date: 2008/4/19
*
* Copyright Generalplus Corp. ALL RIGHTS RESERVED.
*
* Version : 1.00
*
* History:
        0  V1.00 :
*/

#include "fsystem.h"

//=== This is for code configuration DON'T REMOVE or MODIFY it ===//

//================================================================//