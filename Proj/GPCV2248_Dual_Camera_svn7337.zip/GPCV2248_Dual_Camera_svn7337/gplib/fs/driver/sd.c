#define CREAT_DRIVERLAYER_STRUCT

#include "fsystem.h"

//=== This is for code configuration DON'T REMOVE or MODIFY it ===//
#if (defined SD_EN) && (SD_EN == 1)                               //
//================================================================//

#define FS_CACHE_DBG_EN         0
#define FS_FLUSH_CAHCE_EN       1
#define FS_INFO_CACHE           1
#define DIR_INFO_CACHE			1  //add by wwj
#define FAT_WRITE_TBL_ID        0  //0: FATTbl0->FATTbl1, 1: FATTbl1->FATTbl0
#define FS_TBL_MIRROR_SYNC      0

#if FAT_WRITE_TBL_ID == 0
  #define FAT_MAIN_TBL_ID         0
  #define FAT_SECOND_TBL_ID       1
#elif FAT_WRITE_TBL_ID == 1
  #define FAT_MAIN_TBL_ID         1
  #define FAT_SECOND_TBL_ID       0
  #define FS_TBL_MIRROR_SYNC      1  // when FAT2->1 Mirror table must be enable
#endif

//--------------------------------------------------
#if DIR_INFO_CACHE

extern INT32S start_sector_of_root;
extern INT32S start_sector_of_dcim;
extern INT32S start_sector_of_dcima;
extern INT32S start_sector_of_dcimb;

INT8U dir_loaded_flag = 0;
INT8U dcima_dirty_flag = 0;
INT8U dcimb_dirty_flag = 0;

#define ROOT_CACHE_BYTE_SIZE   512
#define DCIM_CACHE_BYTE_SIZE   512
#define DCIMA_CACHE_BYTE_SIZE  32768
#define DCIMB_CACHE_BYTE_SIZE  32768

ALIGN32 INT8U root_cache_ram[ROOT_CACHE_BYTE_SIZE];
ALIGN32 INT8U dcim_cache_ram[DCIM_CACHE_BYTE_SIZE];
ALIGN32 INT8U dcima_cache_ram[DCIMA_CACHE_BYTE_SIZE];
ALIGN32 INT8U dcimb_cache_ram[DCIMB_CACHE_BYTE_SIZE];

INT32S root_cache_size = 0;
INT32S dcim_cache_size = 0;
INT32S dcima_cache_size = 0;
INT32S dcimb_cache_size = 0;

#endif

//--------------------------------------------------
#if FS_FLUSH_CAHCE_EN

#define CACHE_FAT_TABLE_SYNC		0x80
#define CACHE_FAT_TABLE_HIT			0x40
#define CACHE_FAT_TABLE_INIT		0x20
#define CACHE_FAT_TABLE_MISS		0x10

#define CACHE_FAT_TABLE_CNT	10

typedef struct {
	INT32U  cache_sector_idx;
	INT32U  cache_addrs;
	INT32U	cache_time;
	INT8U  	dirty_flag;
	INT8U  	is_used_flag;
}cache_info;

cache_info cache_fat_table[CACHE_FAT_TABLE_CNT]={0};
#else
#define CACHE_FAT_TABLE_CNT	1
#endif
//--------------------------------------------------

#define SDC_CACHE_SIZE          (32*1024)
#define SDC_CACHE_SECTOR_NUMS   (SDC_CACHE_SIZE/512)
ALIGN32 INT8U sd_cache_ram[SDC_CACHE_SIZE*CACHE_FAT_TABLE_CNT];
//--------------------------------------------------

#if (FS_INFO_CACHE == 1 || FAT_WRITE_TBL_ID == 1)
  INT8U fsinfo_loaded_flag = 0;
  INT8U fsinfo_dirty_flag = 0;
  ALIGN32 INT8U sd_fs_info_ram[512];
#endif
//--------------------------------------------------

INT32U  mirror_start_id; // unit: sector
INT32U  mirror_end_id; // unit: sector

INT8U   cache_init_flag = 0;// cache has initialized, its value is set to 0xA8
INT8U   fat_cache_L1_en;	// if cache is intialized sucessfully, it will be set to 1
INT32U  fat_cluster_size;	// unit: sectors
INT32U  fat_tbl_size;		// unit: sectors
INT32U  fat_start_id[2];
static INT8U fat_type;		//FAT16 if its value is 16, or FAT32 if its value is 32
static INT32U fs_info_start;//sector no of FSINFO

INT32U  BPB_Start_id;		//the first sector no of DOS partition

#define SD_RW_RETRY_COUNT       3

//--------------------------------------------------
#if FAT_WRITE_TBL_ID==1
    static INT32U FSI_Free_Count=0;
    static INT32U FSI_Next_Free=0;
#endif
//--------------------------------------------------

//#define C_DATA3_PIN       38//IOC[6]
//#define C_DATA1_PIN       40//IOC[8]
//#define C_DATA2_PIN       41//IOC[9]

static INT32S SD_Initial(void);
static INT32S SD_Uninitial(void);
static void SD_GetDrvInfo(struct DrvInfo* info);
static INT32S SD_ReadSector(INT32U blkno, INT32U blkcnt, INT32U buf);
static INT32S SD_WriteSector(INT32U blkno, INT32U blkcnt, INT32U buf);
static INT32S SD_Flush(void);
static INT32S SD_tbl_mirror_sync(void);
static INT32S SD_cache_sync_step(void);
static INT32S SD_fill_fat_cache(INT32U start_clus, INT32U num_clus);

static INT32S fat_l1_cache_init(void);
static INT32S fat_cache_sync(void);
static void FsCpy4(void *_dst, const void *_src, int len);

void fat_l1_cache_reinit(void);
void fat_l1_cache_uninit(void);

#if DIR_INFO_CACHE
	INT32S dir_cache_init(void);
	INT32S dir_cache_flush(void);
#endif

#if FS_INFO_CACHE==1
	static INT32S fs_info_flush(void);
#endif

#if FAT_WRITE_TBL_ID == 1  //FAT2->FAT1
	static INT32S SD_fsinfo_sync(void)  //  // dominant fat2->fat1
	static INT32S SD_tbl_mirror_init(void);
	static INT32U fat_tbl_tansfer(INT32U blkno);
#endif

//--------------------------------------------------
struct Drv_FileSystem FS_SD_driver = {
	"SD",
	DEVICE_READ_ALLOW|DEVICE_WRITE_ALLOW,
	SD_Initial,
	SD_Uninitial,
	SD_GetDrvInfo,
	SD_ReadSector,
	SD_WriteSector,
	SD_Flush,
	SD_tbl_mirror_sync,
	SD_cache_sync_step,
	SD_fill_fat_cache,
};

/****************************************************************************/
#if FS_FLUSH_CAHCE_EN
INT8U find_cache_fat_table_for_read(INT32U sectorIdx)
{
	INT8U i;
	INT32U max_time_range = OSTimeGet();
	INT8U select_idx = 0;

	for(i=0; i<CACHE_FAT_TABLE_CNT; i++)
	{
		// Return unused cache fat table
		if(cache_fat_table[i].is_used_flag == 0)
		{
			return (i|CACHE_FAT_TABLE_INIT);
		}

		// When all table is full, find the oldest cache time of cache fat table to will replace it later     
		if(max_time_range >= cache_fat_table[i].cache_time)
		{
			max_time_range = cache_fat_table[i].cache_time;
			select_idx = i;
		}

		// BIGO! Return cache fat table	index
		if((sectorIdx >=cache_fat_table[i].cache_sector_idx) &&
		   (sectorIdx < (cache_fat_table[i].cache_sector_idx+SDC_CACHE_SECTOR_NUMS))
		)
		{
			return (i|CACHE_FAT_TABLE_HIT);
		}
	}
	
	return (select_idx|CACHE_FAT_TABLE_MISS);
}

INT8U find_cache_fat_table_for_write(INT32U sectorIdx)
{
	INT8U i;
	INT32U max_time_range = OSTimeGet();
	INT8U select_idx = 0;

	for(i=0; i<CACHE_FAT_TABLE_CNT; i++)
	{
		if(cache_fat_table[i].is_used_flag == 0)
		{
			return (i|CACHE_FAT_TABLE_INIT);
		}
		
		if(max_time_range >= cache_fat_table[i].cache_time)
		{
			max_time_range = cache_fat_table[i].cache_time;
			select_idx = i;
		}
		
		if((sectorIdx >=cache_fat_table[i].cache_sector_idx) &&
		   (sectorIdx < (cache_fat_table[i].cache_sector_idx+SDC_CACHE_SECTOR_NUMS))
		)
		{
			return (i|CACHE_FAT_TABLE_HIT);
		}
	}
	
	return (select_idx|CACHE_FAT_TABLE_SYNC);
}

#endif


/****************************************************************************/
#if DIR_INFO_CACHE
INT32S dir_cache_init(void) //add by wwj
{
	INT32S ret;

	if(dir_loaded_flag) return 0;

	if(fat_cache_L1_en && (start_sector_of_root != 0) && (start_sector_of_dcim != 0) && (start_sector_of_dcima != 0) && (start_sector_of_dcimb != 0)) {

		root_cache_size = fat_cluster_size << 9;
		if(root_cache_size > ROOT_CACHE_BYTE_SIZE) {
			root_cache_size = ROOT_CACHE_BYTE_SIZE;
		}
		root_cache_size >>= 9;

		dcim_cache_size = fat_cluster_size << 9;
		if(dcim_cache_size > DCIM_CACHE_BYTE_SIZE) {
			dcim_cache_size = DCIM_CACHE_BYTE_SIZE;
		}
		dcim_cache_size >>= 9;

		dcima_cache_size = fat_cluster_size << 9;
		if(dcima_cache_size > DCIMA_CACHE_BYTE_SIZE) {
			dcima_cache_size = DCIMA_CACHE_BYTE_SIZE;
		}
		dcima_cache_size >>= 9;

		dcimb_cache_size = fat_cluster_size << 9;
		if(dcimb_cache_size > DCIMB_CACHE_BYTE_SIZE) {
			dcimb_cache_size = DCIMB_CACHE_BYTE_SIZE;
		}
		dcimb_cache_size >>= 9;

        ret = drvl2_sd_read(start_sector_of_root, (INT32U *) &root_cache_ram[0], root_cache_size);
        if(ret == 0) {
	        ret = drvl2_sd_read(start_sector_of_dcim, (INT32U *) &dcim_cache_ram[0], dcim_cache_size);
	        if(ret == 0) {
		        ret = drvl2_sd_read(start_sector_of_dcima, (INT32U *) &dcima_cache_ram[0], dcima_cache_size);
		        if(ret == 0) {
			        ret = drvl2_sd_read(start_sector_of_dcimb, (INT32U *) &dcimb_cache_ram[0], dcimb_cache_size);
			        if(ret == 0) {
		        		dir_loaded_flag = 1;
		        		dcima_dirty_flag = 0;
		        		dcimb_dirty_flag = 0;
						DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("DIR cache init\r\n");
		        		return 0;
					}
		        }
	        }
        }
	}
	return -1;
}

INT32S dir_cache_flush(void)
{
	INT32S ret = 0;

	if(dir_loaded_flag) {
		if(dcima_dirty_flag) {
			ret = drvl2_sd_write(start_sector_of_dcima, (INT32U *)&dcima_cache_ram[0], dcima_cache_size);
			dcima_dirty_flag = 0;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("DCIMA flush\r\n");
		}

		if(dcimb_dirty_flag) {
			ret = drvl2_sd_write(start_sector_of_dcimb, (INT32U *)&dcimb_cache_ram[0], dcimb_cache_size);
			dcimb_dirty_flag = 0;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("DCIMB flush\r\n");
		}
	}
	return ret;
}

#endif

/****************************************************************************/
void fat_l1_cache_uninit(void)
{
    fat_cache_L1_en = 0;

#if FS_INFO_CACHE == 1
	fsinfo_loaded_flag = 0;
#endif

#if DIR_INFO_CACHE
	dir_loaded_flag = 0;
	start_sector_of_root = 0;
	start_sector_of_dcim = 0;
	start_sector_of_dcima = 0;
	start_sector_of_dcimb = 0;
#endif

}

void fat_l1_cache_reinit(void)
{
    cache_init_flag = 0;
    fat_l1_cache_init();

#if DIR_INFO_CACHE
	dir_loaded_flag = 0;
	start_sector_of_root = 0;
	start_sector_of_dcim = 0;
	start_sector_of_dcima = 0;
	start_sector_of_dcimb = 0;
#endif
}

INT32S fat_l1_cache_init(void)
{
    INT32S ret;
    INT8U *byte_buf;
    INT16U *short_buf;
    INT32U *word_buf;
    INT32U Next_Free = 0xFFFFFFFF;
    INT32U FS_info_tag = 0x00000000;
    INT32U Free_Count = 0xFFFFFFFF;
  #if FS_INFO_CACHE == 1
    INT32U *fi_word_buf = (INT32U *) &sd_fs_info_ram[0];
  #endif

  #if FAT_WRITE_TBL_ID == 1
    INT8U  mirror_en = 1;
  #endif

    if (cache_init_flag != 0xA8)
    {
      #if FS_CACHE_DBG_EN == 1
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("SD FatL1 cache Init...");
      #endif

        fs_info_start = 0xFFFFFFFF;

        BPB_Start_id = 0;  // NO MBR, BPB always is 0

        short_buf = (INT16U *) &sd_cache_ram[0];
        word_buf = (INT32U *) &sd_cache_ram[0];
        byte_buf = (INT8U *) &sd_cache_ram[0];


		#if FS_FLUSH_CAHCE_EN
		for(ret=0; ret<CACHE_FAT_TABLE_CNT; ret++)
		{
			cache_fat_table[ret].cache_sector_idx = 0;
			cache_fat_table[ret].dirty_flag = 0;
			cache_fat_table[ret].cache_time = 0;
			cache_fat_table[ret].is_used_flag = 0;
			cache_fat_table[ret].cache_addrs = (INT32U)(sd_cache_ram+(ret*SDC_CACHE_SIZE));
		}
		#endif

        ret = drvl2_sd_read(BPB_Start_id, (INT32U *) &sd_cache_ram[0], 1);
        if(ret==0 && short_buf[0x1fE/2] == 0xAA55 && byte_buf[0] != 0xEB) {
            BPB_Start_id = ((short_buf[0x1C8/2]<<16) | short_buf[0x1C6/2]);
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("MBR Find, first part offset :0x%x\r\n",BPB_Start_id);
            ret = drvl2_sd_read(BPB_Start_id, (INT32U *) &sd_cache_ram[0], 1);
        }

        if(ret != 0) {
            fat_cache_L1_en = 0;

			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 1\r\n");
            return -1;

		} else if(ret == 0) {
            fat_cache_L1_en = 1;

            fat_cluster_size = byte_buf[13];  // 8 sectors
            fat_start_id[0] = short_buf[7] + BPB_Start_id;   //0x24*0x200=0x4800 

            fat_tbl_size = short_buf[22/2];	//this value must be set to 0 in FAT32
            if(fat_tbl_size == 0) {
                //find FAT32
                fat_type = 32;
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FAT32\r\n");

                fat_tbl_size = word_buf[9];  //0x1d72*0x200=0x3AE400
                fs_info_start = short_buf[48/2] + BPB_Start_id;

              #if FS_INFO_CACHE == 1
                if ( drvl2_sd_read(fs_info_start, (INT32U *) &sd_fs_info_ram[0], 1)!=0 ) {
					fsinfo_loaded_flag = 0;
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 2\r\n");
				} else {
					fsinfo_loaded_flag = 1;
				}
				fsinfo_dirty_flag = 0;

                FS_info_tag = fi_word_buf[0];
                Free_Count = fi_word_buf[488/4] + BPB_Start_id;  //should not add BPB_Start_id, wwj comment@20140929
                Next_Free = fi_word_buf[492/4] + BPB_Start_id;
              #else
                if (drvl2_sd_read(fs_info_start, (INT32U *) &sd_cache_ram[0], 1) != 0) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 2\r\n");
				}
                FS_info_tag = word_buf[0];
                Free_Count = word_buf[488/4] + BPB_Start_id;  //should not add BPB_Start_id, wwj comment@20140929
                Next_Free = word_buf[492/4] + BPB_Start_id;
              #endif

                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("Fs info Tag: 0x%x (SectorId:%d)\r\n", FS_info_tag, fs_info_start);

              #if FAT_WRITE_TBL_ID == 1  //FAT2->FAT1
                if (FS_info_tag == 0x41615252) {
                    if ((FSI_Free_Count == Free_Count) && (FSI_Next_Free==Next_Free)) 
                    {
                        mirror_en=0;
                    }
                }
              #endif

            } else {
                fat_type = 16;
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FAT16\r\n");
            }
            fat_start_id[1] = fat_start_id[0] + fat_tbl_size; // 0x3AE400+0x4800=0x3B2C00
        }

      #if FAT_WRITE_TBL_ID==1
        if (mirror_en) {
            SD_tbl_mirror_init(); // Mirror initial FAT1->FAT2
        } else {
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("Tbl Mirror initial avoid\r\n");
        }
      #endif
        mirror_start_id = 0x3FFFFFFF;
        mirror_end_id = 0;  // default mirror start

      #if FS_CACHE_DBG_EN == 1
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("\r\nfat_cluster_size:%d\r\n",fat_cluster_size);
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("fat_start_id[0]:%d\r\n",fat_start_id[0]);
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("fat_start_id[1]:%d\r\n",fat_start_id[1]);
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("fat_tbl_size:%d\r\n",fat_tbl_size);
      #endif
        cache_init_flag = 0xA8;
    }
    return 0;
}


#if FAT_WRITE_TBL_ID==1
INT32S SD_fsinfo_sync(void)  //  // dominant fat2->fat1
{
    INT32U *word_buf=(INT32U *)&sd_fs_info_ram[0];
    INT32S ret;

    if (fat_type==32)
    {
        #if FS_INFO_CACHE==1
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FI_SYNC\r\n");
            ret=0;
        #else
            ret = drvl2_sd_read(fs_info_start, (INT32U *) &sd_fs_info_ram[0], 1);
        #endif
        
        if (ret==0) {
            FSI_Free_Count = word_buf[488/4]+BPB_Start_id;  //should not add BPB_Start_id, wwj comment@20140929
            FSI_Next_Free = word_buf[492/4]+BPB_Start_id;
        } else {
            FSI_Free_Count = 0xFFFFFFEE;
            FSI_Next_Free = 0;
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 3\r\n");
        }
        return ret;
    }
    return -1;
}
#endif


#if FAT_WRITE_TBL_ID==1
INT32S SD_tbl_mirror_init(void)  // dominant fat2->fat1
{
    INT32U i;
    INT32U sync_size;
    INT32U move_cnt;
    INT32U redundant_cnt;
    INT32U mirror_start_offset;
    INT32U fat0_sector_id;
    INT32U fat1_sector_id;
    INT32U fat_mirror_init_time=sw_timer_get_counter_L();

    sync_size = fat_tbl_size;
    fat0_sector_id = fat_start_id[0];
    fat1_sector_id = fat_start_id[1];
    
    move_cnt = sync_size/SDC_CACHE_SECTOR_NUMS;
    redundant_cnt = sync_size%SDC_CACHE_SECTOR_NUMS;
    mirror_start_offset = 0;
    for (i=0;i<move_cnt;i++)
    {
        if ( drvl2_sd_read(fat0_sector_id+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0] , SDC_CACHE_SECTOR_NUMS)!=0 )
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 4\r\n");
        if ( drvl2_sd_write(fat1_sector_id+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0], SDC_CACHE_SECTOR_NUMS)!=0 ) 
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 1\r\n");
    }

    if (redundant_cnt)
    {
        if ( drvl2_sd_read(fat0_sector_id+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0] , redundant_cnt)!=0 )
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 5\r\n");
        if ( drvl2_sd_write(fat1_sector_id+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0], redundant_cnt)!=0 )
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 2\r\n");
    }

    mirror_start_id = 0x3FFFFFFF;
    mirror_end_id = 0;  // default mirror start

    #if 1 //FS_CACHE_DBG_EN==1
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FAT1->FAT2 full size %d KB mirror time: %d\r\n",fat_tbl_size/2,sw_timer_get_counter_L()-fat_mirror_init_time);
    #endif

    return 0;
}
#endif



INT32S SD_tbl_mirror_sync(void)
{
#if FS_TBL_MIRROR_SYNC==1
    INT32U i;
    INT32U sync_size;
    INT32U move_cnt;
    INT32U redundant_cnt;
    INT32U mirror_start_offset;
    INT32S ret = -1;
#else
    INT32S ret=0;
#endif

    //fat_cache_sync();

#if FS_INFO_CACHE==1
    //fs_info_flush();
#endif

#if DIR_INFO_CACHE
    //dir_cache_flush();
#endif

#if FAT_WRITE_TBL_ID==1
    SD_fsinfo_sync();
#endif

#if FS_TBL_MIRROR_SYNC==1
    sync_size = mirror_end_id-mirror_start_id+1;
    if ((mirror_start_id!=0x3FFFFFFF) && (sync_size<=fat_tbl_size))
    {
        move_cnt = sync_size/SDC_CACHE_SECTOR_NUMS;
        redundant_cnt = sync_size%SDC_CACHE_SECTOR_NUMS;
        mirror_start_offset = mirror_start_id-fat_start_id[FAT_MAIN_TBL_ID];
        for (i=0;i<move_cnt;i++)
        {
            if ( drvl2_sd_read(fat_start_id[FAT_MAIN_TBL_ID]+mirror_start_offset+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0] , SDC_CACHE_SECTOR_NUMS) )
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 6\r\n");
            if ( drvl2_sd_write(fat_start_id[FAT_SECOND_TBL_ID]+mirror_start_offset+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0], SDC_CACHE_SECTOR_NUMS) )
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 3\r\n");
        }

        if (redundant_cnt)
        {
            if ( drvl2_sd_read(fat_start_id[FAT_MAIN_TBL_ID]+mirror_start_offset+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0] , redundant_cnt) )
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 7\r\n");		
            if ( drvl2_sd_write(fat_start_id[FAT_SECOND_TBL_ID]+mirror_start_offset+SDC_CACHE_SECTOR_NUMS*i, (INT32U *) &sd_cache_ram[0], redundant_cnt) )
                DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 4\r\n");
        }        

        mirror_start_id = 0x3FFFFFFF;
        mirror_end_id = 0;  // default mirror start

      #if FS_CACHE_DBG_EN==1
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FS TBL SYNC %d Sectors [%d:%d]->[%d:%d]\r\n",sync_size,fat_start_id[FAT_MAIN_TBL_ID]+mirror_start_offset,fat_start_id[FAT_MAIN_TBL_ID]+mirror_start_offset+sync_size-1,fat_start_id[FAT_SECOND_TBL_ID]+mirror_start_offset,fat_start_id[FAT_SECOND_TBL_ID]+mirror_start_offset+sync_size-1);
      #endif

        ret = 0;
    }

  #if FS_CACHE_DBG_EN==1
    if (ret == -1) {
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FS TBL SYNC NONE..\r\n");
    }
  #endif
#endif
    return ret;
}

INT32S SD_Initial(void)
{
    INT32S ret;
    
//    gpio_write_io(C_DATA3_PIN, 1);
//    gpio_write_io(C_DATA1_PIN, 1);
//    gpio_write_io(C_DATA2_PIN, 1);

	ret = drvl2_sd_init();
	if (ret == 0) {
		fat_l1_cache_init();
	} else {
//		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FS drvl2_sd_init fail\r\n");
	}
	fs_sd_ms_plug_out_flag_reset();
	return ret; 
}

INT32S SD_Uninitial(void)
{
     drvl2_sd_card_remove();
	 return 0;
}

void SD_GetDrvInfo(struct DrvInfo* info)
{
    fat_l1_cache_init();
	info->nSectors = drvl2_sd_sector_number_get();
	info->nBytesPerSector = 512;
}

//read/write speed test function
#if (FAT_WRITE_TBL_ID==1)
static INT32U fat_tbl_tansfer(INT32U blkno)
{
    if ((blkno>=fat_start_id[0]) && (blkno<fat_start_id[0]+fat_tbl_size)) {
        blkno += fat_tbl_size;
    }
    return blkno;
}
#endif

INT32S SD_ReadSector(INT32U blkno, INT32U blkcnt, INT32U buf)
{
	INT32S	ret;
	INT32S	i;
#if FS_FLUSH_CAHCE_EN==1
	INT8U retIdx;
	INT32U cache_sector_idx;
#endif

    fat_l1_cache_init();

#if DIR_INFO_CACHE
	dir_cache_init();
#endif
    
    if (fs_sd_ms_plug_out_flag_get()==1) {return 0xFFFFFFFF;}

#if (FAT_WRITE_TBL_ID==1)
    blkno=fat_tbl_tansfer(blkno);
#endif

#if FS_INFO_CACHE == 1
    if ((fat_type==32) && (blkcnt==1) && (blkno==fs_info_start) && (fsinfo_loaded_flag)) {
        //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FI_R\r\n");
        FsCpy4((void *)buf, (void *) &sd_fs_info_ram[0], 512);
        return 0;
    }
#endif

#if DIR_INFO_CACHE
	if((blkcnt == 1) && dir_loaded_flag) {
		if((blkno >= start_sector_of_root) && (blkno < (start_sector_of_root + root_cache_size))) {
	        FsCpy4((void *)buf, (void *) (&root_cache_ram[0] + ((blkno - start_sector_of_root)<<9)), 512);
			//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("root_r\r\n");
			return 0;
		}

		if((blkno >= start_sector_of_dcim) && (blkno < (start_sector_of_dcim + dcim_cache_size))) {
	        FsCpy4((void *)buf, (void *) (&dcim_cache_ram[0] + ((blkno - start_sector_of_dcim)<<9)), 512);
			//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcim_r\r\n");
			return 0;
		}

		if((blkno >= start_sector_of_dcima) && (blkno < (start_sector_of_dcima + dcima_cache_size))) {
	        FsCpy4((void *)buf, (void *) (&dcima_cache_ram[0] + ((blkno - start_sector_of_dcima)<<9)), 512);
			//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcima_r\r\n");
			return 0;
		}
	
		if((blkno >= start_sector_of_dcimb) && (blkno < (start_sector_of_dcimb + dcimb_cache_size))) {
	        FsCpy4((void *)buf, (void *) (&dcimb_cache_ram[0] + ((blkno - start_sector_of_dcimb)<<9)), 512);
			//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcima_r\r\n");
			return 0;
		}
	}
#endif

#if FS_FLUSH_CAHCE_EN==1
    if (blkcnt==1) {
        if (fat_cache_L1_en) {
            if ((blkno>=fat_start_id[FAT_MAIN_TBL_ID]) && (blkno<fat_start_id[FAT_MAIN_TBL_ID]+fat_tbl_size)) 
            {
				retIdx = find_cache_fat_table_for_read(blkno);
				if(retIdx & CACHE_FAT_TABLE_HIT)
				{
			      #if FS_CACHE_DBG_EN == 1
			        //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("h");
			      #endif

					retIdx &= ~(CACHE_FAT_TABLE_HIT);
					cache_sector_idx = ((blkno-cache_fat_table[retIdx].cache_sector_idx)<<9);
					FsCpy4((void *)buf, (void *)(cache_fat_table[retIdx].cache_addrs+cache_sector_idx), 512);
					return 0;
				}
				else if(retIdx & CACHE_FAT_TABLE_INIT)
				{
			      #if FS_CACHE_DBG_EN == 1
			        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("i");
			      #endif
					retIdx &= ~(CACHE_FAT_TABLE_INIT);

					// Read data from SDC and store it into cache fat table
					cache_fat_table[retIdx].cache_sector_idx = ((blkno/SDC_CACHE_SECTOR_NUMS)*SDC_CACHE_SECTOR_NUMS);
					
					for(i=0; i<SD_RW_RETRY_COUNT; i++) {
						ret = drvl2_sd_read(cache_fat_table[retIdx].cache_sector_idx, (INT32U *) cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
						if(ret == 0) {
							break;
						}
					}

					// Return data
					cache_sector_idx = ((blkno-cache_fat_table[retIdx].cache_sector_idx)<<9);
					FsCpy4((void *)buf, (void *)(cache_fat_table[retIdx].cache_addrs+cache_sector_idx), 512);		
					cache_fat_table[retIdx].is_used_flag = 1;
					cache_fat_table[retIdx].cache_time = OSTimeGet();
					return 0;
				}
				else
				{
			      #if FS_CACHE_DBG_EN == 1
			        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("m");
			      #endif

					retIdx &= ~(CACHE_FAT_TABLE_MISS);

					// Write the replaced data from the cache fat table to the SDC
					if(cache_fat_table[retIdx].dirty_flag)
					{
				      #if FS_CACHE_DBG_EN == 1
				        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("w");
				      #endif
						for(i=0; i<SD_RW_RETRY_COUNT; i++)
						{
							ret = drvl2_sd_write(cache_fat_table[retIdx].cache_sector_idx, (INT32U *)cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
							if(ret == 0) {
								break;
							}
						}
					}

					// Read data from SDC and store it into cache fat table
					cache_fat_table[retIdx].cache_sector_idx = ((blkno/SDC_CACHE_SECTOR_NUMS)*SDC_CACHE_SECTOR_NUMS);
				
					for(i=0; i<SD_RW_RETRY_COUNT; i++) {
						ret = drvl2_sd_read(cache_fat_table[retIdx].cache_sector_idx, (INT32U *) cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
						if(ret == 0) {
							break;
						}
					}

					cache_sector_idx = ((blkno-cache_fat_table[retIdx].cache_sector_idx)<<9);
					FsCpy4((void *)buf,(void *)(cache_fat_table[retIdx].cache_addrs+cache_sector_idx),512);
					cache_fat_table[retIdx].cache_time = OSTimeGet();
					cache_fat_table[retIdx].is_used_flag = 1;
					cache_fat_table[retIdx].dirty_flag = 0;
					return 0;
				}
            } else {
            	//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("g");
            }
        } else {
        	//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("g");
        }
    }
#endif

	for(i=0; i<SD_RW_RETRY_COUNT; i++) {
		ret = drvl2_sd_read(blkno, (INT32U *) buf, blkcnt);
		if(ret == 0) {
			break;
		} else {
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD read fail 8\r\n");
		}
	}

#if SUPPORT_STG_SUPER_PLUGOUT == 1
    if(ret != 0) {
        //if(drvl2_sd_read(0, (INT32U *) buf, 1) != 0)
        {
            fs_sd_ms_plug_out_flag_en();
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("============>SUPER PLUG OUT DETECTED<===========\r\n");
        }
    }
#endif

	return ret;
}


INT32S SD_WriteSector(INT32U blkno, INT32U blkcnt, INT32U buf)
{
	INT32S	ret;
	INT32S	i;
#if FS_FLUSH_CAHCE_EN==1
	INT8U retIdx;
	INT32U cache_sector_idx;
#endif

    fat_l1_cache_init();

#if DIR_INFO_CACHE
	dir_cache_init();
#endif

    if(fs_sd_ms_plug_out_flag_get() == 1) {return 0xFFFFFFFF;}

#if (FAT_WRITE_TBL_ID==1)
    blkno = fat_tbl_tansfer(blkno);
#endif

    if (blkcnt == 1) {
        if ((blkno >= fat_start_id[FAT_MAIN_TBL_ID]) && (blkno < fat_start_id[FAT_MAIN_TBL_ID]+fat_tbl_size)) {
            if(blkno<mirror_start_id) {
                mirror_start_id = blkno;
            }

            if(blkno>mirror_end_id) {
                mirror_end_id = blkno;
            }

          #if FS_FLUSH_CAHCE_EN==1
            if(fat_cache_L1_en) {
				retIdx = find_cache_fat_table_for_write(blkno);
				if((retIdx & CACHE_FAT_TABLE_SYNC) ||
				   (retIdx & CACHE_FAT_TABLE_INIT)
				)
				{
					// Write the replaced data from the cache fat table to the SDC
					if(retIdx & CACHE_FAT_TABLE_SYNC)
					{	
						retIdx &= ~(CACHE_FAT_TABLE_SYNC);
						
						if(cache_fat_table[retIdx].dirty_flag)
						{
					      #if FS_CACHE_DBG_EN == 1
					        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("w");
					      #endif
							cache_fat_table[retIdx].dirty_flag = 0;
							for(i=0; i<SD_RW_RETRY_COUNT; i++)
							{
								ret = drvl2_sd_write(cache_fat_table[retIdx].cache_sector_idx, (INT32U *)cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
								if(ret == 0) {
									break;
								}
							}
						}
					}
					else
					{
				      #if FS_CACHE_DBG_EN == 1
				        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("i");
				      #endif
						retIdx &= ~(CACHE_FAT_TABLE_INIT);
					}

					// Read data from SDC and store it into cache fat table
					cache_fat_table[retIdx].cache_sector_idx = ((blkno/SDC_CACHE_SECTOR_NUMS)*SDC_CACHE_SECTOR_NUMS);
					
					for(i=0; i<SD_RW_RETRY_COUNT; i++) {
						ret = drvl2_sd_read(cache_fat_table[retIdx].cache_sector_idx, (INT32U *) cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
						if(ret == 0) {
							break;
						}
					}

					cache_sector_idx = ((blkno-cache_fat_table[retIdx].cache_sector_idx)<<9);
					FsCpy4((void *)(cache_fat_table[retIdx].cache_addrs+cache_sector_idx),(void *)buf, 512);
					cache_fat_table[retIdx].cache_time = OSTimeGet();
					cache_fat_table[retIdx].is_used_flag = 1;
					cache_fat_table[retIdx].dirty_flag = 1;
					return 0;
					
				}
				else if(retIdx & CACHE_FAT_TABLE_HIT)
				{
			      #if FS_CACHE_DBG_EN == 1
			        //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("h");
			      #endif
					retIdx &= ~(CACHE_FAT_TABLE_HIT);

					cache_sector_idx = ((blkno-cache_fat_table[retIdx].cache_sector_idx)<<9);
					FsCpy4((void *)(cache_fat_table[retIdx].cache_addrs+cache_sector_idx),(void *)buf, 512);
					cache_fat_table[retIdx].dirty_flag = 1;
					return 0;
				}
            }
          #endif 
        }  

      #if FS_INFO_CACHE == 1
        else if((fat_type == 32) && (blkno == fs_info_start) && (fsinfo_loaded_flag))
        {
            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FI_W\r\n");
            FsCpy4((void *)&sd_fs_info_ram[0],(const void *) buf, 512);
            fsinfo_dirty_flag = 1;
            return 0;
        }
      #endif

	  #if DIR_INFO_CACHE
		else if(dir_loaded_flag) {
			if((blkno >= start_sector_of_root) && (blkno < (start_sector_of_root + root_cache_size))) {
				dir_cache_flush();
		        dir_loaded_flag = 0;
				//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("root_w\r\n");
			}

			else if((blkno >= start_sector_of_dcim) && (blkno < (start_sector_of_dcim + dcim_cache_size))) {
				dir_cache_flush();
		        dir_loaded_flag = 0;
				//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcim_w\r\n");
			}

			else if((blkno >= start_sector_of_dcima) && (blkno < (start_sector_of_dcima + dcima_cache_size))) {
		        FsCpy4((void *) (&dcima_cache_ram[0] + ((blkno - start_sector_of_dcima)<<9)), (void *)buf, 512);
				dcima_dirty_flag = 1;
				//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcima_w\r\n");
				return 0;
			}
		
			else if((blkno >= start_sector_of_dcimb) && (blkno < (start_sector_of_dcimb + dcimb_cache_size))) {
		        FsCpy4((void *) (&dcimb_cache_ram[0] + ((blkno - start_sector_of_dcimb)<<9)), (void *)buf, 512);
				dcimb_dirty_flag = 1;
				//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dcimb_w\r\n");
				return 0;
			}
		} else {
			//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("f");
		}
	  #endif

    }

	for(i=0; i<SD_RW_RETRY_COUNT; i++)
	{
		ret = drvl2_sd_write(blkno, (INT32U *) buf, blkcnt);
		if(ret == 0) {
			break;
		} else {
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 5\r\n");
		}
	}

#if SUPPORT_STG_SUPER_PLUGOUT == 1
    if (ret!=0) {
        if (drvl2_sd_read(0, (INT32U *) buf, 1) != 0) {
            fs_sd_ms_plug_out_flag_en();
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("============>SUPER PLUG OUT DETECTED<===========\r\n");
        }
    }
#endif

	return ret;
}

INT32S SD_Flush(void)
{
  #if FS_INFO_CACHE==1
    fs_info_flush();
  #endif

  #if DIR_INFO_CACHE
    dir_cache_flush();
  #endif

    fat_cache_sync();
    return 0;
}


INT32S fat_cache_sync(void)
{
	INT8U i;

  #if FS_FLUSH_CAHCE_EN==1
    if (fat_cache_L1_en) {
		INT8U did_flush = 0;

		for(i=0; i<CACHE_FAT_TABLE_CNT; i++)
		{
			if(cache_fat_table[i].dirty_flag)
			{
		      #if FS_CACHE_DBG_EN == 1
		        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("s");
		      #endif
				did_flush = 1;

				cache_fat_table[i].dirty_flag = 0;
			    if (drvl2_sd_write(cache_fat_table[i].cache_sector_idx, (INT32U *)cache_fat_table[i].cache_addrs, SDC_CACHE_SECTOR_NUMS) != 0) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 6\r\n");
				}
			}

			if((i == (CACHE_FAT_TABLE_CNT - 1)) && (did_flush)) {
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FAT cache flush\r\n");
			}
		}
		return 0;
    }
    return -1;
  #endif
}

INT32S SD_cache_sync_step(void)
{
	INT8U i;
	INT32S ret;

  #if FS_FLUSH_CAHCE_EN==1
    if (fat_cache_L1_en) {
		for(i=0; i<CACHE_FAT_TABLE_CNT; i++)
		{
			if(cache_fat_table[i].dirty_flag)
			{
		      #if FS_CACHE_DBG_EN == 1
		        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("s");
		      #endif
				cache_fat_table[i].dirty_flag = 0;
			    if (drvl2_sd_write(cache_fat_table[i].cache_sector_idx, (INT32U *)cache_fat_table[i].cache_addrs, SDC_CACHE_SECTOR_NUMS) != 0) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 6\r\n");
				}
				return 1;
			}
		}
    }
  #endif

  #if FS_INFO_CACHE==1
	if((fat_type==32) && (fsinfo_loaded_flag == 1) && (fsinfo_dirty_flag == 1)) {
        //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FI_FLUSH\r\n");
        ret = drvl2_sd_write(fs_info_start, (INT32U *)&sd_fs_info_ram[0], 1);
        if (ret != 0) {
			fsinfo_loaded_flag = 0;
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 7\r\n");
        }
        fsinfo_dirty_flag = 0;
        return 1;
    }
  #endif

	return 0;
}



INT32S SD_fill_fat_cache(INT32U start_clus, INT32U num_clus)
{
  #if FS_FLUSH_CAHCE_EN==1
	INT8U retIdx, i;
	INT32U blkno;
	INT32S ret;
	INT32U addr1, addr2;
	INT32U *ptr, *ptr_end;

    if(fat_cache_L1_en && num_clus)
    {
	    while(1) {
			blkno = fat_start_id[FAT_MAIN_TBL_ID] + (start_clus * 4)/512;
			retIdx = find_cache_fat_table_for_write(blkno);
			if((retIdx & CACHE_FAT_TABLE_SYNC) ||
			   (retIdx & CACHE_FAT_TABLE_INIT))
			{
				// Write the replaced data from the cache fat table to the SDC
				if(retIdx & CACHE_FAT_TABLE_SYNC) {
					retIdx &= ~(CACHE_FAT_TABLE_SYNC);
					if(cache_fat_table[retIdx].dirty_flag) {
				      #if FS_CACHE_DBG_EN == 1
				        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("w");
				      #endif
						cache_fat_table[retIdx].dirty_flag = 0;
						for(i=0; i<SD_RW_RETRY_COUNT; i++) {
							ret = drvl2_sd_write(cache_fat_table[retIdx].cache_sector_idx, (INT32U *)cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
							if(ret == 0) {
								break;
							}
						}
					}
				} else {

			      #if FS_CACHE_DBG_EN == 1
			        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("i");
			      #endif
					retIdx &= ~(CACHE_FAT_TABLE_INIT);
				}

				// Read data from SDC and store it into cache fat table
				cache_fat_table[retIdx].cache_sector_idx = ((blkno/SDC_CACHE_SECTOR_NUMS)*SDC_CACHE_SECTOR_NUMS);
				
				for(i=0; i<SD_RW_RETRY_COUNT; i++) {
					ret = drvl2_sd_read(cache_fat_table[retIdx].cache_sector_idx, (INT32U *) cache_fat_table[retIdx].cache_addrs, SDC_CACHE_SECTOR_NUMS);
					if(ret == 0) {
						break;
					}
				}
				
				cache_fat_table[retIdx].cache_time = OSTimeGet();
				cache_fat_table[retIdx].is_used_flag = 1;
				cache_fat_table[retIdx].dirty_flag = 1;

			} else if(retIdx & CACHE_FAT_TABLE_HIT) {

		      #if FS_CACHE_DBG_EN == 1
		        //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("h");
		      #endif
				retIdx &= ~(CACHE_FAT_TABLE_HIT);

				cache_fat_table[retIdx].dirty_flag = 1;
			}

			addr1 = fat_start_id[FAT_MAIN_TBL_ID] * 512 + (start_clus * 4) - cache_fat_table[retIdx].cache_sector_idx * 512 + cache_fat_table[retIdx].cache_addrs;
			ptr = (INT32U *)addr1;
			addr2 = cache_fat_table[retIdx].cache_addrs + SDC_CACHE_SIZE;
			ptr_end = (INT32U *)addr2;
			while(ptr < ptr_end) {
				*ptr++ = start_clus + 1;
				start_clus++;
				num_clus--;
				if(num_clus == 0) {
					ptr--;
					*ptr = LONG_LAST_CLUSTER;
					break;
				}
			}
			if(num_clus == 0) return STATUS_OK;
		}
    }
  #endif 

	return STATUS_FAIL;
}


//=== SD 1 setting ===//
#if (SD_DUAL_SUPPORT==1)

INT32S SD1_Initial(void)
{
	return drvl2_sd1_init();
}

INT32S SD1_Uninitial(void)
{
     drvl2_sd1_card_remove();
	 return 0;
}

void SD1_GetDrvInfo(struct DrvInfo* info)
{
	info->nSectors = drvl2_sd1_sector_number_get();
	info->nBytesPerSector = 512;
}

//read/write speed test function
INT32S SD1_ReadSector(INT32U blkno, INT32U blkcnt, INT32U buf)
{
	INT32S	ret;
	INT32S	i;

    if (fs_sd_ms_plug_out_flag_get()==1) {return 0xFFFFFFFF;}
	for(i = 0; i < SD_RW_RETRY_COUNT; i++)
	{
		ret = drvl2_sd1_read(blkno, (INT32U *) buf, blkcnt);
		if(ret == 0)
		{
			break;
		}
	}
  #if SUPPORT_STG_SUPER_PLUGOUT == 1
    if (ret!=0) 
    {
        //if (drvl2_sd_read(0, (INT32U *) buf, 1)!=0)
        {
            fs_sd_ms_plug_out_flag_en();
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("============>SUPER PLUG OUT DETECTED<===========\r\n");
        }
    }
  #endif
	return ret;
}

INT32S SD1_WriteSector(INT32U blkno, INT32U blkcnt, INT32U buf)
{
	INT32S	ret;
	INT32S	i;

    if (fs_sd_ms_plug_out_flag_get()==1) {return 0xFFFFFFFF;}
	for(i = 0; i < SD_RW_RETRY_COUNT; i++)
	{
		ret = drvl2_sd1_write(blkno, (INT32U *) buf, blkcnt);
		if(ret == 0)
		{
			break;
		}
	}
  #if SUPPORT_STG_SUPER_PLUGOUT == 1
    if (ret!=0) 
    {
        if (drvl2_sd1_read(0, (INT32U *) buf, 1)!=0)
        {
            fs_sd_ms_plug_out_flag_en();
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("============>SUPER PLUG OUT DETECTED<===========\r\n");
        }
    }
  #endif
	return ret;
}

INT32S SD1_Flush(void)
{

    //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("+++++++SD1_Flush\r\n");
	return 0;
}

struct Drv_FileSystem FS_SD1_driver = {
	"SD1",
	DEVICE_READ_ALLOW|DEVICE_WRITE_ALLOW,
	SD1_Initial,
	SD1_Uninitial,
	SD1_GetDrvInfo,
	SD1_ReadSector,
	SD1_WriteSector,
	SD1_Flush,
};
#endif

#if FS_INFO_CACHE==1
INT32S fs_info_flush(void)
{
    INT32S ret=0;

	if((fat_type==32) && (fsinfo_loaded_flag == 1) && (fsinfo_dirty_flag == 1)) {
        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("FI_FLUSH\r\n");
        ret = drvl2_sd_write(fs_info_start, (INT32U *)&sd_fs_info_ram[0], 1);
        if (ret != 0) {
			fsinfo_loaded_flag = 0;
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SD write fail 7\r\n");
        }
        fsinfo_dirty_flag = 0;
    }
    return ret;
}
#endif


static void FsCpy4(void *_dst, const void *_src, int len)
{
	register long *dst = (long*)_dst;
	const register long *src = (long*)_src;
	register long *end = (long*)((char*)_dst + len);
	len >>= 2;
	switch(len & 15)
	{
	case 15:
		__asm{
			LDMIA src!,{r4-r10}
			STMIA dst!,{r4-r10}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 14:
		__asm{
			LDMIA src!,{r4-r9}
			STMIA dst!,{r4-r9}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 13:
		__asm{
			LDMIA src!,{r4-r8}
			STMIA dst!,{r4-r8}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 12:
		__asm{
			LDMIA src!,{r4-r7}
			STMIA dst!,{r4-r7}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 11:
		__asm{
			LDMIA src!,{r4-r6}
			STMIA dst!,{r4-r6}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 10:
		__asm{
			LDMIA src!,{r4-r5}
			STMIA dst!,{r4-r5}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
		break;
	case 9:
		__asm{
			LDMIA src!,{r4-r12}
			STMIA dst!,{r4-r12}
		}
		break;
	case 8:
		__asm{
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}
		}
		break;
	case 7:
		__asm{
			LDMIA src!,{r4-r10}
			STMIA dst!,{r4-r10}
		}
		break;
	case 6:
		__asm{
			LDMIA src!,{r4-r9}
			STMIA dst!,{r4-r9}
		}
		break;
	case 5:
		__asm{
			LDMIA src!,{r4-r8}
			STMIA dst!,{r4-r8}
		}
		break;
	case 4:
		__asm{
			LDMIA src!,{r4-r7}
			STMIA dst!,{r4-r7}
		}
		break;
	case 3:
		__asm{
			LDMIA src!,{r4-r6}
			STMIA dst!,{r4-r6}
		}
		break;
	case 2:
		__asm{
			LDMIA src!,{r4-r5}
			STMIA dst!,{r4-r5}
		}
		break;
	case 1:
		*dst++ = *src++;
	}

	while(dst < end)
	{
		__asm{
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}
			LDMIA src!,{r4-r11}
			STMIA dst!,{r4-r11}			
		}
	}
}

//=== This is for code configuration DON'T REMOVE or MODIFY it ===//
#endif //(defined SD_EN) && (SD_EN == 1)                          //
//================================================================//

