#ifndef __DRV_L2_HDMI_H__
#define __DRV_L2_HDMI_H__

#ifdef __cplusplus
extern "C" {
#endif

int drvl2_hdmi_init(unsigned int DISPLAY_MODE, unsigned int AUD_FREQ);

#ifdef __cplusplus
}
#endif

#endif		// __DRV_L2_HDMI_H__

