#include "my_video_codec_callback.h"

//+++ GuanYu
#include "drv_l1_wrap.h" 
#include "drv_l1_scaler.h"
#include "drv_l1_conv422to420.h"
#include "drv_l1_conv420to422.h"
#include "avi_encoder_app.h"
#include "drv_l2_sensor.h"
#include "ap_state_config.h"
#include "ap_state_resource.h"
//---

#if DUAL_SENSOR_FUNC_ENABLE
#include "drv_l1_csi.h"
#endif

/****************************************************************************/
#include "LDWs.h"
#if (Enable_Lane_Departure_Warning_System)
INT32U LDWS_buf_malloc_cnt; 
INT32U LDWS_buf_addrs;
INT32U LDWS_buf_size;
INT8U  LDWS_buf_addrs_idx;
INT8U  LDWS_start_fifo_idx;
INT8U  LDWS_end_fifo_idx;
extern INT8U LDWS_Enable_Flag;
extern INT8U ap_LDW_get_from_config(INT8U LDW_choice);

extern INT32U USE_SDRAM_SUPPORT_FIFO_ADDRS_START;
extern INT32U USE_SDRAM_SUPPORT_FIFO_ADDRS_END;

#endif

extern INT32S ap_display_queue_put(INT32U *queue, INT32U data);
/****************************************************************************/
#define bit(n) (1UL << (n))

#define DateTimeStampBufWidth	45 // Unit: Byte 
#define DateTimeStampBufSize	(DateTimeStampBufWidth*40)
INT8U  DateTimeStampBuf[DateTimeStampBufSize];
TIME_T	DateTimeStamp = 0;
INT8U   DateTimeFormatFlag = 0;
INT8U   DateTimeInitFlag = 0;

typedef struct date_time_byte_offset_s
{
	INT32U Year_Ones;
	INT32U Year_Tens;
	INT32U Year_Hundreds;
	INT32U Year_Thousands;
	INT32U Month_Ones;
	INT32U Month_Tens;
	INT32U Day_Ones;
	INT32U Day_Tens;	
	INT32U Forward_Slash_1;
	INT32U Forward_Slash_2;
}date_time_byte_offset_t;

date_time_byte_offset_t DateTimeByteOffset = 0;
extern t_FONT_TABLE_STRUCT  *number_font_cache_1;
void DateTimeBufUpdate(void);
void DateTimeDraw(INT32U targetBuf,STRING_INFO strInfo,INT32U showTimeStamp,INT8U drawFormat);

/****************************************************************************/
//+++ Zoom
#define DO_ZOOM_NOTHING	0
#define DO_ZOOM_IN 		1
#define DO_ZOOM_OUT		2
//---

//+++ Video Recording
#define VIDEO_RECORD_NOTHING	0
#define VIDEO_RECORD_START		1
#define VIDEO_RECORD_RECING		2
#define VIDEO_RECORD_STOP		3
//---

//+++ Scaler
typedef enum
{
    SCALER_BUFFER_IDX_A,                     
    SCALER_BUFFER_IDX_B,
    SCALER_BUFFER_IDX_MAX
} SCALER_BUFFER_IDX;

/****************************************************************************/
static INT8U zoomInOutFlag = DO_ZOOM_NOTHING;
static volatile INT8U videoRecordFlag = VIDEO_RECORD_NOTHING;
static volatile INT8U wantToStopPreviewFlag = 0;

INT8U PreviewIsStopped = 1;
INT8U PreviewInitDone = 0;

static INT8U protect_recover_flag = 0;
static INT32U protect_recover_cnt = 0;
static INT32U fifo_addr_bak0 = 0;
static INT32U fifo_addr_bak1 = 0;

static INT8U wantToPreview2DummyFlag = 0;
static INT8U DoBlackEdgeFlag = 0;
static INT32U ZOOM_WIDTH_INTERVAL = 0;
static INT32U ZOOM_HEIGHT_INTERVAL = 0;

#if USE_BYPASS_SCALER1_PATH
INT8U scaler_isr_done_flag = 0;
#endif

preview_args_t gGpreviewArgs = {0};

/****************************************************************************/
//+++ Zoom
typedef struct zoom_args_s
{
	sensor_frame_range_t sensor_clip_range;
	INT32U source_width;
	INT32U source_height;
	INT32U scaler_factor_w;
	INT32U scaler_factor_h;	
	INT32U zoom_step;
}zoom_args_t;

zoom_args_t gZoomArgs = {0};

//+++ Conv422to420
typedef struct conv422_args_s
{
	INT32U conv422_buffer_A;
	INT32U conv422_buffer_B;
	INT32U conv422_buffer_next;
	INT32U conv422_fifo_total_count;
	INT32U conv422_fifo_line_len;
	INT32U conv422_fifo_data_size;
	INT32U (*conv422_fifo_ready_notify)(INT32U fifoSrc,INT32U fifoMsg, INT32U fifoAddrs ,INT32U fifoIdx);	
	INT32U (*conv422_fifo_buffer_addrs_get)(void);
	INT32S (*conv422_fifo_buffer_addrs_put)(INT32U addr);
	INT8U  conv422_output_format;
	INT8U  conv422_isr_count_max;
	INT8U  conv422_isr_count;
	INT8U  conv422_fifo_path;	
}conv422_args_t;

conv422_args_t gConv422Args = {0};

//+++ scale up
typedef struct scale_up_args_s
{
	INT32U scaler_buffer_A;
	INT32U scaler_buffer_B;
	INT32U scaler_buffer_size;
	INT32U (*scaler_ready_notify)(INT32U fifoMsg, INT32U fifoAddrs);
	INT8U  scaler_buffer_idx;
	INT8U  scaler_1st_buffer_notify;
	INT8U  scaler_buffer_remaining_idx;
	INT8U  scaler_engine_status;
}scale_up_args_t;

scale_up_args_t gScalupArgs = {0};

//+++ sensor
sensor_apis_ops* pSensorApiOps = NULL;

INT8U lastFIFOIdx = 0;
INT8U showOnTVFlag;

extern INT32U scaler_stopped_timer;
extern INT32U sensor_error_power_off_timer;
extern INT32U cdsp_overflow_count;
extern INT32U display_isr_queue[];
extern INT8U FIFO_LINE_LN;

static void sensor_display_update(void);

#if DUAL_SENSOR_FUNC_ENABLE

back_sensor_args_t gBackSensorRecArgs;
INT8U BackSensorStartRecFlag = 0;
static volatile INT8U wantToStopBackPreviewFlag = 0;

INT8U Video_Rec_Target;
INT8U Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_ALL_DUMMY;
INT8U Back_Sensor_Do_Init_Flag = 0;
INT32U Back_Sensor_Display_Width;
INT32U Back_Sensor_Display_Height;
volatile INT8U Back_Sensor_Skip_Frame_Count;

INT32U PIP_Width;
INT32U PIP_Height;
INT32U Display_PIP_Yoffset =0;

typedef struct PIP_Ready_Buf_Arg_s
{
	INT32U PIP_Ready_Buf_Addrs;
	INT8U  PIP_Ready_Buf_Update_Flag;	
}PIP_Ready_Buf_Arg_t;

#define PIP_RDY_BUF_CNT		DISPLAY_BUF_NUM_MAX
PIP_Ready_Buf_Arg_t PIP_Rdy_Buf[PIP_RDY_BUF_CNT];
INT8U PIP_Rdy_Buf_W_Idx;
INT8U PIP_Rdy_Buf_R_Idx;
INT8U PIP_Rdy_Buf_Count = PIP_RDY_BUF_CNT;
INT8U BackSensorSkipFrameFlag = 0;
extern INT8U Scale_Run_Status_Flag;
extern INT8U BackSensorScaleQArray_R_Idx;
extern INT32U Back_Sensor_fifo_ready_notify_callback(INT32U fifoSrc,INT32U fifoMsg, INT32U fifoAddrs, INT32U fifoIdx);
extern INT32U BackSensorScaleQArray[CSI_FIFO_Q_MAX_CNT];
extern INT32U Back_Sensor_Scale_Up_Jpeg_Adrrs;
extern INT8U  Back_Sensor_Stop_Flag;

#endif

#if DUAL_SENSOR_FUNC_ENABLE
/****************************************************************************/
/*
 *	PIP_Rdy_Buf_clear:
 */
void PIP_Rdy_Buf_clear(void)
{
	INT8U i;

	/*
		�����Ҧ�,�N�s�bPIP_Rdy_Buf ��display Address �٦^�h
	*/

	PIP_Rdy_Buf_R_Idx = 0;
	PIP_Rdy_Buf_W_Idx = 0;

	for(i=0; i<PIP_RDY_BUF_CNT; i++)
	{
		if(PIP_Rdy_Buf[i].PIP_Ready_Buf_Update_Flag)
		{
			if((PIP_Rdy_Buf[i].PIP_Ready_Buf_Addrs != 0) && (PIP_Rdy_Buf[i].PIP_Ready_Buf_Addrs != DUMMY_BUFFER_ADDRS))
			{
				ap_display_queue_put(display_isr_queue, PIP_Rdy_Buf[i].PIP_Ready_Buf_Addrs);
			}
		}

		PIP_Rdy_Buf[i].PIP_Ready_Buf_Addrs = DUMMY_BUFFER_ADDRS;
		PIP_Rdy_Buf[i].PIP_Ready_Buf_Update_Flag = 0;
	}

	/*
		����Display Mode ���i��b Scaler 0 ISR �� Scaler 1 ISR �����o��
		�ҥH�٦^display Buffer �]��dummy ,���o�i�e��
	*/
	if((gBackSensorRecArgs.display_buffer_addrs != 0) && (gBackSensorRecArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS))
	{
		ap_display_queue_put(display_isr_queue, gBackSensorRecArgs.display_buffer_addrs);
	}

	if((gGpreviewArgs.display_buffer_addrs != 0) && (gGpreviewArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS))
	{
		ap_display_queue_put(display_isr_queue, gGpreviewArgs.display_buffer_addrs);
	}

	gBackSensorRecArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
	gGpreviewArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;	
}

/****************************************************************************/
/*
 *	ap_disply_mode_set:
 */
void ap_disply_mode_set(INT8U dispMode)
{
	OS_CPU_SR cpu_sr;

	OS_ENTER_CRITICAL();

	PIP_Rdy_Buf_clear();

	switch(dispMode)
	{
		case 1: // PIP: Front base
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE;		
		break;
		
		case 2: // PIP: Back base
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE;		
		break;
		
		case 3: // PBP
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_PBP;		
		break;
		
		case 4: // Back
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_BACK;		
		break;

		case 5: // Front
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_FRONT;		
		break;

		case 6: // Front & Back In Dummy
			Dual_Sensor_Display_Mode_Flag = DUAL_SENSOR_DISPLAY_MODE_ALL_DUMMY;
		break;
		
	}

	OS_EXIT_CRITICAL();
	
}

/****************************************************************************/
/*
 *	PIP_Rdy_Buf_Set:
 */
void PIP_Rdy_Buf_Set(INT32U BufSet)
{
	OS_CPU_SR cpu_sr;

	if(BufSet == DUMMY_BUFFER_ADDRS)
	{
		return;
	}

	OS_ENTER_CRITICAL();

	if(	PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Update_Flag)
	{
//		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("[Warning] Get Buf Slowly \r\n");
		if((PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Addrs != 0) && (PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Addrs != DUMMY_BUFFER_ADDRS))
		{
			ap_display_queue_put(display_isr_queue, PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Addrs);
		}
	}

	PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Addrs = BufSet;
	PIP_Rdy_Buf[PIP_Rdy_Buf_W_Idx].PIP_Ready_Buf_Update_Flag = 1;
	
	PIP_Rdy_Buf_W_Idx++;
	
	if(PIP_Rdy_Buf_W_Idx >= PIP_Rdy_Buf_Count)
	{
		PIP_Rdy_Buf_W_Idx = 0;
	}	

	OS_EXIT_CRITICAL();
	
}

/****************************************************************************/
/*
 *	PIP_Rdy_Buf_get:
 */
INT32U PIP_Rdy_Buf_get(void)
{
	INT32U RetAddrs;
	OS_CPU_SR cpu_sr;

	OS_ENTER_CRITICAL();
	
	RetAddrs = DUMMY_BUFFER_ADDRS;
	
	if(PIP_Rdy_Buf[PIP_Rdy_Buf_R_Idx].PIP_Ready_Buf_Update_Flag)
	{
		RetAddrs = PIP_Rdy_Buf[PIP_Rdy_Buf_R_Idx].PIP_Ready_Buf_Addrs;
		PIP_Rdy_Buf[PIP_Rdy_Buf_R_Idx].PIP_Ready_Buf_Update_Flag = 0;
		PIP_Rdy_Buf_R_Idx++;
		
		if(PIP_Rdy_Buf_R_Idx >= PIP_Rdy_Buf_Count)
		{
			PIP_Rdy_Buf_R_Idx = 0;
		}	
	}

	OS_EXIT_CRITICAL();
	
	return RetAddrs;	
}

#endif

/****************************************************************************/
/*
 *	cdsp_overflow_isr_func:
 */
void cdsp_overflow_isr_func(void)
{
	if(PreviewInitDone == 0) return;

    (*((volatile INT32U *) 0xC0130004)) = (0xFF<<16);

	scaler_stop(SCALER_0);
	#if USE_BYPASS_SCALER1_PATH
	scaler_isr_done_flag = 0;
	#else
	scaler_stop(SCALER_1);
	#endif

	if(PreviewIsStopped) {
		return;
	}

	cdsp_overflow_count++;

	protect_recover_flag = 1;
	protect_recover_cnt = 0;

	wrap_filter_flush(WRAP_CSIMUX);
	wrap_filter_flush(WRAP_CSI2SCA);

	#if USE_BYPASS_SCALER1_PATH
	scaler_isr_done_flag = 0;
	#else
	scaler_restart(SCALER_1);
	#endif	

	scaler_restart(SCALER_0);
}

#if USE_BYPASS_SCALER1_PATH	
/****************************************************************************/
/*
 *	cdsp_do_flush_callback_func:
 */
void cdsp_do_flush_callback_func(void)
{	
	if(scaler_isr_done_flag)
	{
		scaler_isr_done_flag = 0;

		if(videoRecordFlag == VIDEO_RECORD_RECING)
		{
			wrap_path_set(WRAP_CSI2SCA,1,1);
		}

		wrap_filter_flush(WRAP_CSIMUX);
		wrap_filter_flush(WRAP_CSI2SCA);
		scaler_restart(SCALER_0);
		//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("+");
		
	}

	//wwj test
  	//gpio_write_io(IO_A15, !gpio_read_io(IO_A15));
}
#endif

/****************************************************************************/
/*
 *	conv422_isr_func:
 */
void conv422_isr_func(void)
{
	INT32U buf_A_B;
	INT32U buf_addrs;
	INT32U date_stamp_flag;
	INT32U date_stamp_msg;
	#if (Enable_Lane_Departure_Warning_System)
	INT32U ldws_enable_flag;	
	#endif	

	buf_A_B = conv422_idle_buf_get(0);

	// ����2/3?fifo ���ϕr�g %����FIFO_LINE_LN �{��%
	date_stamp_flag = 0;
	#if (Enable_Lane_Departure_Warning_System)
	ldws_enable_flag = 0;
	#endif
	gConv422Args.conv422_isr_count++;

	if(gConv422Args.conv422_fifo_path == FIFO_PATH_TO_VIDEO_RECORD)
	{
		#if (Enable_Lane_Departure_Warning_System)
		if(LDWS_Enable_Flag)
		{
			if((gConv422Args.conv422_isr_count >= LDWS_start_fifo_idx) &&
			   (gConv422Args.conv422_isr_count < LDWS_end_fifo_idx)
			)
			{
				ldws_enable_flag++;
			}		
		}
		#endif		
	
		if((gConv422Args.conv422_isr_count >= (gConv422Args.conv422_isr_count_max-lastFIFOIdx)) &&
		   (gConv422Args.conv422_isr_count < (gConv422Args.conv422_isr_count_max))
		)
		{
			date_stamp_flag = gConv422Args.conv422_isr_count-(gConv422Args.conv422_isr_count_max-lastFIFOIdx);
			date_stamp_msg = MSG_VIDEO_ENCODE_FIFO_1ST_DATE+(date_stamp_flag*0x00100000);
			date_stamp_flag++; // �@��������?�����M���Д�ʽ
		}
	}
	
	if(buf_A_B == CONV422_IDLE_BUF_A)
	{
		/*
			ȡ��֮ǰBuffer A λ�Â���ȥ,?λ������ʼBuffer A��ַ
			֪ͨ MSG_VIDEO_ENCODE_FIFO_START
		*/
		buf_addrs = conv422_output_A_addr_get();

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// To fix continuously printing "MMMMMMM...."
		if(buf_addrs != fifo_addr_bak0) { //error occur
			buf_addrs = DUMMY_BUFFER_ADDRS;
			#if (Enable_Lane_Departure_Warning_System)
			if(((fifo_addr_bak0 >= 0xF8000000) && (fifo_addr_bak0 < 0xF8040000)) ||
			   ((fifo_addr_bak0 >= USE_SDRAM_SUPPORT_FIFO_ADDRS_START) && (fifo_addr_bak0 < USE_SDRAM_SUPPORT_FIFO_ADDRS_END))
			)
			#endif
			{
				if(fifo_addr_bak0 != DUMMY_BUFFER_ADDRS) {
					gConv422Args.conv422_fifo_buffer_addrs_put(fifo_addr_bak0);
					//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("\r\nR = 0x%x\r\n", fifo_addr_bak0);
				}
			}
		}
		fifo_addr_bak0 = fifo_addr_bak1;
		fifo_addr_bak1 = 0;
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		if(gConv422Args.conv422_fifo_ready_notify)
		{
			if(gConv422Args.conv422_isr_count == 1)
			{
				// ֪ͨjpeg �_ʼ����1?fifo
				(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,MSG_VIDEO_ENCODE_FIFO_START,buf_addrs,gConv422Args.conv422_isr_count);
			}
			else if(gConv422Args.conv422_isr_count > gConv422Args.conv422_isr_count_max)
			{
				if(buf_addrs != DUMMY_BUFFER_ADDRS) {
					gConv422Args.conv422_fifo_buffer_addrs_put(buf_addrs);
				}
			}
			else
			{
				if(date_stamp_flag > 0)
				{	// ֪ͨ�όӿ��Լ���Date Stamp
					(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,date_stamp_msg,buf_addrs,gConv422Args.conv422_isr_count);
				}
				else
				{
					(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,MSG_VIDEO_ENCODE_FIFO_CONTINUE,buf_addrs,gConv422Args.conv422_isr_count);
				}
			}
		}

		if(gConv422Args.conv422_fifo_path == FIFO_PATH_TO_VIDEO_RECORD)
		{
			#if (Enable_Lane_Departure_Warning_System)
			if(ldws_enable_flag > 0)
			{
				gConv422Args.conv422_buffer_next = LDWS_buf_addrs+(LDWS_buf_size*LDWS_buf_addrs_idx);
				LDWS_buf_addrs_idx++;
				if(LDWS_buf_addrs_idx >= LDWS_buf_malloc_cnt)
				{
					LDWS_buf_addrs_idx = 0;
				}
			}
			else
			#endif
			{
				gConv422Args.conv422_buffer_next = gConv422Args.conv422_fifo_buffer_addrs_get();
			}
			conv422_output_A_addr_set(gConv422Args.conv422_buffer_next);

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			fifo_addr_bak1 = gConv422Args.conv422_buffer_next;
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		}
	}

	if(buf_A_B == CONV422_IDLE_BUF_B)
	{
		buf_addrs = conv422_output_B_addr_get();

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// To fix continuously printing "MMMMMMM...."
		if(buf_addrs != fifo_addr_bak0) { //error occur
			buf_addrs = DUMMY_BUFFER_ADDRS;
			#if (Enable_Lane_Departure_Warning_System)
			if(((fifo_addr_bak0 >= 0xF8000000) && (fifo_addr_bak0 < 0xF8040000)) ||
			   ((fifo_addr_bak0 >= USE_SDRAM_SUPPORT_FIFO_ADDRS_START) && (fifo_addr_bak0 < USE_SDRAM_SUPPORT_FIFO_ADDRS_END))
			)
			#endif
			{
				if(fifo_addr_bak0 != DUMMY_BUFFER_ADDRS) {
					gConv422Args.conv422_fifo_buffer_addrs_put(fifo_addr_bak0);
					//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("\r\nR = 0x%x\r\n", fifo_addr_bak0);
				}
			}
		}
		fifo_addr_bak0 = fifo_addr_bak1;
		fifo_addr_bak1 = 0;
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		if(gConv422Args.conv422_fifo_ready_notify)
		{
			if(gConv422Args.conv422_isr_count == 1)
			{
				// ֪ͨjpeg �_ʼ����1?fifo
				(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,MSG_VIDEO_ENCODE_FIFO_START,buf_addrs,gConv422Args.conv422_isr_count);
			}
			else if(gConv422Args.conv422_isr_count > gConv422Args.conv422_isr_count_max)
			{
				if(buf_addrs != DUMMY_BUFFER_ADDRS) {
					gConv422Args.conv422_fifo_buffer_addrs_put(buf_addrs);
				}
			}
			else
			{
				if(date_stamp_flag > 0)
				{	// ֪ͨ�όӿ��Լ���Date Stamp
					(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,date_stamp_msg,buf_addrs,gConv422Args.conv422_isr_count);
				}
				else
				{
					(*gConv422Args.conv422_fifo_ready_notify)(FIFO_SOURCE_FROM_CONV422,MSG_VIDEO_ENCODE_FIFO_CONTINUE,buf_addrs,gConv422Args.conv422_isr_count);
				}
			}
		}

		if(gConv422Args.conv422_fifo_path == FIFO_PATH_TO_VIDEO_RECORD)
		{
			#if (Enable_Lane_Departure_Warning_System)
			if(ldws_enable_flag > 0)
			{
				gConv422Args.conv422_buffer_next = LDWS_buf_addrs+(LDWS_buf_size*LDWS_buf_addrs_idx);
				LDWS_buf_addrs_idx++;
				if(LDWS_buf_addrs_idx >= LDWS_buf_malloc_cnt)
				{
					LDWS_buf_addrs_idx = 0;
				}
			}
			else
			#endif
			{
				gConv422Args.conv422_buffer_next = gConv422Args.conv422_fifo_buffer_addrs_get();
			}
			conv422_output_B_addr_set(gConv422Args.conv422_buffer_next);

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			fifo_addr_bak1 = gConv422Args.conv422_buffer_next;
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		}
	}

	if(conv422_frame_end_check() == STATUS_OK)
	{
		if(gConv422Args.conv422_fifo_ready_notify)
		{
			gConv422Args.conv422_isr_count = 0;
		}

		if((videoRecordFlag == VIDEO_RECORD_STOP) || (videoRecordFlag == VIDEO_RECORD_RECING))
		{
			scaler_stop(SCALER_0);
			
			#if !USE_BYPASS_SCALER1_PATH
			scaler_stop(SCALER_1);
			#endif

			if(gConv422Args.conv422_fifo_path == FIFO_PATH_TO_CAPTURE_PHOTO)
			{
				videoRecordFlag = VIDEO_RECORD_STOP;
				wantToStopPreviewFlag = 1;
				wantToStopBackPreviewFlag = 1;
			}

			if(videoRecordFlag == VIDEO_RECORD_STOP)
			{
				protect_recover_flag = 0;
				protect_recover_cnt = 0;

				/*
					Close csi2sca_wrap's o path
				*/
				wrap_path_set(WRAP_CSI2SCA,1,0);

				// ����conv422to420 protect
				#if USE_BYPASS_SCALER1_PATH
				(*((volatile INT32U *) 0xC0130004)) = (0x5E<<16);
				#else
				(*((volatile INT32U *) 0xC0130004)) = (0x5C<<16);
				#endif

				conv422_fifo_interrupt_enable(0);
				vic_irq_disable(18);

				fifo_addr_bak0 = 0;
				fifo_addr_bak1 = 0;

				videoRecordFlag = VIDEO_RECORD_NOTHING;

				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("V\r\n");
			}
			else //if(videoRecordFlag == VIDEO_RECORD_RECING)
			{
				if(protect_recover_flag) {
					protect_recover_cnt += 1;
					if(protect_recover_cnt > 5) {
						protect_recover_flag = 0;
						protect_recover_cnt = 0;

						// �࿴conv422to420 protect	
						#if USE_BYPASS_SCALER1_PATH
						(*((volatile INT32U *) 0xC0130004)) = ((0x1Eul<<16)|(0xBFul<<24));		
						#else
						(*((volatile INT32U *) 0xC0130004)) = ((0x1Cul<<16)|(0xBFul<<24));		
						#endif
					}
				}
			}

			wrap_filter_flush(WRAP_CSIMUX);
			wrap_filter_flush(WRAP_CSI2SCA);
			
			#if !USE_BYPASS_SCALER1_PATH
			scaler_restart(SCALER_1);
			#endif
			scaler_restart(SCALER_0);
			
		}
	}
}

/****************************************************************************/
/*
 *	zoom_in_out_func:
 */
void zoom_in_out_func(void)
{
	pSensorApiOps->frameRangeClip(&(gZoomArgs.sensor_clip_range));

	if((gZoomArgs.source_width == SENSOR_WIDTH) ||
	   (gZoomArgs.source_width == 960)
	)
	{
		scaler_input_pixels_set(SCALER_1,gZoomArgs.sensor_clip_range.clip_w, gZoomArgs.sensor_clip_range.clip_h);
		scaler_output_pixels_set(SCALER_1,gZoomArgs.scaler_factor_w, gZoomArgs.scaler_factor_h, gZoomArgs.source_width, gZoomArgs.source_height);
	}
}


/****************************************************************************/
/*
 *	sensor_display_update:
 */

/*
	�� Scaler ����� Buffer ���o Display
	DUMMY_BUFFER_ADDRS: ���� queue �� Buffer ����ʹ�� 
*/ 
#if DUAL_SENSOR_FUNC_ENABLE
static void sensor_display_update(void)
{
	if(gGpreviewArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS) // Get display buffer from queue 
	{
		/*
			�u����ܫe���PIP_Back�~�b�o�ᵹDisplay Task, ��L�Ҧ��ѫ���ᵹDisplay Task
		*/
		if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_FRONT)
		{
			(*gGpreviewArgs.display_frame_ready_notify)(gGpreviewArgs.display_buffer_addrs);
			gGpreviewArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS; 
		}
		else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE)
		{
			(*gGpreviewArgs.display_frame_ready_notify)(gGpreviewArgs.display_buffer_addrs);
			gGpreviewArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS; 
		}		
	}

	/*
		��ܫe��e��
	*/
	if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE)
	{		
		gGpreviewArgs.display_buffer_addrs = PIP_Rdy_Buf_get();
	}
	else
	{
		if((Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE) || (Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP))
		{
			/*
				PIP_FRONT �Ҧ� �� PBP �Ҧ�
				Scaler0���NAddress �s�_��,��Scaler1 �X�W�h						
			*/
			PIP_Rdy_Buf_Set(gGpreviewArgs.display_buffer_addrs);
		}
	
		if((Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_BACK) || (Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_ALL_DUMMY)) 
		{
			gGpreviewArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
		}
		else
		{
			gGpreviewArgs.display_buffer_addrs = (*gGpreviewArgs.display_buffer_pointer_get)();
		}
	}

	if((Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_FRONT) || (Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE))
	{
		scaler_output_offset_set(SCALER_0,0);
		scaler_output_pixels_set(SCALER_0,(gGpreviewArgs.clip_width*65536/gGpreviewArgs.display_width), (gGpreviewArgs.clip_height*65536/gGpreviewArgs.display_height), gGpreviewArgs.display_width, gGpreviewArgs.display_height);
		scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs, 0, 0); 
	}
	else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP)
	{
		scaler_output_offset_set(SCALER_0,(gGpreviewArgs.display_width >> 1));
		scaler_output_pixels_set(SCALER_0,(gGpreviewArgs.clip_width*65536/(gGpreviewArgs.display_width>>1)), (gGpreviewArgs.clip_height*65536/gGpreviewArgs.display_height), (gGpreviewArgs.display_width>>1), gGpreviewArgs.display_height);
		scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs, 0, 0); 
	}
	else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE)
	{
		scaler_output_offset_set(SCALER_0,(gGpreviewArgs.display_width-PIP_Width));		
		scaler_output_pixels_set(SCALER_0,(gGpreviewArgs.clip_width*65536/PIP_Width), (gGpreviewArgs.clip_height*65536/PIP_Height), PIP_Width, PIP_Height);
		scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+Display_PIP_Yoffset+((gGpreviewArgs.display_width-PIP_Width)<<1), 0, 0); 
	}
	else // DUAL_SENSOR_DISPLAY_MODE_BACK
	{
		scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs, 0, 0); 
	}

}
#else
static void sensor_display_update(void)
{
	if(gGpreviewArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS) // Get display buffer from queue 
	{
		if(gGpreviewArgs.display_frame_ready_notify)
		{
			if(wantToPreview2DummyFlag) {
				(*gGpreviewArgs.display_buffer_pointer_put)(display_isr_queue, gGpreviewArgs.display_buffer_addrs);
			} else {
				(*gGpreviewArgs.display_frame_ready_notify)(gGpreviewArgs.display_buffer_addrs);
			}
		}
	}

	/*
		ȡ����һ?Display Buffer ���o Scaler
	*/
	if(wantToPreview2DummyFlag) // Preview buffer pass to dummy address when connect to pc
	{
		gGpreviewArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
	}
	else
	{
		gGpreviewArgs.display_buffer_addrs = (*gGpreviewArgs.display_buffer_pointer_get)();
	}

	if(DoBlackEdgeFlag)
	{
		if(showOnTVFlag)
		{
			#if (TV_WIDTH == 640)
			scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+(gGpreviewArgs.display_width*60*2), 0, 0); 
			#else
			scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+(40<<1), 0, 0); 
			#endif
		}
		else
		{
		  #if (USE_PANEL_NAME == PANEL_T27P05_ILI8961)
			scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+(40<<1), 0, 0); 
		  #elif(USE_PANEL_NAME == PANEL_T43)
			scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+(60<<1), 0, 0); 
		  #else
			scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs+(gGpreviewArgs.display_width*30*2), 0, 0); 
		  #endif
		}
	}
	else
	{
		scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs, 0, 0); 
	}

	/*
		Zoom In / Out
	*/
	if(zoomInOutFlag != DO_ZOOM_NOTHING)
	{
		zoom_in_out_func();			
		zoomInOutFlag = DO_ZOOM_NOTHING;
	}
}
#endif

/****************************************************************************/
/*
 *	scaler_isr_func_for_encode
 */
void scaler_isr_func_for_encode(INT32U scaler0_event, INT32U scaler1_event)
{
	#if !USE_BYPASS_SCALER1_PATH	
	if((scaler0_event & C_SCALER_STATUS_DONE) && (scaler1_event & C_SCALER_STATUS_DONE))
	#else
	if(scaler0_event & C_SCALER_STATUS_DONE)
	#endif
	{
		//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("-");

		scaler_stop(SCALER_0);

		#if USE_BYPASS_SCALER1_PATH
		scaler_isr_done_flag = 0;
		#else
		scaler_stop(SCALER_1);
		#endif
		
		if(PreviewIsStopped) return;
		sensor_display_update();

		scaler_stopped_timer = 0;

		if((videoRecordFlag == VIDEO_RECORD_START) || (videoRecordFlag == VIDEO_RECORD_NOTHING))
		{
			/*
				�_��¼Ӱ
			*/
			if(videoRecordFlag == VIDEO_RECORD_START)
			{
				if(protect_recover_flag) {
					protect_recover_cnt += 1;
					if(protect_recover_cnt > 5) {
						protect_recover_flag = 0;
						protect_recover_cnt = 0;
					}
				} else {

					// �࿴conv422to420 protect	
					#if USE_BYPASS_SCALER1_PATH
					(*((volatile INT32U *) 0xC0130004)) = ((0x1Eul<<16)|(0xBFul<<24));		
					#else
					(*((volatile INT32U *) 0xC0130004)) = ((0x1Cul<<16)|(0xBFul<<24));		
					#endif

					/*
						Open csi2sca_wrap's o path
					*/
					#if !USE_BYPASS_SCALER1_PATH
					wrap_path_set(WRAP_CSI2SCA,1,1);
					#endif
					/*
						�ГQ��con422to420 �� flush
					*/
					videoRecordFlag = VIDEO_RECORD_RECING;
					
					OSMboxPost(my_avi_encode_ack_m, (void*)C_ACK_SUCCESS);
				}
			}
			else// if(videoRecordFlag == VIDEO_RECORD_NOTHING)
			{
				if(protect_recover_flag) {
					protect_recover_cnt += 1;
					if(protect_recover_cnt > 5) {
						protect_recover_flag = 0;
						protect_recover_cnt = 0;

						// ����conv422to420 protect
						#if USE_BYPASS_SCALER1_PATH
						(*((volatile INT32U *) 0xC0130004)) = (0x5E<<16);		
						#else
						(*((volatile INT32U *) 0xC0130004)) = (0x5C<<16);		
						#endif
					}
				}

				/*
					�Ȍ���bypass ·�����Psensor
				*/
				else if(wantToStopPreviewFlag == 1)
				{
					//+++
					PIP_Rdy_Buf_clear();
					scaler_output_addr_set(SCALER_0,gGpreviewArgs.display_buffer_addrs, 0, 0);
					//---

					#if !DUAL_SENSOR_FUNC_ENABLE
					(*(volatile INT32U *)(0xD0000084)) &= ~(1<<4);
					#endif
					
					wrap_path_set(WRAP_CSIMUX,0,0);
					wrap_filter_flush(WRAP_CSIMUX);
					wrap_filter_flush(WRAP_CSI2SCA);
					wrap_filter_enable(WRAP_CSIMUX,0);
					wrap_protect_enable(WRAP_CSIMUX,0);
					wrap_filter_enable(WRAP_CSI2SCA,0);
					wantToStopPreviewFlag = 0;
					PreviewIsStopped = 1;	


					return;
				}

			}

			#if USE_BYPASS_SCALER1_PATH
			scaler_isr_done_flag = 1;
			#else
			wrap_filter_flush(WRAP_CSIMUX);
			wrap_filter_flush(WRAP_CSI2SCA);
			scaler_restart(SCALER_1);
			scaler_restart(SCALER_0);
			#endif
		}
	}

	#if DUAL_SENSOR_FUNC_ENABLE
	#if 0
	if(scaler1_event & C_SCALER_STATUS_DONE)
	{
		//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("#");
		
		scaler_stop(SCALER_1);

		Scale_Run_Status_Flag = SCALE_ENGINE_STATUS_IDLE;

		if(gBackSensorRecArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS)
		{
			if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_BACK)
			{
				(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
			}
			else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP)
			{
				(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
			}
			else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE)
			{
				(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
			}
		}
		
		/*
		  ��W��ܫ���~�ۦ��Display Address , ��PBP/PIP�Ҧ��ѫe���Display Address
		*/
		if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_BACK)
		{
			gBackSensorRecArgs.display_buffer_addrs = (*gBackSensorRecArgs.display_buffer_pointer_get)();
			scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs, 0, 0); 
		}
		else
		{

			if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP)
			{
				/*
					PBP �Ҧ�
					Scaler0 Isr �|�� Scaler1 Isr ��, �ҥHScaler0 �����Display Buffer , Scaler1 �򱵥��P�@��Display Buffer
				*/
				gBackSensorRecArgs.display_buffer_addrs = PIP_Rdy_Buf_get();
				scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs+Back_Sensor_Display_Width, 0, 0); 
			}				
			else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE)
			{
				gBackSensorRecArgs.display_buffer_addrs = PIP_Rdy_Buf_get();
				scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs+Back_Sensor_Display_Width, 0, 0); 
			}
			else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE)
			{
				/*
					PIP �Ҧ�
					Scaler1���NAddress �s�_��,��Scaler0 �X�W�h						
				*/
				PIP_Rdy_Buf_Set(gBackSensorRecArgs.display_buffer_addrs);
				
				gBackSensorRecArgs.display_buffer_addrs = (*gBackSensorRecArgs.display_buffer_pointer_get)();
				scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs, 0, 0); 
			}
			else // DUAL_SENSOR_DISPLAY_MODE_FRONT
			{
				gBackSensorRecArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
				scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs, 0, 0); 
			}
		}			
	}
	#else
	if(scaler1_event & C_SCALER_STATUS_DONE)
	{
		//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("#");
		
		scaler_stop(SCALER_1);

		if(Scale_Run_Status_Flag == SCALE_ENGINE_STATUS_DISP)
		{
			// ��ܥ\��
			if(gBackSensorRecArgs.display_buffer_addrs != DUMMY_BUFFER_ADDRS)
			{
				if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_BACK)
				{
					(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
					gBackSensorRecArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
				}
				else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP)
				{
					(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
					gBackSensorRecArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
				}
				else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE)
				{
					(*gBackSensorRecArgs.display_frame_ready_notify)(gBackSensorRecArgs.display_buffer_addrs);
					gBackSensorRecArgs.display_buffer_addrs = DUMMY_BUFFER_ADDRS;
				}
			}

			if ((videoRecordFlag == VIDEO_RECORD_RECING) && (Video_Rec_Target == JPEG_SEND_FOR_RECORD))
			{
				OSQPost(my_AVIEncodeApQ, (void*)MSG_BACK_SENSOR_SCALE_UP_JPEG);
			}
			else
			{
				Scale_Run_Status_Flag = SCALE_ENGINE_STATUS_IDLE;
				BackSensorScaleQArray_R_Idx++;
				if(BackSensorScaleQArray_R_Idx >= CSI_FIFO_Q_MAX_CNT)
				{
					BackSensorScaleQArray_R_Idx = 0;
				}
			}
		}
		else // SCALE_ENGINE_STATUS_JPEG
		{
			Back_Sensor_fifo_ready_notify_callback(FIFO_SOURCE_FROM_CSI,MSG_VIDEO_ENCODE_FIFO_START,Back_Sensor_Scale_Up_Jpeg_Adrrs,0);
		
			Scale_Run_Status_Flag = SCALE_ENGINE_STATUS_IDLE;
			BackSensorScaleQArray_R_Idx++;
			if(BackSensorScaleQArray_R_Idx >= CSI_FIFO_Q_MAX_CNT)
			{
				BackSensorScaleQArray_R_Idx = 0;
			}
		}	
	}
	#endif
	#endif	
}

/****************************************************************************/
/*
 *	video_encode_preview_start
 */
INT32S video_preview_start(preview_args_t* pPreviewArgs)
{
	INT32U clip_width;
	INT32U clip_height;
	INT32U sensor_width;
	INT32U sensor_height;
	INT32U display_width;
	INT32U display_height;
	INT32U display_buffer_addrs;
	INT32U w_factor_scaler0,h_factor_scaler0;
	SCALER_MAS scaler0_mas;
	INT32U dummy_addrs = DUMMY_BUFFER_ADDRS;
	INT32U filter_addrs_size;
	sensor_frame_range_t sensorFrameRange = {0};
	OS_CPU_SR cpu_sr;
	#if !USE_BYPASS_SCALER1_PATH
	SCALER_MAS scaler1_mas;
	INT32U w_factor_scaler1,h_factor_scaler1;
	#endif

	/*
	  �����Oֵ
	*/
	PreviewInitDone = 0;

	OS_ENTER_CRITICAL();
	showOnTVFlag = 0;
	wantToStopPreviewFlag = 0;
	PreviewIsStopped = 1; //for 1st power on
	DoBlackEdgeFlag = 0;
	videoRecordFlag = VIDEO_RECORD_NOTHING;

	//+++
	DateTimeBufUpdate();

	gp_memcpy((INT8S*)&gGpreviewArgs,(INT8S*)pPreviewArgs,sizeof(preview_args_t));
	scaler_init(0);						// Initiate Scaler engine0
	#if !USE_BYPASS_SCALER1_PATH
	scaler_init(1);						// Initiate Scaler engine1
	#endif
	OS_EXIT_CRITICAL();

	clip_width = gGpreviewArgs.clip_width;
	clip_height = gGpreviewArgs.clip_height;
	sensor_width = gGpreviewArgs.sensor_width;
	sensor_height = gGpreviewArgs.sensor_height;
	display_width = gGpreviewArgs.display_width;
	display_height = gGpreviewArgs.display_height; 

	PIP_Rdy_Buf_Count = DISPLAY_BUF_NUM_MAX;

	PIP_Width = PIP_TFT_WIDTH;
	PIP_Height = PIP_TFT_HEIGHT;
    Display_PIP_Yoffset = (TFT_WIDTH*DUAL_SENSOR_DISPLAY_MODE_PIP_YOFFSET)<<2;

	if(display_width > TFT_WIDTH)
	{
		showOnTVFlag = 1;
		PIP_Rdy_Buf_Count = TV_DISPLAY_BUF_NUM;
		PIP_Width = PIP_TV_WIDTH;
		PIP_Height = PIP_TV_HEIGHT;
		Display_PIP_Yoffset = (TV_WIDTH*DUAL_SENSOR_DISPLAY_MODE_PIP_YOFFSET)<<2;
	}

	if(showOnTVFlag) // On TV
	{
		#if (TV_WIDTH == 640)
			switch(sensor_width)
			{
				// 16:9 �n����
				case AVI_WIDTH_720P:
				case AVI_WIDTH_WVGA:
					DoBlackEdgeFlag = 0;
				break;
				// 4:3 �n���k�d����
				case AVI_WIDTH_VGA:
				case AVI_WIDTH_QVGA:
					DoBlackEdgeFlag = 0;
				break;			
				case 960:
					if(gGpreviewArgs.run_ap_mode == STATE_VIDEO_RECORD)
					{
						DoBlackEdgeFlag = 0;						
					}
					else
					{
						DoBlackEdgeFlag = 0;						
					}
				break;				
			}
			
			if(DoBlackEdgeFlag)
			{	
				display_height = 360; // ���F16:9 �����
			}
			else
			{
				display_height = gGpreviewArgs.display_height; 
			}
			/*
				scaler0 ���Y�p���
			*/
			#if USE_BYPASS_SCALER1_PATH
			w_factor_scaler0 = clip_width*65536/display_width;
			#else
			w_factor_scaler0 = sensor_width*65536/display_width;
			#endif

			/*
				scaler0 �u���Y�p,�]����1
			*/
			if(sensor_height == display_height)
			{
				display_height--;
			}

			#if USE_BYPASS_SCALER1_PATH
			h_factor_scaler0 = clip_height*65536/(display_height);			
			#else
			h_factor_scaler0 = sensor_height*65536/(display_height);			
			#endif			
		#else // 720
			switch(sensor_width)
			{
				// 16:9 �n����
				case AVI_WIDTH_720P:
				case AVI_WIDTH_WVGA:
					DoBlackEdgeFlag = 0;
				break;
				// 4:3 �n���k�d����
				case 960:
				case AVI_WIDTH_VGA:
				case AVI_WIDTH_QVGA:
					DoBlackEdgeFlag = 1;
				break;			
			}
			if(DoBlackEdgeFlag)
			{	
				#if USE_BYPASS_SCALER1_PATH
				w_factor_scaler0 = clip_width*65536/640;
				#else
				w_factor_scaler0 = sensor_width*65536/640;
				#endif
			}
			else
			{
				#if USE_BYPASS_SCALER1_PATH
				w_factor_scaler0 = clip_width*65536/720;
				#else
				w_factor_scaler0 = sensor_width*65536/720;
				#endif
			}	

			/*
				scaler0 ���Y�p���
			*/
			#if USE_BYPASS_SCALER1_PATH
			h_factor_scaler0 = clip_height*65536/display_height;
			#else
			h_factor_scaler0 = sensor_height*65536/display_height;
			#endif
		#endif
	}
	else
	{			
	  #if (USE_PANEL_NAME == PANEL_T27P05_ILI8961)
		switch(sensor_width)
		{
			// 16:9 Ҫ�M��
			case AVI_WIDTH_720P:
			case AVI_WIDTH_WVGA:
				DoBlackEdgeFlag = 0;
			break;
			// 4:3 Ҫ��������?
			case 960:
			case AVI_WIDTH_VGA:
			case AVI_WIDTH_QVGA:
				DoBlackEdgeFlag = 1;
			break;			
		}
		if(DoBlackEdgeFlag)
		{	
			#if USE_BYPASS_SCALER1_PATH
			w_factor_scaler0 = clip_width*65536/240;
			#else
			w_factor_scaler0 = sensor_width*65536/240;
			#endif
		}
		else
		{
			#if USE_BYPASS_SCALER1_PATH
			w_factor_scaler0 = clip_width*65536/320;
			#else
			w_factor_scaler0 = sensor_width*65536/320;
			#endif
		}	

		/*
			scaler0 ���sС����
		*/
		#if USE_BYPASS_SCALER1_PATH
		h_factor_scaler0 = clip_height*65536/display_height;
		#else
		h_factor_scaler0 = sensor_height*65536/display_height;
		#endif
	  #elif (USE_PANEL_NAME == PANEL_T43)
		switch(sensor_width)
		{
			// 16:9 Ҫ�M��
			case AVI_WIDTH_720P:
			case AVI_WIDTH_WVGA:
				DoBlackEdgeFlag = 0;
			break;
			// 4:3 Ҫ��������?
			case 960:
			case AVI_WIDTH_VGA:
			case AVI_WIDTH_QVGA:
				DoBlackEdgeFlag = 0;
			break;			
		}
		if(DoBlackEdgeFlag)
		{	
			#if USE_BYPASS_SCALER1_PATH
			w_factor_scaler0 = clip_width*65536/360;
			#else
			w_factor_scaler0 = sensor_width*65536/360;
			#endif
		}
		else
		{
			#if USE_BYPASS_SCALER1_PATH
			w_factor_scaler0 = clip_width*65536/480;
			#else
			w_factor_scaler0 = sensor_width*65536/480;
			#endif
		}	

		/*
			scaler0 ���sС����
		*/
		#if USE_BYPASS_SCALER1_PATH
		h_factor_scaler0 = clip_height*65536/display_height;
		#else
		h_factor_scaler0 = sensor_height*65536/display_height;
		#endif


	  #else
		switch(sensor_width)
		{
			case 960:
			case AVI_WIDTH_VGA:
				DoBlackEdgeFlag = 0;
			break;

			case AVI_WIDTH_720P:
			case AVI_WIDTH_WVGA:
				DoBlackEdgeFlag = 1;
			break;			
		}
		
		if(DoBlackEdgeFlag)
		{	
			display_height = 180; // ����16:9 �ȱ���
		}
		else
		{
			display_height = gGpreviewArgs.display_height; 
		}
		/*
			scaler0 ���sС����
		*/
		#if USE_BYPASS_SCALER1_PATH
		w_factor_scaler0 = clip_width*65536/display_width;
		h_factor_scaler0 = clip_height*65536/display_height;
		#else
		w_factor_scaler0 = sensor_width*65536/display_width;
		h_factor_scaler0 = sensor_height*65536/display_height;
		#endif
	  #endif
	}

	display_buffer_addrs = gGpreviewArgs.display_buffer_addrs;
	filter_addrs_size = gGpreviewArgs.sensor_width*gGpreviewArgs.sensor_height*2;

	DoBlackEdgeFlag = 0;

	/*
		scaler1 ���Ŵ�
	*/
	#if !USE_BYPASS_SCALER1_PATH
	w_factor_scaler1 = clip_width*65536/sensor_width;
	h_factor_scaler1 = clip_height*65536/sensor_height;
	#endif

	/*
	  sensor �Gһ frame ?����,�� csi_mux �� sr path	  
	*/
	if(gGpreviewArgs.sensor_do_init)
	{
		gp_memset((INT8S*)&gZoomArgs,0,sizeof(zoom_args_t));

		cdsp_overflow_count = 0;
		sensor_error_power_off_timer = 0;

		//?��cdsp overflow
		cdsp_overflow_isr_register(cdsp_overflow_isr_func);

		#if USE_BYPASS_SCALER1_PATH	
		cdsp_do_refresh_isr_register(cdsp_do_flush_callback_func);
		#endif
		
		// sensor �³� SENSOR_WIDTH & SENSOR_HEIGHT
		if(pSensorApiOps == NULL)
		{
			pSensorApiOps = sensor_attach();
		}

		pSensorApiOps->switch_pclk(1);


	#if ( (USE_SENSOR_NAME==SENSOR_GC1004)||(USE_SENSOR_NAME==SENSOR_GC1004_MIPI) || (USE_SENSOR_NAME==SENSOR_OV9712))
		sys_ldo28_ctrl(0, LDO_28_33v);	// LDO_2.8 �զ� 3.3v  => ON
	#else
		sys_ldo28_ctrl(0, LDO_28_28v);	// LDO_2.8v => ON
	#endif	

		OSTimeDly(30);

	#if ( (USE_SENSOR_NAME==SENSOR_GC1004)||(USE_SENSOR_NAME==SENSOR_GC1004_MIPI) || (USE_SENSOR_NAME==SENSOR_OV9712))
		sys_ldo28_ctrl(1, LDO_28_33v);	// LDO_2.8 �զ� 3.3v  => ON
	#else
		sys_ldo28_ctrl(1, LDO_28_28v);	// LDO_2.8v => ON
	#endif	

		OSTimeDly(10);

		pSensorApiOps->start(dummy_addrs,0);
	}

	#if (Enable_Lane_Departure_Warning_System)
	if(LDWS_Enable_Flag)
	{
		pSensorApiOps->set_Maxfps(25);

		if(pSensorApiOps->get_fps() != 25)
		{
			sw_i2c_lock();
			OSSchedLock();
			pSensorApiOps->wait4FrameEnd();
			pSensorApiOps->set_fps(25);
			pSensorApiOps->wait4FrameEnd();
			OSSchedUnlock();
			sw_i2c_unlock();
		}
	}
	else
	{
		pSensorApiOps->set_Maxfps(30);

		if(pSensorApiOps->get_fps() != 30)
		{
			sw_i2c_lock();
			OSSchedLock();
			pSensorApiOps->wait4FrameEnd();
			pSensorApiOps->set_fps(30);
			pSensorApiOps->wait4FrameEnd();
			OSSchedUnlock();
			sw_i2c_unlock();
		}
	}
	#endif

	//++ �_��C���sensor frame end
	if((gGpreviewArgs.sensor_width == SENSOR_WIDTH) &&
		(gGpreviewArgs.sensor_height == SENSOR_HEIGHT)
	)
	{
		sensorFrameRange.point_x = (SENSOR_WIDTH-clip_width)>>1;
		sensorFrameRange.point_y = (SENSOR_HEIGHT-clip_height)>>1;

		sensorFrameRange.clip_w = clip_width;
		sensorFrameRange.clip_h = clip_height+4;

		sensorFrameRange.scaledown_w = clip_width;
		sensorFrameRange.scaledown_h = clip_height;

		sensorFrameRange.frame_w = SENSOR_WIDTH;
		sensorFrameRange.frame_h = SENSOR_HEIGHT;
		sensorFrameRange.docropflag = 1;
	}
	else if((gGpreviewArgs.sensor_width == 960) &&
		(gGpreviewArgs.sensor_height == 720)
	)
	{
		sensorFrameRange.point_x = (SENSOR_WIDTH-clip_width)>>1;
		sensorFrameRange.point_y = (SENSOR_HEIGHT-clip_height)>>1;

		sensorFrameRange.clip_w = clip_width;
		sensorFrameRange.clip_h = clip_height+2;

		sensorFrameRange.scaledown_w = clip_width;
		sensorFrameRange.scaledown_h = clip_height;

		sensorFrameRange.frame_w = SENSOR_WIDTH;
		sensorFrameRange.frame_h = SENSOR_HEIGHT;
		sensorFrameRange.docropflag = 1;

	}
	else if((gGpreviewArgs.sensor_width == 848) &&
		(gGpreviewArgs.sensor_height == 480)
	)
	{
		sensorFrameRange.point_x = (SENSOR_WIDTH-1268)>>1;
		sensorFrameRange.point_y = (SENSOR_HEIGHT-720)>>1;
		sensorFrameRange.clip_w = 1268;
		sensorFrameRange.clip_h = 720;
		sensorFrameRange.scaledown_w = gGpreviewArgs.sensor_width;
		sensorFrameRange.scaledown_h = gGpreviewArgs.sensor_height;
		sensorFrameRange.frame_w = 1268;
		sensorFrameRange.frame_h = 720;
		sensorFrameRange.docropflag = 1;
		sensorFrameRange.doscaledownflag = 1;
	}
	else if((gGpreviewArgs.sensor_width == 640) &&
		(gGpreviewArgs.sensor_height == 480)
	)
	{
		sensorFrameRange.point_x = (SENSOR_WIDTH-960)>>1;
		sensorFrameRange.point_y = (SENSOR_HEIGHT-720)>>1;
		sensorFrameRange.clip_w = 960;
		sensorFrameRange.clip_h = 720;
		sensorFrameRange.scaledown_w = gGpreviewArgs.sensor_width;
		sensorFrameRange.scaledown_h = gGpreviewArgs.sensor_height;
		sensorFrameRange.frame_w = 960;
		sensorFrameRange.frame_h = 720;
		sensorFrameRange.docropflag = 1;
		sensorFrameRange.doscaledownflag = 1;
	}
	else if((gGpreviewArgs.sensor_width == 320) &&
		(gGpreviewArgs.sensor_height == 240)
	)
	{
		sensorFrameRange.point_x = (SENSOR_WIDTH-960)>>1;
		sensorFrameRange.point_y = (SENSOR_HEIGHT-720)>>1;
		sensorFrameRange.clip_w = 960;
		sensorFrameRange.clip_h = 720;
		sensorFrameRange.scaledown_w = gGpreviewArgs.sensor_width;
		sensorFrameRange.scaledown_h = gGpreviewArgs.sensor_height;
		sensorFrameRange.frame_w = 960;
		sensorFrameRange.frame_h = 720;
		sensorFrameRange.docropflag = 1;
		sensorFrameRange.doscaledownflag = 1;
	}
		
	OSSchedLock();
	pSensorApiOps->wait4FrameEnd();
	pSensorApiOps->frameRangeClip(&sensorFrameRange);
	pSensorApiOps->wait4FrameEnd();
	OSSchedUnlock();
	//---

	wrap_addr_set(WRAP_CSIMUX,dummy_addrs);
	wrap_filter_addr_set(WRAP_CSIMUX,dummy_addrs,filter_addrs_size);	
	wrap_path_set(WRAP_CSIMUX,0,0);
	wrap_filter_enable(WRAP_CSIMUX,0);

	//+++ protect mechanism
	#if USE_BYPASS_SCALER1_PATH
	(*((volatile INT32U *) 0xC0130004)) = (0x5E<<16);		
	#else
	(*((volatile INT32U *) 0xC0130004)) = (0x5C<<16);		
	#endif
	wrap_protect_enable(WRAP_CSIMUX,0);
	wrap_protect_pixels_set(WRAP_CSIMUX,clip_width,clip_height);
	//---
	
	/*	
		�� csi2sca_wrap �� sr path
	*/	
	wrap_addr_set(WRAP_CSI2SCA,dummy_addrs);
	wrap_path_set(WRAP_CSI2SCA,1,0);
	wrap_filter_enable(WRAP_CSI2SCA,0);

	
	scaler_isr_callback_set(&scaler_isr_func_for_encode);	

	/*
		scaler1
	*/
	#if !USE_BYPASS_SCALER1_PATH	
	gp_memset((INT8S*)&scaler1_mas,0,sizeof(SCALER_MAS));
	scaler1_mas.mas_2 = MAS_EN_READ;
	scaler1_mas.mas_3 = MAS_EN_WRITE;
	scaler_mas_set(SCALER_1,&scaler1_mas);
	
	scaler_input_A_addr_set(SCALER_1,dummy_addrs, 0, 0);
	scaler_fifo_line_set(SCALER_1,C_SCALER_CTRL_FIFO_DISABLE);
	scaler_input_format_set(SCALER_1,C_SCALER_CTRL_IN_UYVY);
	scaler_output_format_set(SCALER_1,C_SCALER_CTRL_OUT_YUYV);
	scaler_input_pixels_set(SCALER_1,clip_width, clip_height);
	scaler_output_pixels_set(SCALER_1,w_factor_scaler1, h_factor_scaler1, sensor_width, sensor_height);
	scaler_output_addr_set(SCALER_1,dummy_addrs, 0, 0); 
	#endif

	/*
		scaler0
	*/
	gp_memset((INT8S*)&scaler0_mas,0,sizeof(SCALER_MAS));
	scaler0_mas.mas_2 = MAS_EN_READ;
	scaler0_mas.mas_0 = MAS_EN_WRITE;
	scaler_mas_set(SCALER_0,&scaler0_mas);

	scaler_input_A_addr_set(SCALER_0,dummy_addrs, 0, 0);
	scaler_fifo_line_set(SCALER_0,C_SCALER_CTRL_FIFO_DISABLE);
	
	#if USE_BYPASS_SCALER1_PATH
	scaler_input_format_set(SCALER_0,C_SCALER_CTRL_IN_UYVY);
	#else
	scaler_input_format_set(SCALER_0,C_SCALER_CTRL_IN_YUYV);
	#endif

	scaler_output_format_set(SCALER_0,C_SCALER_CTRL_OUT_RGB565);

	#if USE_BYPASS_SCALER1_PATH
	scaler_input_pixels_set(SCALER_0,clip_width, clip_height);
	#else
	scaler_input_pixels_set(SCALER_0,sensor_width, sensor_height);
	#endif

	scaler_output_pixels_set(SCALER_0,w_factor_scaler0, h_factor_scaler0, display_width, display_height);
	scaler_out_of_boundary_mode_set(SCALER_0,1);

	if(DoBlackEdgeFlag)
	{
		if(showOnTVFlag)
		{
		  #if (TV_WIDTH == 640)
			scaler_output_addr_set(SCALER_0,(display_buffer_addrs+(display_width*60*2)), 0, 0); 
		  #else
			// ���L�e80Bytes
			scaler_output_addr_set(SCALER_0,(display_buffer_addrs+(40<<1)), 0, 0); 		
		  #endif
		}
		else
		{
		  #if (USE_PANEL_NAME == PANEL_T27P05_ILI8961)
			// ���^ǰ80Bytes
			scaler_output_addr_set(SCALER_0,(display_buffer_addrs+(40<<1)), 0, 0); 		
	  #elif (USE_PANEL_NAME == PANEL_T43)
			scaler_output_addr_set(SCALER_0,(display_buffer_addrs+(60<<1)), 0, 0); 		
		  #else
			// ���L�e30��
			scaler_output_addr_set(SCALER_0,(display_buffer_addrs+(display_width*30*2)), 0, 0); 
		  #endif
		}
	}
	else
	{
		scaler_output_addr_set(SCALER_0,display_buffer_addrs, 0, 0); 
	}

	OSSchedLock();

	pSensorApiOps->wait4FrameEnd();

	#if !DUAL_SENSOR_FUNC_ENABLE
	(*(volatile INT32U *)(0xD0000084)) |= (1<<4);
	#endif

	#if USE_BYPASS_SCALER1_PATH
	wrap_path_set(WRAP_CSIMUX,0,1);
	#else
	wrap_path_set(WRAP_CSIMUX,1,0);
	#endif
	wrap_filter_enable(WRAP_CSIMUX,1);
	wrap_protect_enable(WRAP_CSIMUX,1);
	wrap_filter_enable(WRAP_CSI2SCA,1);

	wrap_filter_flush(WRAP_CSIMUX);
	wrap_filter_flush(WRAP_CSI2SCA);

	#if USE_BYPASS_SCALER1_PATH	
	scaler_isr_done_flag = 0;
	#else
	scaler_start(SCALER_1);
	#endif

	scaler_start(SCALER_0);

	PreviewIsStopped = 0;
	scaler_stopped_timer = 0;
	PreviewInitDone = 1;

	OSSchedUnlock();

	//wait frame end more than 5 times
	pSensorApiOps->wait4FrameEnd();
	pSensorApiOps->wait4FrameEnd();
	pSensorApiOps->wait4FrameEnd();
	pSensorApiOps->wait4FrameEnd();
	pSensorApiOps->wait4FrameEnd();
    return 0;
}

#if DUAL_SENSOR_FUNC_ENABLE
#if CSI_INTERFACE_USE_FIFO
void back_sensor_isr_func(CSI_EVENT_ENUM event, INT32U buffer)
{
	INT32U BackSensorAddrs = DUMMY_BUFFER_ADDRS;
	INT32U date_stamp_msg = MSG_VIDEO_ENCODE_FIFO_START;
	INT32U date_stamp_flag;

	date_stamp_flag = 0;

	if ((event == ENUM_CSI_EVENT_FIFO_FULL) || (event == ENUM_CSI_EVENT_FRAME_END))
	{
		// Send data to encode
		if(BackSensorStartRecFlag)
		{
			if((gBackSensorRecArgs.vid_rec_fifo_idx >= (gBackSensorRecArgs.vid_rec_fifo_max_idx-backlastFIFOIdx)) &&
			   (gBackSensorRecArgs.vid_rec_fifo_idx < (gBackSensorRecArgs.vid_rec_fifo_max_idx))
			)
			{
				date_stamp_flag = gBackSensorRecArgs.vid_rec_fifo_idx-(gBackSensorRecArgs.vid_rec_fifo_max_idx-backlastFIFOIdx);
				date_stamp_msg = MSG_VIDEO_ENCODE_FIFO_1ST_DATE+(date_stamp_flag*0x00100000);
				date_stamp_flag++; // �@��������?�����M���Д�ʽ
			}

			if(date_stamp_flag > 0)
			{	// ֪ͨ�όӿ��Լ���Date Stamp
				(*gBackSensorRecArgs.fifo_ready_notify)(FIFO_SOURCE_FROM_CSI,date_stamp_msg,buffer,gBackSensorRecArgs.vid_rec_fifo_idx);
			}
			else
			{
				(*gBackSensorRecArgs.fifo_ready_notify)(FIFO_SOURCE_FROM_CSI,MSG_VIDEO_ENCODE_FIFO_START,buffer,gBackSensorRecArgs.vid_rec_fifo_idx);
			}

		}
		else
		{			
			if(buffer != DUMMY_BUFFER_ADDRS)
			{
				gBackSensorRecArgs.fifo_buffer_addrs_put(buffer);
			}
		}

		BackSensorAddrs = gBackSensorRecArgs.fifo_buffer_addrs_get();

		if(gBackSensorRecArgs.vid_rec_fifo_idx & 0x01)
		{
			scaler_input_B_addr_set(SCALER_1,buffer, 0, 0);
			drvl1_csi_frame_B_buffer_put(BackSensorAddrs);		  // Sensor output buffer
		}
		else
		{
			scaler_input_A_addr_set(SCALER_1,buffer, 0, 0);
			drvl1_csi_frame_buffer_put(BackSensorAddrs);		  // Sensor output buffer
		}

		//if(wantToBackPreview2DummyFlag == 0)
		{
			if(gBackSensorRecArgs.vid_rec_fifo_idx == 0)
			{
				scaler_start(SCALER_1);
			}
			else
			{
				scaler_restart(SCALER_1);
			}
		}

		if (event == ENUM_CSI_EVENT_FRAME_END)
		{
			gBackSensorRecArgs.vid_rec_fifo_idx = 0;
			
			if((videoRecordFlag == VIDEO_RECORD_RECING) && (Video_Rec_Target == JPEG_SEND_FOR_RECORD))
			{
				BackSensorStartRecFlag = 1;
			}
			else
			{
				BackSensorStartRecFlag = 0;
			}
		}
		else
		{		
			gBackSensorRecArgs.vid_rec_fifo_idx++;			
		}
	}	
}
#else
#if 0
void back_sensor_isr_func(CSI_EVENT_ENUM event, INT32U buffer)
{
	INT32U BackSensorAddrs = DUMMY_BUFFER_ADDRS;

	if (event == ENUM_CSI_EVENT_FRAME_END)
	{	
		// Send data to encode
		if ((videoRecordFlag == VIDEO_RECORD_RECING) && (Video_Rec_Target == JPEG_SEND_FOR_RECORD))
		{
			/*
				��X MSG_VIDEO_ENCODE_FIFO_START ���@�}�l��JPEG
			*/
			(*gBackSensorRecArgs.fifo_ready_notify)(FIFO_SOURCE_FROM_CSI,MSG_VIDEO_ENCODE_FIFO_START,buffer,gBackSensorRecArgs.vid_rec_fifo_idx);
		}
		else
		{			
			if(buffer != DUMMY_BUFFER_ADDRS)
			{
				gBackSensorRecArgs.fifo_buffer_addrs_put(buffer);
			}
		}

		BackSensorAddrs = gBackSensorRecArgs.fifo_buffer_addrs_get();

		/*
			��ܫ���e��
		*/
		if((Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_BACK) || (Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_BACK_BASE))
		{
			scaler_output_offset_set(SCALER_1,0);
			scaler_output_pixels_set(SCALER_1,(BACK_SENSOR_WIDTH*65536/Back_Sensor_Display_Width), (BACK_SENSOR_HEIGHT*65536/Back_Sensor_Display_Height), Back_Sensor_Display_Width, Back_Sensor_Display_Height);
		}
		else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PBP)
		{
			scaler_output_offset_set(SCALER_1,(Back_Sensor_Display_Width>>1));
			scaler_output_pixels_set(SCALER_1,(BACK_SENSOR_WIDTH*65536/(Back_Sensor_Display_Width>>1)), (BACK_SENSOR_HEIGHT*65536/Back_Sensor_Display_Height), (Back_Sensor_Display_Width>>1), Back_Sensor_Display_Height);
		}
		else if(Dual_Sensor_Display_Mode_Flag == DUAL_SENSOR_DISPLAY_MODE_PIP_FRONT_BASE)
		{
			scaler_output_offset_set(SCALER_1,(Back_Sensor_Display_Width>>1));
			scaler_output_pixels_set(SCALER_1,(BACK_SENSOR_WIDTH*65536/(Back_Sensor_Display_Width>>1)), (BACK_SENSOR_HEIGHT*65536/(Back_Sensor_Display_Height>>1)), (Back_Sensor_Display_Width>>1), (Back_Sensor_Display_Height >>1));
		}

		scaler_input_A_addr_set(SCALER_1,buffer, 0, 0);

		if(wantToStopBackPreviewFlag == 0)
		{			
			if(scaler_start(SCALER_1) >= 0)
			{	
				// DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("@");
			}
		}
		else
		{
			drvl1_csi_stop();
			wantToStopBackPreviewFlag = 0;
			//+++
			PIP_Rdy_Buf_clear();
			//---
			return;
		}
		
		drvl1_csi_frame_buffer_put(BackSensorAddrs);		  // Sensor output buffer
	}	
}
#else
void back_sensor_isr_func(CSI_EVENT_ENUM event, INT32U buffer)
{
	INT32U BackSensorAddrs = DUMMY_BUFFER_ADDRS;

	if (event == ENUM_CSI_EVENT_FRAME_END)
	{	
		if(BackSensorSkipFrameFlag & 0x01)
		{
			BackSensorAddrs = gBackSensorRecArgs.fifo_buffer_addrs_get();
		}
		else
		{
			BackSensorAddrs = DUMMY_BUFFER_ADDRS;
		}

		BackSensorSkipFrameFlag ^= 0x01;

		if(buffer != DUMMY_BUFFER_ADDRS)
		{
			if(Back_Sensor_Skip_Frame_Count < 3)
			{
				Back_Sensor_Skip_Frame_Count++;
			}
			else
			{		
				(*gBackSensorRecArgs.fifo_ready_notify)(FIFO_SOURCE_FROM_CSI,MSG_VIDEO_ENCODE_FIFO_START,buffer,gBackSensorRecArgs.vid_rec_fifo_idx);
			}

			gBackSensorRecArgs.fifo_buffer_addrs_put(buffer);
		}

		if(wantToStopBackPreviewFlag == 1)
		{
			drvl1_csi_stop();
			wantToStopBackPreviewFlag = 0;
			Back_Sensor_Stop_Flag = 1;
			//+++
			PIP_Rdy_Buf_clear();
			//---
			return;
		}
		
		drvl1_csi_frame_buffer_put(BackSensorAddrs);		  // Sensor output buffer
	}	
}

#endif
#endif

#if 0
INT32S back_sensor_preview_start(back_sensor_args_t* pBackSensorArgs)
{
	INT32U BackSensorAddrs_A = DUMMY_BUFFER_ADDRS;

	#if CSI_INTERFACE_USE_FIFO
	INT32U BackSensorAddrs_B = DUMMY_BUFFER_ADDRS;
	#endif
	
	SCALER_MAS scaler1_mas;
	INT32U w_factor_scaler1,h_factor_scaler1;

	wantToStopBackPreviewFlag = 0;

	PIP_Rdy_Buf_clear();

	gp_memcpy((INT8S*)&gBackSensorRecArgs,(INT8S*)pBackSensorArgs,sizeof(back_sensor_args_t));

	scaler_init(SCALER_1);						// Initiate Scaler engine1

	scaler_isr_callback_set(&scaler_isr_func_for_encode);	

	gp_memset((INT8S*)&scaler1_mas,0,sizeof(SCALER_MAS));
	scaler1_mas.mas_0 = (MAS_EN_READ|MAS_EN_WRITE);
	scaler_mas_set(SCALER_1,&scaler1_mas);

	w_factor_scaler1 = BACK_SENSOR_WIDTH*65536/Back_Sensor_Display_Width;
	h_factor_scaler1 = BACK_SENSOR_HEIGHT*65536/Back_Sensor_Display_Height;

	scaler_input_A_addr_set(SCALER_1,BackSensorAddrs_A, 0, 0);

	#if CSI_INTERFACE_USE_FIFO
	scaler_input_B_addr_set(SCALER_1,BackSensorAddrs_B, 0, 0);
	scaler_fifo_line_set(SCALER_1,gBackSensorRecArgs.vid_rec_fifo_line_len);
	#else
	scaler_fifo_line_set(SCALER_1,C_SCALER_CTRL_IN_FIFO_DISABLE);
	#endif
	
	scaler_input_format_set(SCALER_1,C_SCALER_CTRL_IN_YUYV);
	scaler_output_format_set(SCALER_1,C_SCALER_CTRL_OUT_RGB565);
	scaler_input_pixels_set(SCALER_1,BACK_SENSOR_WIDTH, BACK_SENSOR_HEIGHT);
	scaler_output_pixels_set(SCALER_1,w_factor_scaler1, h_factor_scaler1, Back_Sensor_Display_Width, Back_Sensor_Display_Height);
	scaler_output_fifo_line_set(SCALER_1,C_SCALER_CTRL_OUT_FIFO_DISABLE);
	scaler_output_addr_set(SCALER_1,gBackSensorRecArgs.display_buffer_addrs, 0, 0); 

	if(Back_Sensor_Do_Init_Flag)
	{
		R_SYSTEM_CTRL |= 0x100;

		if(pSensorApiOps == NULL)
		{
			pSensorApiOps = sensor_attach();
		}
		
		pSensorApiOps->back_sensor_start();
	}

	drvl1_csi_init();
	drvl1_csi_frame_buffer_init();
	BackSensorAddrs_A = gBackSensorRecArgs.fifo_buffer_addrs_get();
	drvl1_csi_frame_buffer_put(BackSensorAddrs_A);		  // Sensor output buffer

	#if CSI_INTERFACE_USE_FIFO
	BackSensorAddrs_B = gBackSensorRecArgs.fifo_buffer_addrs_get();
	drvl1_csi_frame_B_buffer_put(BackSensorAddrs_B);		  // Sensor output buffer
	#endif

	#if 0 // GuanYu Test
	drvl1_csi_input_set(ENUM_CSI_HREF, ENUM_CSI_NON_INTERLACE, 0, ENUM_CSI_IN_YUYV);
	drvl1_csi_input_latch_timing1_set(0, 0, 0, ENUM_CSI_LATCH_DELAY_1_CLOCK);
	drvl1_csi_input_latch_timing2_set(ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE, ENUM_CSI_RISING_EDGE, ENUM_CSI_RISING_EDGE);
	#else
	// TVP5150
	drvl1_csi_input_set(ENUM_CSI_HSYNC_CCIR_656, ENUM_CSI_INTERLACE_INVERT_FIELD, 0, ENUM_CSI_IN_YUYV);
	drvl1_csi_input_latch_timing1_set(0x00, 0x02, 0x02, ENUM_CSI_LATCH_DELAY_3_CLOCK);
	drvl1_csi_input_latch_timing2_set(ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE);
	#endif
	
	drvl1_csi_input_resolution_set(BACK_SENSOR_WIDTH, BACK_SENSOR_HEIGHT);
	drvl1_csi_output_format_set(ENUM_CSI_OUT_YUYV);  

	#if CSI_INTERFACE_USE_FIFO
		switch(gBackSensorRecArgs.vid_rec_fifo_line_len)
		{
			case 16:
			drvl1_csi_output_fifo_set(ENUM_CSI_FIFO_16LINE);
			break;
		}
	#else
		drvl1_csi_output_fifo_set(ENUM_CSI_FIFO_DISABLE);
	#endif
	
	drvl1_csi_start(&back_sensor_isr_func);

    return 0;
}
#else
INT32S back_sensor_preview_start(back_sensor_args_t* pBackSensorArgs)
{
	INT8U timeout=0;
	INT32U BackSensorAddrs_A = DUMMY_BUFFER_ADDRS;

	timeout = 0;
	wantToStopBackPreviewFlag = 0;
	BackSensorSkipFrameFlag = 0;
	Back_Sensor_Skip_Frame_Count = 0;

	PIP_Rdy_Buf_clear();

	gp_memcpy((INT8S*)&gBackSensorRecArgs,(INT8S*)pBackSensorArgs,sizeof(back_sensor_args_t));
	
	if(Back_Sensor_Do_Init_Flag)
	{
		R_SYSTEM_CTRL |= 0x100;

		if(pSensorApiOps == NULL)
		{
			pSensorApiOps = sensor_attach();
		}
		
		pSensorApiOps->back_sensor_start();
	}

	drvl1_csi_init();
	drvl1_csi_frame_buffer_init();
	BackSensorAddrs_A = gBackSensorRecArgs.fifo_buffer_addrs_get();
	drvl1_csi_frame_buffer_put(BackSensorAddrs_A);		  // Sensor output buffer

	// TVP5150
	drvl1_csi_input_set(ENUM_CSI_HSYNC_CCIR_656, ENUM_CSI_NON_INTERLACE, 0, ENUM_CSI_IN_YUYV);
	drvl1_csi_input_latch_timing1_set(0x20, 0x02, 0x02, ENUM_CSI_LATCH_DELAY_3_CLOCK);
	drvl1_csi_input_latch_timing2_set(ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE, ENUM_CSI_FALLING_EDGE);
	
	drvl1_csi_input_resolution_set(BACK_SENSOR_WIDTH, BACK_SENSOR_HEIGHT);
	drvl1_csi_output_format_set(ENUM_CSI_OUT_YUYV);  

	drvl1_csi_output_fifo_set(ENUM_CSI_FIFO_DISABLE);
	drvl1_csi_start(&back_sensor_isr_func);

	while(Back_Sensor_Skip_Frame_Count < 3)
	{
		//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("back sensor frame Waiting...\r\n");
		OSTimeDly(1);
		timeout++;
		if(timeout>50){
			return -1;
		}
	} // Wait for CSI stable image

    return 0;
}

#endif

INT32S video_back_preview_stop(void)
{
	INT32U time_begin, t;

	wantToStopBackPreviewFlag = 1;

	time_begin = OSTimeGet();

	while(wantToStopBackPreviewFlag == 1) 
	{
		t = OSTimeGet();
		if((t - time_begin) > 50) { //500ms

			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Back preview stop wait error!\r\n");
			break;
		}
	}

	wantToStopBackPreviewFlag = 0;
	
	return 0;
}

#endif

/****************************************************************************/
/*
 *	video_preview_stop
 */
INT32S video_preview_stop(INT8U closeSensor)
{
	INT32U time_begin, t;

	wantToStopPreviewFlag = 1;
	if(PreviewIsStopped == 0) {
		time_begin = OSTimeGet();
		while(wantToStopPreviewFlag == 1) {
			t = OSTimeGet();
			if((t - time_begin) > 50) { //500ms

				OSSchedLock();
				pSensorApiOps->wait4FrameEnd();

			    (*((volatile INT32U *) 0xC0130004)) = (0xFF<<16);

				scaler_stop(SCALER_0);
				#if !USE_BYPASS_SCALER1_PATH
				scaler_stop(SCALER_1);
				#endif
	
				#if !DUAL_SENSOR_FUNC_ENABLE
				(*(volatile INT32U *)(0xD0000084)) &= ~(1<<4);
				#endif
				
				wrap_path_set(WRAP_CSIMUX,0,0);
				wrap_filter_flush(WRAP_CSIMUX);
				wrap_filter_flush(WRAP_CSI2SCA);
				wrap_filter_enable(WRAP_CSIMUX,0);
				wrap_protect_enable(WRAP_CSIMUX,0);
				wrap_filter_enable(WRAP_CSI2SCA,0);
				PreviewIsStopped = 1;

				#if USE_BYPASS_SCALER1_PATH
				scaler_isr_done_flag = 0;
				#endif

				OSSchedUnlock();

				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("preview stop wait error!\r\n");
				break;
			}
		}
	}
	wantToStopPreviewFlag = 0;

	// Close sensor
	if(closeSensor)
	{
		pSensorApiOps->stop();
	}
	
	return 0;
}

/****************************************************************************/
/*
 *	sensor_2_dummy_addrs_wait
 */
INT32S sensor_2_dummy_addrs_wait(void)
{
	INT32U time_begin, t;

	time_begin = OSTimeGet();
	while(wantToStopPreviewFlag == 1) {
		t = OSTimeGet();
		if((t - time_begin) > 50) { //500ms
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dummy wait error!\r\n");
			break;
		}
	}

	time_begin = OSTimeGet();
	while(wantToStopBackPreviewFlag == 1) {
		t = OSTimeGet();
		if((t - time_begin) > 50) { //500ms
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("dummy wait error!\r\n");
			break;
		}
	}

	return 0;	
}



/****************************************************************************/
/*
 *	video_preview_zoom_to_zero
 */
void video_preview_zoom_to_zero(void)
{
	gZoomArgs.zoom_step = 0;
}

/****************************************************************************/
/*
 *	video_preview_zoom_setp_get
 */
INT32U video_preview_zoom_setp_get(void)
{
	return gZoomArgs.zoom_step;
}

/****************************************************************************/
/*
 *	video_preview_zoom_in_out:
 *
 *  	zoomInOut: 1: zoom in 0: zoom out
 */
INT32S video_preview_zoom_in_out(INT8U zoomInOut, INT8U zoomIn_zoomOut)
{
	gp_memset((INT8S*)&(gZoomArgs.sensor_clip_range),0,sizeof(sensor_frame_range_t));

	if(zoomIn_zoomOut == 1) // Zoom In
	{
    	if(gZoomArgs.zoom_step < 5)
    	{
        	gZoomArgs.zoom_step++;
    	}
    	else
    	{
    		return 0;
    	}
	}
	else // Zoom Out
	{
		if(gZoomArgs.zoom_step != 0)
		{
    		gZoomArgs.zoom_step--;
    	}	     
    	else
    	{
    		return 0;
    	}    	
	}

	gZoomArgs.source_width = gGpreviewArgs.sensor_width;
	gZoomArgs.source_height = gGpreviewArgs.sensor_height;

	if((gGpreviewArgs.sensor_width == SENSOR_WIDTH) &&
	   (gGpreviewArgs.sensor_height == SENSOR_HEIGHT)
	)
	{
		ZOOM_WIDTH_INTERVAL = 128;
		ZOOM_HEIGHT_INTERVAL = 72;
		gZoomArgs.sensor_clip_range.point_x = ((ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.point_y = ((ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.clip_w = SENSOR_WIDTH - (ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.clip_h = SENSOR_HEIGHT - (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.scaledown_w = gZoomArgs.sensor_clip_range.clip_w;
		gZoomArgs.sensor_clip_range.scaledown_h = gZoomArgs.sensor_clip_range.clip_h;
		gZoomArgs.sensor_clip_range.docropflag = 1;		
		gZoomArgs.sensor_clip_range.doscaledownflag = 0;		

		gZoomArgs.scaler_factor_w = gZoomArgs.sensor_clip_range.clip_w*65536/gZoomArgs.source_width;
		gZoomArgs.scaler_factor_h = gZoomArgs.sensor_clip_range.clip_h*65536/gZoomArgs.source_height;
	
	}
	else if((gGpreviewArgs.sensor_width == 960) &&
	   (gGpreviewArgs.sensor_height == 720)
	)
	{
		ZOOM_WIDTH_INTERVAL = 96;
		ZOOM_HEIGHT_INTERVAL = 72;
		gZoomArgs.sensor_clip_range.point_x = ((SENSOR_WIDTH-960)>>1) + ((ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.point_y = ((ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.clip_w = 960 - (ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.clip_h = 720 - (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.scaledown_w = gZoomArgs.sensor_clip_range.clip_w;
		gZoomArgs.sensor_clip_range.scaledown_h = gZoomArgs.sensor_clip_range.clip_h;
		gZoomArgs.sensor_clip_range.docropflag = 1;		
		gZoomArgs.sensor_clip_range.doscaledownflag = 0;		

		gZoomArgs.scaler_factor_w = gZoomArgs.sensor_clip_range.clip_w*65536/gZoomArgs.source_width;
		gZoomArgs.scaler_factor_h = gZoomArgs.sensor_clip_range.clip_h*65536/gZoomArgs.source_height;
	
	}	
 	else if((gGpreviewArgs.sensor_width == 848) &&
	   (gGpreviewArgs.sensor_height == 480)
	)
	{
		ZOOM_WIDTH_INTERVAL = 84;
		ZOOM_HEIGHT_INTERVAL = 48;

		gZoomArgs.sensor_clip_range.point_x = ((SENSOR_WIDTH-1268)>>1) + ((ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.point_y = (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step)>>1;
		gZoomArgs.sensor_clip_range.clip_w = 1268 - (ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.clip_h = 720 - (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.scaledown_w = gGpreviewArgs.sensor_width;
		gZoomArgs.sensor_clip_range.scaledown_h = gGpreviewArgs.sensor_height;
		gZoomArgs.sensor_clip_range.frame_w = gZoomArgs.sensor_clip_range.clip_w;
		gZoomArgs.sensor_clip_range.frame_h = gZoomArgs.sensor_clip_range.clip_h;
		gZoomArgs.sensor_clip_range.docropflag = 1;		
		gZoomArgs.sensor_clip_range.doscaledownflag = 0;		
		if(gZoomArgs.zoom_step < 5)
		{
			gZoomArgs.sensor_clip_range.doscaledownflag = 1;		
		}
	
	}
 	else if((gGpreviewArgs.sensor_width == 640) &&
	   (gGpreviewArgs.sensor_height == 480)
	)
	{
		ZOOM_WIDTH_INTERVAL = 64;
		ZOOM_HEIGHT_INTERVAL = 48;

		gZoomArgs.sensor_clip_range.point_x = ((SENSOR_WIDTH-960)>>1) + ((ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step)>>1);
		gZoomArgs.sensor_clip_range.point_y = (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step)>>1;
		gZoomArgs.sensor_clip_range.clip_w = 960 - (ZOOM_WIDTH_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.clip_h = 720 - (ZOOM_HEIGHT_INTERVAL*gZoomArgs.zoom_step);
		gZoomArgs.sensor_clip_range.scaledown_w = gGpreviewArgs.sensor_width;
		gZoomArgs.sensor_clip_range.scaledown_h = gGpreviewArgs.sensor_height;
		gZoomArgs.sensor_clip_range.frame_w = gZoomArgs.sensor_clip_range.clip_w;
		gZoomArgs.sensor_clip_range.frame_h = gZoomArgs.sensor_clip_range.clip_h;
		gZoomArgs.sensor_clip_range.docropflag = 1;		
		gZoomArgs.sensor_clip_range.doscaledownflag = 0;		
		if(gZoomArgs.zoom_step < 5)
		{
			gZoomArgs.sensor_clip_range.doscaledownflag = 1;		
		}
	}

	if(zoomInOut) 
	{// zoom in
		zoomInOutFlag = DO_ZOOM_IN;
	}
	else 
	{// zoom out
		zoomInOutFlag = DO_ZOOM_OUT;
	}

	return 0;
}

/****************************************************************************/
/*
 *	sensor_crop_W_H_get:
 *
 */
void sensor_crop_W_H_get(INT32U* pCropWValue,INT32U* pCropHValue)
{
	*pCropWValue = ZOOM_WIDTH_INTERVAL;
	*pCropHValue = ZOOM_HEIGHT_INTERVAL;
}

/****************************************************************************/
/*
 *	video_recording_start:
 *
 */
INT32S video_recording_start(vid_rec_args_t* pVidRecArgs)
{
	Video_Rec_Target = pVidRecArgs->vid_rec_target;

	gConv422Args.conv422_fifo_ready_notify = pVidRecArgs->fifo_ready_notify;
	gConv422Args.conv422_fifo_buffer_addrs_get = pVidRecArgs->fifo_buffer_addrs_get;
	gConv422Args.conv422_fifo_buffer_addrs_put = pVidRecArgs->fifo_buffer_addrs_put;

	// FIFO Mode Setting
	gConv422Args.conv422_fifo_total_count = pVidRecArgs->vid_rec_fifo_total_count;
	gConv422Args.conv422_fifo_line_len = pVidRecArgs->vid_rec_fifo_line_len;

	if(gConv422Args.conv422_fifo_line_len == 16)
	{
		lastFIFOIdx = 3;
	}
	else
	{
		lastFIFOIdx = 2;
	}
	
	gConv422Args.conv422_fifo_path = pVidRecArgs->vid_rec_fifo_path;
	gConv422Args.conv422_fifo_data_size = pVidRecArgs->vid_rec_fifo_data_size;
	gConv422Args.conv422_output_format = pVidRecArgs->vid_rec_fifo_output_format;

	gConv422Args.conv422_buffer_A = gConv422Args.conv422_fifo_buffer_addrs_get();

	if(gConv422Args.conv422_fifo_path == FIFO_PATH_TO_VIDEO_RECORD)
	{
		gConv422Args.conv422_buffer_B = gConv422Args.conv422_fifo_buffer_addrs_get();
	}
	else
	{
		gConv422Args.conv422_buffer_B = gConv422Args.conv422_buffer_A;
	}
	
	// Start recording
	gConv422Args.conv422_isr_count_max = my_pAviEncVidPara->sensor_height/gConv422Args.conv422_fifo_line_len;
	if((my_pAviEncVidPara->sensor_height%gConv422Args.conv422_fifo_line_len) != 0) {
		gConv422Args.conv422_isr_count_max++;
	}
	gConv422Args.conv422_isr_count = 0;

	/*
		Conv_422_to_420 setting
	*/
	vic_irq_register(18,conv422_isr_func);
	vic_irq_enable(18);

	conv422_input_pixels_set(gGpreviewArgs.sensor_width,gGpreviewArgs.sensor_height);
	conv422_fifo_line_set(gConv422Args.conv422_fifo_line_len);
	conv422_output_A_addr_set(gConv422Args.conv422_buffer_A);
	conv422_output_B_addr_set(gConv422Args.conv422_buffer_B);

	fifo_addr_bak0 = gConv422Args.conv422_buffer_A;
	fifo_addr_bak1 = gConv422Args.conv422_buffer_B;

	if(gConv422Args.conv422_output_format == FIFO_FORMAT_422)
	{
		conv422_output_format_set(FORMAT_422);
	}
	else
	{
		conv422_output_format_set(FORMAT_420);
	}

	#if USE_BYPASS_SCALER1_PATH 
	conv422_input_img_format_set(CONV422_INPUT_IMG_FORMAT_UYVY);
	#else
	conv422_input_img_format_set(CONV422_INPUT_IMG_FORMAT_YUYV);
	#endif

	conv422_mode_set(FIFO_MODE);
	conv422_fifo_interrupt_enable(1);
	conv422_clear_set();
	
	videoRecordFlag = VIDEO_RECORD_START;
	return 0;
}

/****************************************************************************/
/*
 *	video_recording_stop_get
 */
INT32U video_recording_stop_get(void)
{
	// BackSensorStartRecFlag = 1 => CSI Recing

	return (((videoRecordFlag == VIDEO_RECORD_NOTHING)?1:0) && ((BackSensorStartRecFlag == 0)?1:0));
}

/****************************************************************************/
/*
 *	video_recording_stop
 */
void video_recording_stop(void)
{
	videoRecordFlag = VIDEO_RECORD_STOP;
}

/****************************************************************************/
/*
 *	avi_enc_stop_flush
 */
void avi_enc_stop_flush(void)
{
	videoRecordFlag = VIDEO_RECORD_NOTHING;
	conv422_fifo_interrupt_enable(0);
	vic_irq_disable(18);
}

/****************************************************************************/
/*
 *	do_scale_up_next_block
 */
void do_scale_up_next_block(void)
{
	// Scaler A/B ����M���������� scaler_restart
	if(gScalupArgs.scaler_buffer_remaining_idx != 0)
	{
		// Scaler engine ?δ���, �^�m����
		if(gScalupArgs.scaler_engine_status != SCALER_ENGINE_STATUS_FINISH) 
		{
			gScalupArgs.scaler_engine_status = SCALER_ENGINE_STATUS_BUSY;
			gScalupArgs.scaler_buffer_idx = !gScalupArgs.scaler_buffer_idx;
			scaler_restart(SCALER_0);
		}
	}
	else
	{   // Scaler A/B Buffer ���M��r
		gScalupArgs.scaler_engine_status = SCALER_ENGINE_STATUS_IDLE;
	}
}
 
/****************************************************************************/
/*
 *	scaler_engine_status_get
 */
INT32U scaler_engine_status_get(void)
{
	return gScalupArgs.scaler_engine_status;
}

/****************************************************************************/
/*
 *	scaler_isr_func_for_capture
 */
void scaler_isr_func_for_capture(INT32U scaler0_event, INT32U scaler1_event)
{

	if(scaler0_event & C_SCALER_STATUS_DONE)
	{
		if(gScalupArgs.scaler_buffer_idx == SCALER_BUFFER_IDX_A)
		{
			(*gScalupArgs.scaler_ready_notify)(MSG_VIDEO_ENCODE_FIFO_END,gScalupArgs.scaler_buffer_A);
		}
		else
		{
			(*gScalupArgs.scaler_ready_notify)(MSG_VIDEO_ENCODE_FIFO_END,gScalupArgs.scaler_buffer_B);					
		}	

		gScalupArgs.scaler_engine_status = SCALER_ENGINE_STATUS_FINISH;
	}
	else if(scaler0_event & C_SCALER_STATUS_OUTPUT_FULL)
	{
		if(gScalupArgs.scaler_buffer_idx == SCALER_BUFFER_IDX_A)
		{
			if(gScalupArgs.scaler_1st_buffer_notify == 0)
			{
				gScalupArgs.scaler_1st_buffer_notify = 1;
				(*gScalupArgs.scaler_ready_notify)(MSG_VIDEO_ENCODE_FIFO_START,gScalupArgs.scaler_buffer_A);
			}
			else
			{
				(*gScalupArgs.scaler_ready_notify)(MSG_VIDEO_ENCODE_FIFO_CONTINUE,gScalupArgs.scaler_buffer_A);
			}
		}
		else // SCALER_BUFFER_IDX_B
		{
			(*gScalupArgs.scaler_ready_notify)(MSG_VIDEO_ENCODE_FIFO_CONTINUE,gScalupArgs.scaler_buffer_B);					
		}

		do_scale_up_next_block();
	}
}

/****************************************************************************/
/*
 *	do_scale_up_stop
 */
void do_scale_up_stop(void)
{
	scaler_stop(SCALER_0);	

	if(gScalupArgs.scaler_buffer_A != 0)
	{
		gp_free((void *)gScalupArgs.scaler_buffer_A);		
	}
}

/****************************************************************************/
/*
 *	do_scale_up_start
 */
void do_scale_up_start(scaler_args_t* pScalerArgs)
{
	SCALER_MAS scaler0_mas;
	INT32U w_factor_scaler0,h_factor_scaler0;

	scaler_init(SCALER_0);
	#if 0 //!TV_DET_ENABLE
	conv420_init(); 
	#endif

	//+++ Parameters
	gScalupArgs.scaler_ready_notify = pScalerArgs->scaler_ready_notify;
	gScalupArgs.scaler_buffer_idx = SCALER_BUFFER_IDX_A;
	gScalupArgs.scaler_1st_buffer_notify = 0;
	gScalupArgs.scaler_buffer_remaining_idx = SCALER_BUFFER_IDX_MAX; // Scaler A/B Buffer

	w_factor_scaler0 = pScalerArgs->scaler_in_width*65536/pScalerArgs->scaler_out_width;
	h_factor_scaler0 = pScalerArgs->scaler_in_height*65536/pScalerArgs->scaler_out_height;

	gScalupArgs.scaler_buffer_size = pScalerArgs->scaler_out_width*SCALER_CTRL_OUT_FIFO_16LINE*2; // C_SCALER_CTRL_OUT_FIFO_16LINE
	gScalupArgs.scaler_buffer_A = pScalerArgs->scaler_out_buffer_addrs;
	gScalupArgs.scaler_buffer_B = gScalupArgs.scaler_buffer_A+gScalupArgs.scaler_buffer_size;

	//+++ conv420_to_422
	#if 0 //!TV_DET_ENABLE
	conv420_reset();
	conv420_path(CONV420_TO_SCALER0);
	conv420_input_A_addr_set(pScalerArgs->scaler_in_buffer_addrs);
	conv420_input_pixels_set(pScalerArgs->scaler_in_width);

	if(pScalerArgs->scaler_input_format == FIFO_FORMAT_422)		
	{
		conv420_convert_enable(0); // conversion disable: source data is 422
	}
	else
	{
		conv420_convert_enable(1); //420 -> 422
	}
	conv420_start();
	#endif

	//+++ Scaler 0
	scaler_isr_callback_set(&scaler_isr_func_for_capture);	

	gp_memset((INT8S*)&scaler0_mas,0,sizeof(SCALER_MAS));
	#if 1 //TV_DET_ENABLE
	scaler0_mas.mas_0 = (MAS_EN_READ|MAS_EN_WRITE);
	#else
	scaler0_mas.mas_1 = MAS_EN_READ;
	scaler0_mas.mas_0 = MAS_EN_WRITE;	
	#endif
	scaler_mas_set(SCALER_0,&scaler0_mas);

	scaler_input_A_addr_set(SCALER_0,pScalerArgs->scaler_in_buffer_addrs, 0, 0);

	#if USE_BYPASS_SCALER1_PATH 
	scaler_input_format_set(SCALER_0,C_SCALER_CTRL_IN_UYVY);
	#else
	scaler_input_format_set(SCALER_0,C_SCALER_CTRL_IN_YUYV);
	#endif
	
	scaler_fifo_line_set(SCALER_0,C_SCALER_CTRL_FIFO_DISABLE);
	scaler_output_format_set(SCALER_0,C_SCALER_CTRL_OUT_YUYV);
	scaler_input_pixels_set(SCALER_0,pScalerArgs->scaler_in_width, pScalerArgs->scaler_in_height);
	scaler_output_pixels_set(SCALER_0,w_factor_scaler0, h_factor_scaler0, pScalerArgs->scaler_out_width, pScalerArgs->scaler_out_height);
	scaler_output_fifo_line_set(SCALER_0,C_SCALER_CTRL_OUT_FIFO_16LINE);
	scaler_output_addr_set(SCALER_0,gScalupArgs.scaler_buffer_A, 0, 0); 

	gScalupArgs.scaler_engine_status = SCALER_ENGINE_STATUS_BUSY;
	scaler_start(SCALER_0);
}

/****************************************************************************/
/*
 *	scale_up_buffer_idx_add : ?jpeg engine ��ɺ��д�func
 */
void scale_up_buffer_idx_add(void)
{
	OS_CPU_SR cpu_sr;

	OS_ENTER_CRITICAL();

	if(gScalupArgs.scaler_buffer_remaining_idx < SCALER_BUFFER_IDX_MAX)
	{
		gScalupArgs.scaler_buffer_remaining_idx++;
	}

	OS_EXIT_CRITICAL();	
}

/****************************************************************************/
/*
 *	scale_up_buffer_idx_decrease : ?scaler engine ��ɺ��д�func
 */
void scale_up_buffer_idx_decrease(void)
{
	OS_CPU_SR cpu_sr;

	OS_ENTER_CRITICAL();

	if(gScalupArgs.scaler_buffer_remaining_idx != 0)
	{
		gScalupArgs.scaler_buffer_remaining_idx--;
	}	

	OS_EXIT_CRITICAL();	
}

/****************************************************************************/
/*
 *	video_preview_buf_to_dummy
 */
void video_preview_buf_to_dummy(INT8U enableValue)
{
	wantToPreview2DummyFlag = enableValue;
}

/****************************************************************************/
/*
 *	enable_black_edge_get
 */
INT32U enable_black_edge_get(void)
{
	return DoBlackEdgeFlag;
}

/****************************************************************************/
/*
 *	cpu_draw_time_osd : 
 */
#if 0 
void cpu_draw_time_osd(TIME_T current_time, INT32U target_buffer, INT8U draw_type, INT8U state,INT32U ImgWidth, INT32U ImgHeight)
{
	INT32S tm1;
	INT16S gap_1, gap_2;
	STRING_INFO str_info = {0};
	INT8U enable_draw_time_flag = 0;
	INT8U year_mon_day_format = 0;

#if 0 // �|�z�Z��FIFO
	if(current_time.tm_year > 2099) {
		current_time.tm_year = 2000;
		cal_time_set(current_time);
	}
#endif
	str_info.language = LCD_EN;

	enable_draw_time_flag = draw_type & 0xF0;
	draw_type &= 0x0F;

	if(((state & 0xF) == (STATE_VIDEO_RECORD & 0xF)) || ((state & 0xF) == (STATE_VIDEO_PREVIEW & 0xF))) {
		gap_1 = 3;
		gap_2 = 20;
		if(draw_type == YUYV_DRAW)
		{
			str_info.font_color = 0xFF80;	//white		//0x5050;	//green
		}
		else // UYVY
		{
			str_info.font_color = 0x80FF;	//white		//0x5050;	//green
		}
		str_info.pos_x = ap_state_resource_time_stamp_position_x_get();

		// Video Recording
		if((state & 0xF) == (STATE_VIDEO_RECORD & 0xF))
		{
			if(ImgHeight == 16)
			{
				// �r��40,�ϥ�3��fifo(16 line)�ӥ[�W�ɶ� 
				if(state & 0x80)
				{	// The last part of date stamp
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 28;
				}
				else if(state & 0x40)
				{	// The 2nd part of date stamp 
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 12;
				}
				else
				{	// The first part of date stamp
					str_info.pos_y = 4;
					str_info.font_offset_h_start = 0;
				}
			}
			else
			{
				// �r��40,�ϥ�2��fifo(32 line)�ӥ[�W�ɶ� 
				if(state & 0x40)
				{	// The 2nd part of date stamp 
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 20;
				}
				else
				{	// The first part of date stamp
					str_info.pos_y = 12;
					str_info.font_offset_h_start = 0;
				}
			}
		} 
		else
		{	// Capture Photo
			if(ImgHeight == AVI_HEIGHT_720P)
			{
				str_info.pos_y = 651;
			}
			else if (ImgHeight == AVI_HEIGHT_WVGA)
			{
				str_info.pos_y = 434;
			}
			else // AVI_HEIGHT_QVGA
			{
				str_info.pos_y = 217;
			}
		}

		str_info.buff_w = ImgWidth;
		str_info.buff_h = ImgHeight; 
		
	} else {
		gap_1 = 2;
		gap_2 = 8;
		str_info.font_color = 0xFFFF;	//white
		str_info.pos_x = ap_state_resource_time_stamp_position_x_get()/2;
		str_info.pos_y = ap_state_resource_time_stamp_position_y_get()/2;
		str_info.buff_w = TFT_WIDTH;
		str_info.buff_h = TFT_HEIGHT;
	}


	year_mon_day_format = ap_state_config_data_time_mode_get();

	switch(year_mon_day_format)
	{
		case 0:  // Y/M/D
		default:
			tm1 = current_time.tm_year/1000;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*1000;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/100;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*100;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_year+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_mon/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mon -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mon+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_mday/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mday -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mday+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_2;		
		break;

		case 1:  // D/M/Y
			tm1 = current_time.tm_mday/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mday -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mday+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;		

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_mon/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mon -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mon+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/1000;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*1000;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/100;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*100;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_year+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_2;
		break;

		case 2:  // M/D/Y
			tm1 = current_time.tm_mon/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mon -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mon+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_mday/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_mday -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_mday+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_1;		

			ap_state_resource_char_draw(0x2F, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  "/"
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/1000;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*1000;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/100;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*100;
			str_info.pos_x += gap_1;

			tm1 = current_time.tm_year/10;
			ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			current_time.tm_year -= tm1*10;
			str_info.pos_x += gap_1;

			ap_state_resource_char_draw(current_time.tm_year+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
			str_info.pos_x += gap_2;
		break;
	}

	if(enable_draw_time_flag == DRAW_DATE_TIME)
	{
		tm1 = current_time.tm_hour/10;
		ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
		current_time.tm_hour -= tm1*10;
		str_info.pos_x += gap_1;

		ap_state_resource_char_draw(current_time.tm_hour+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
		str_info.pos_x += gap_1;

		ap_state_resource_char_draw(0x3A, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  ":"
		str_info.pos_x += gap_1;

		tm1 = current_time.tm_min/10;
		ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
		current_time.tm_min -= tm1*10;
		str_info.pos_x += gap_1;

		ap_state_resource_char_draw(current_time.tm_min+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
		str_info.pos_x += gap_1;

		ap_state_resource_char_draw(0x3A, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);		//  ":"
		str_info.pos_x += gap_1;

		tm1 = current_time.tm_sec/10;
		ap_state_resource_char_draw(tm1+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
		current_time.tm_sec -= tm1*10;
		str_info.pos_x += gap_1;

		ap_state_resource_char_draw(current_time.tm_sec+0x30, (INT16U *) target_buffer, &str_info, draw_type, (state == (STATE_AUDIO_RECORD & 0xF))?2:1);
	}
}
#else
void cpu_draw_time_osd(TIME_T current_time, INT32U target_buffer, INT8U draw_type, INT8U state,INT32U ImgWidth, INT32U ImgHeight)
{
	STRING_INFO str_info = {0};
	INT8U enable_draw_time_flag = 0;

	enable_draw_time_flag = draw_type & 0xF0;
	draw_type &= 0x0F;

	if(((state & 0xF) == (STATE_VIDEO_RECORD & 0xF)) || ((state & 0xF) == (STATE_VIDEO_PREVIEW & 0xF))) 
	{
		if(draw_type == YUYV_DRAW)
		{
			str_info.font_color = 0xFF80;	//white		//0x5050;	//green
		}
		else // UYVY
		{
			str_info.font_color = 0x80FF;	//white		//0x5050;	//green
		}
		str_info.pos_x = ap_state_resource_time_stamp_position_x_get();
		
		// Video Recording
		if((state & 0xF) == (STATE_VIDEO_RECORD & 0xF))
		{
			if(ImgHeight == 16)
			{
				// �r��40,�ϥ�3��fifo(16 line)�ӥ[�W�ɶ� 
				// �r�W��7���ť�,�U���K���ť�
				if(state & 0x80)
				{	// The last part of date stamp
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 28;
					str_info.font_offset_h_width = 4; // �����K���ť�
				}
				else if(state & 0x40)
				{	// The 2nd part of date stamp 
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 12;
					str_info.font_offset_h_width = 16;
				}
				else
				{	// The first part of date stamp
					str_info.pos_y = 11;
					str_info.font_offset_h_start = 7;
					str_info.font_offset_h_width = 5; // ����7���ť�
				}
			}
			else
			{
				// �r��40,�ϥ�2��fifo(32 line)�ӥ[�W�ɶ� 
				if(state & 0x40)
				{	// The 2nd part of date stamp 
					str_info.pos_y = 0;
					str_info.font_offset_h_start = 20;
					str_info.font_offset_h_width = 12; // �����K���ť�
				}
				else
				{	// The first part of date stamp
					str_info.pos_y = 19;
					str_info.font_offset_h_start = 7;
					str_info.font_offset_h_width = 13; // ����7���ť�
				}
			}
		} 
		else
		{	// Capture Photo
			if(ImgHeight == AVI_HEIGHT_720P)
			{
				str_info.pos_y = 651;
			}
			else if (ImgHeight == AVI_HEIGHT_WVGA)
			{
				str_info.pos_y = 434;
			}
			else // AVI_HEIGHT_QVGA
			{
				str_info.pos_y = 217;
			}

			str_info.font_offset_h_start = 0;
			str_info.font_offset_h_width = 40;
		}

		str_info.buff_w = ImgWidth;
		str_info.buff_h = ImgHeight; 	
	}

	DateTimeDraw(target_buffer,str_info,enable_draw_time_flag,draw_type);
}

#endif
//------------------------------------------------------------
/*
	0~9 �e���O 19*40
	/: �e���O 10*40
*/
void DateTimeDraw(INT32U targetBuf,STRING_INFO strInfo,INT32U showTimeStamp,INT8U drawFormat)
{
	INT8U* strDateTimeBuf;
	INT32U strWidth,strHeight;
	INT32U strWidthLoop;
	INT8U  strDateTime;
	INT16U* drawTargetBuf = (INT16U*)0xF8500000;
	INT32U startWidth;
	INT32U startHeight;
	INT32U targetBufWidth;
	INT32U jumpByteAddrs;
	INT32U startHeightStart;
	INT32U startHeightEnd;
	INT8U* drawTargetBufByte = (INT8U*)0xF8500000;
	INT32U oddOffsetByteCount;
	INT32U evenOffsetByteCount;
	INT32U width15Size;


	startWidth = strInfo.pos_x;
	startHeight = strInfo.pos_y;
	targetBufWidth = strInfo.buff_w;
	startHeightStart = strInfo.font_offset_h_start;
	startHeightEnd = strInfo.font_offset_h_width;

	if(showTimeStamp == DRAW_DATE_TIME)
	{
		strWidthLoop = DateTimeStampBufWidth;
	}
	else // �ɶ��b�� 24Byte ��
	{
		strWidthLoop = 24;		
	}

	jumpByteAddrs = (DateTimeStampBufWidth-strWidthLoop);

	strDateTimeBuf = (DateTimeStampBuf+(startHeightStart*DateTimeStampBufWidth));

	if(drawFormat == YUV420_DRAW)
	{
		oddOffsetByteCount = ((startHeight*targetBufWidth*3>>1) + (targetBufWidth<<1) + startWidth);
		evenOffsetByteCount = ((startHeight*targetBufWidth*3>>1) + startWidth);
		width15Size = ((targetBufWidth*3)>>1);
	
		for(strHeight=0; strHeight<startHeightEnd; strHeight++)
		{
			if((startHeight+strHeight) & 0x01)
			{
				drawTargetBufByte = (((INT8U*)targetBuf)+(((strHeight-1)*width15Size) + oddOffsetByteCount));
			}
			else
			{
				drawTargetBufByte = (((INT8U*)targetBuf)+((strHeight*width15Size) + evenOffsetByteCount));
			}

			for(strWidth=strWidthLoop; strWidth>0; strWidth--,drawTargetBufByte+=8)
			{
				strDateTime = *(strDateTimeBuf++);
				if(strDateTime == 0)
				{
					continue;
				}

				if(strDateTime & 0xF0)
				{
					if(strDateTime & 0x80)
					{
						*drawTargetBufByte = 0xFF;
					}

					if(strDateTime & 0x40)
					{
						*(drawTargetBufByte+1) = 0xFF;
					}

					if(strDateTime & 0x20)
					{
						*(drawTargetBufByte+2) = 0xFF;
					}
			
					if(strDateTime & 0x10)
					{
						*(drawTargetBufByte+3) = 0xFF;
					}
				}

				if(strDateTime & 0x0F)
				{							
					if(strDateTime & 0x08)
					{
						*(drawTargetBufByte+4) = 0xFF;
					}		
			
					if(strDateTime & 0x04)
					{
						*(drawTargetBufByte+5) = 0xFF;
					}
				
					if(strDateTime & 0x02)
					{
						*(drawTargetBufByte+6) = 0xFF;
					}
					
					if(strDateTime & 0x01)
					{
						*(drawTargetBufByte+7) = 0xFF;
					}
				}
			}
			
			strDateTimeBuf += jumpByteAddrs;	
		}
	}
	else
	{
		evenOffsetByteCount = startWidth+(targetBufWidth*startHeight);

		for(strHeight=0; strHeight<startHeightEnd; strHeight++)
		{
			drawTargetBuf = (((INT16U*)targetBuf)+evenOffsetByteCount+(targetBufWidth*strHeight));

			for(strWidth=strWidthLoop; strWidth>0; strWidth--,drawTargetBuf+=8)
			{
				strDateTime = *(strDateTimeBuf++);
				if(strDateTime == 0)
				{
					continue;
				}

				if(strDateTime & 0xF0)
				{
					if(strDateTime & 0x80)
					{
						*drawTargetBuf = strInfo.font_color;
					}

					if(strDateTime & 0x40)
					{
						*(drawTargetBuf+1) = strInfo.font_color;
					}

					if(strDateTime & 0x20)
					{
						*(drawTargetBuf+2) = strInfo.font_color;
					}
			
					if(strDateTime & 0x10)
					{
						*(drawTargetBuf+3) = strInfo.font_color;
					}
				}

				if(strDateTime & 0x0F)
				{								
					if(strDateTime & 0x08)
					{
						*(drawTargetBuf+4) = strInfo.font_color;
					}		
			
					if(strDateTime & 0x04)
					{
						*(drawTargetBuf+5) = strInfo.font_color;
					}
				
					if(strDateTime & 0x02)
					{
						*(drawTargetBuf+6) = strInfo.font_color;
					}
					
					if(strDateTime & 0x01)
					{
						*(drawTargetBuf+7) = strInfo.font_color;
					}
				}
			}
			
			strDateTimeBuf += jumpByteAddrs;
		}
	}
}

void copybit(INT8U srcByte, INT8U* destByte, INT32U srcBitIdx, INT32U destBitIdx)
{
	if(srcByte & bit(srcBitIdx))
	{
		*destByte |= bit(destBitIdx);
	}
	else
	{
		*destByte &= ~bit(destBitIdx);	
	}
}

void DateTimeStringReplace(INT8U* dateTimeBuf,INT32U strChar,INT32U strWidth,INT32U bitOffset)
{
	INT32U dataOffset;
	INT8U* dataContent;
	INT8U* strTargetBuffer;
	INT32U byteOffsetStart;
	INT32U bitOffsetStart;
	INT32U strWidthIdx,strHeightIdx;
	INT32U strByteWidth;
	INT8U  srcStrData;
	INT8U  destStrData;
	INT8U  needNBitToOneByte;
	
	dataOffset = (INT32U) (number_font_cache_1 + (strChar - 0x2F));
	dataContent = (INT8U *) (((t_FONT_TABLE_STRUCT *) dataOffset)->font_content);

	strByteWidth = (strWidth/8);
	if((strWidth%8)!=0)
	{
		strByteWidth++;
	}

	byteOffsetStart = (bitOffset >> 3);
	bitOffsetStart = (bitOffset & 0x07);

	needNBitToOneByte = 0;

	//����n���L��m
	strTargetBuffer = (INT8U*)(dateTimeBuf+byteOffsetStart);

	for(strHeightIdx=0; strHeightIdx<40; strHeightIdx++)
	{		
		if(bitOffsetStart != 0)
		{
			needNBitToOneByte = (8-bitOffsetStart);
		}
	
		for(strWidthIdx=0; strWidthIdx<strWidth; strWidthIdx++)
		{		
			srcStrData = *(dataContent+(strWidthIdx >> 3)+(strByteWidth*strHeightIdx));

			//�B�z�e���Ѿl��m
			if(needNBitToOneByte != 0)
			{
				destStrData = *(strTargetBuffer+(DateTimeStampBufWidth*strHeightIdx));
			}
			else
			{	
				// �e�����Byte	����			
				if(((bitOffsetStart+strWidthIdx) & 0x07) == 0)
				{	
					// �̫�Byte����\�L�᭱�r�����,�ݭnŪ�X�ӳB�z
					if(((bitOffsetStart+strWidthIdx) >> 3) == (strByteWidth-1))
					{
						destStrData = *(strTargetBuffer+(strByteWidth-1)+(DateTimeStampBufWidth*strHeightIdx));					
					}
					else
					{
						destStrData = 0;
					}
				}			
			}

			// Resource Tool �q����ư_
			copybit(srcStrData,&destStrData,(0x07-(strWidthIdx & 0x07)),(0x07-((bitOffsetStart+strWidthIdx) & 0x07)));
			
			*(strTargetBuffer+((bitOffsetStart+strWidthIdx) >> 3)+(DateTimeStampBufWidth*strHeightIdx)) = destStrData;

			if(needNBitToOneByte != 0)
			{
				needNBitToOneByte--;
			}			
		}	
	}		
}


#if RECORD_DEBUG
extern INT32S target_Y_Q_value;
extern INT32S target_UV_Q_value;
extern INT32U current_VLC_size;
extern INT8U free_buffer_count;
#endif

void DateTimeBufUpdate(void)
{
	TIME_T	current_system_time;
	INT32U  current_tm,dataTime_tm;
	INT32U  storeTime;
	INT8U   current_DateTimeFormatFlag;
	INT8U   repaintFlag;

	repaintFlag = 0;
	cal_time_get(&current_system_time);
	current_DateTimeFormatFlag = ap_state_config_data_time_mode_get(); 

	if((current_DateTimeFormatFlag != DateTimeFormatFlag) || (DateTimeInitFlag == 0))	
	{
		DateTimeInitFlag = 1;
		
  	 	gp_memset((INT8S*)DateTimeStampBuf, 0x00, DateTimeStampBufSize);
		DateTimeFormatFlag = current_DateTimeFormatFlag;
		repaintFlag = 1;

		switch(current_DateTimeFormatFlag)
		{
			// ����ɶ����j�O 1 pixel = 1 bit
			case 0:	// Y/M/D 
			default:
				DateTimeByteOffset.Year_Thousands = 0;
				DateTimeByteOffset.Year_Hundreds = 21;
				DateTimeByteOffset.Year_Tens = 42;
				DateTimeByteOffset.Year_Ones = 63;
				
				DateTimeByteOffset.Forward_Slash_1 = 84;
				DateTimeByteOffset.Month_Tens = 96;
				DateTimeByteOffset.Month_Ones = 117;
				DateTimeByteOffset.Forward_Slash_2 = 138;
				DateTimeByteOffset.Day_Tens = 150;
				DateTimeByteOffset.Day_Ones = 171;
			break;

			case 1: // D/M/Y
				DateTimeByteOffset.Day_Tens = 0;
				DateTimeByteOffset.Day_Ones = 21;
				DateTimeByteOffset.Forward_Slash_1 = 42;
				DateTimeByteOffset.Month_Tens = 54;
				DateTimeByteOffset.Month_Ones = 75;
				DateTimeByteOffset.Forward_Slash_2 = 96;
				DateTimeByteOffset.Year_Thousands = 108;
				DateTimeByteOffset.Year_Hundreds = 129;
				DateTimeByteOffset.Year_Tens = 150;
				DateTimeByteOffset.Year_Ones = 171;
			break;

			case 2: // M/D/Y
				DateTimeByteOffset.Month_Tens = 0;
				DateTimeByteOffset.Month_Ones = 21;
				DateTimeByteOffset.Forward_Slash_1 = 42;
				DateTimeByteOffset.Day_Tens = 54;
				DateTimeByteOffset.Day_Ones = 75;
				DateTimeByteOffset.Forward_Slash_2 = 96;
				DateTimeByteOffset.Year_Thousands = 108;
				DateTimeByteOffset.Year_Hundreds = 129;
				DateTimeByteOffset.Year_Tens = 150;
				DateTimeByteOffset.Year_Ones = 171;
			break;
		}
	}

  #if RECORD_DEBUG
	current_system_time.tm_year = current_VLC_size/1024;
	current_system_time.tm_mon = target_Y_Q_value;
	current_system_time.tm_mday = target_UV_Q_value;
	current_system_time.tm_hour = free_buffer_count;
  #endif

	if((current_system_time.tm_sec != DateTimeStamp.tm_sec) || repaintFlag)
	{
		storeTime = current_system_time.tm_sec;

		//+++
		current_tm = current_system_time.tm_sec/10;
		dataTime_tm = DateTimeStamp.tm_sec/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,318);
		}	
		current_system_time.tm_sec -= current_tm*10;
		DateTimeStamp.tm_sec -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_sec;
		dataTime_tm = DateTimeStamp.tm_sec;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,339);
		}	

		DateTimeStamp.tm_sec = storeTime;
	}

	if((current_system_time.tm_min != DateTimeStamp.tm_min) || repaintFlag)
	{
		storeTime = current_system_time.tm_min;

		//+++
		current_tm = current_system_time.tm_min/10;
		dataTime_tm = DateTimeStamp.tm_min/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,264);
		}	
		current_system_time.tm_min -= current_tm*10;
		DateTimeStamp.tm_min -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_min;
		dataTime_tm = DateTimeStamp.tm_min;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,285);
		}	

		DateTimeStamp.tm_min = storeTime;
	}

	if((current_system_time.tm_hour != DateTimeStamp.tm_hour) || repaintFlag)
	{
		storeTime = current_system_time.tm_hour;

		//+++
		current_tm = current_system_time.tm_hour/10;
		dataTime_tm = DateTimeStamp.tm_hour/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,210);
		}	
		current_system_time.tm_hour -= current_tm*10;
		DateTimeStamp.tm_hour -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_hour;
		dataTime_tm = DateTimeStamp.tm_hour;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,231);
		}	

		DateTimeStamp.tm_hour = storeTime;
	}

	if((current_system_time.tm_mday != DateTimeStamp.tm_mday) || repaintFlag)
	{
		storeTime = current_system_time.tm_mday;

		//+++
		current_tm = current_system_time.tm_mday/10;
		dataTime_tm = DateTimeStamp.tm_mday/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Day_Tens);
		}	
		current_system_time.tm_mday -= current_tm*10;
		DateTimeStamp.tm_mday -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_mday;
		dataTime_tm = DateTimeStamp.tm_mday;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Day_Ones);
		}	

		DateTimeStamp.tm_mday = storeTime;
	}

	if((current_system_time.tm_mon != DateTimeStamp.tm_mon) || repaintFlag)
	{
		storeTime = current_system_time.tm_mon;

		//+++
		current_tm = current_system_time.tm_mon/10;
		dataTime_tm = DateTimeStamp.tm_mon/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Month_Tens);
		}	
		current_system_time.tm_mon -= current_tm*10;
		DateTimeStamp.tm_mon -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_mon;
		dataTime_tm = DateTimeStamp.tm_mon;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Month_Ones);
		}	

		DateTimeStamp.tm_mon = storeTime;
	}
	
	if((current_system_time.tm_year != DateTimeStamp.tm_year) || repaintFlag)
	{
		storeTime = current_system_time.tm_year;

		//+++
		current_tm = current_system_time.tm_year/1000;
		dataTime_tm = DateTimeStamp.tm_year/1000;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Year_Thousands);
		}
		current_system_time.tm_year -= current_tm*1000;
		DateTimeStamp.tm_year -= dataTime_tm*1000;

		//+++
		current_tm = current_system_time.tm_year/100;
		dataTime_tm = DateTimeStamp.tm_year/100;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Year_Hundreds);
		}	
		current_system_time.tm_year -= current_tm*100;
		DateTimeStamp.tm_year -= dataTime_tm*100;

		//+++
		current_tm = current_system_time.tm_year/10;
		dataTime_tm = DateTimeStamp.tm_year/10;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Year_Tens);
		}	
		current_system_time.tm_year -= current_tm*10;
		DateTimeStamp.tm_year -= dataTime_tm*10;

		//+++
		current_tm = current_system_time.tm_year;
		dataTime_tm = DateTimeStamp.tm_year;
		if((current_tm != dataTime_tm) || repaintFlag)
		{
			DateTimeStringReplace(DateTimeStampBuf,(current_tm+0x30),19,DateTimeByteOffset.Year_Ones);
		}	

		DateTimeStamp.tm_year = storeTime;
	}

	if (repaintFlag)
	{
		DateTimeStringReplace(DateTimeStampBuf,0x2F,10,DateTimeByteOffset.Forward_Slash_1); // Forward Slash	
		DateTimeStringReplace(DateTimeStampBuf,0x2F,10,DateTimeByteOffset.Forward_Slash_2); // Forward Slash	
		DateTimeStringReplace(DateTimeStampBuf,0x3A,10,252); // Colon 	
		DateTimeStringReplace(DateTimeStampBuf,0x3A,10,306); // Colon 	
	}		
}


