#include "ap_video_record.h"
#include "ap_state_config.h"
#include "ap_state_handling.h"
#include "avi_encoder_app.h"
#include "application.h"
#include "ap_display.h"
#include "LDWs.h"
#include "ap_peripheral_handling.h"
#include "my_video_codec_callback.h"


STOR_SERV_FILEINFO curr_file_info;
INT8S video_record_sts;
static STR_ICON_EXT resolution_str;
static STR_ICON_EXT park_mode_str;

#if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
	static INT8U cyclic_record_timerid;
	STOR_SERV_FILEINFO next_file_info;
	static CHAR g_cycle_prev_file_path[24];
	static CHAR g_cycle_prev_file_path_b[24];
#endif
#if C_MOTION_DETECTION == CUSTOM_ON
	static INT8U motion_detect_timerid = 0xFF;
//prototype
	void ap_video_record_md_icon_clear_all(void);
	void ap_video_record_md_tick(INT8U *md_tick);
	INT8S ap_video_record_md_active(INT8U *md_tick);
	void ap_video_record_md_disable(void);
	void ap_video_record_md_icon_update(INT8U sts);
#endif
    INT8S g_lock_current_file_flag = 0;
	INT8U g_cycle_record_continuing_flag = 0;

//prototype
void video_calculate_left_recording_time_enable(void);
void video_calculate_left_recording_time_disable(void);

extern void date_time_force_display(INT8U force_en,INT8U postion_flag);
void ap_video_record_show_park_mode(void)
{
	STRING_ASCII_INFO ascii_str;
	ascii_str.font_color = BLUE_COLOR;
	ascii_str.font_type = 0;
	ascii_str.pos_x = 0;
	ascii_str.pos_y = 0;
	ascii_str.str_ptr = "P";
	ascii_str.buff_h = park_mode_str.h = ASCII_draw_char_height;
	ascii_str.buff_w = park_mode_str.w = ASCII_draw_char_width*1;

	if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
		park_mode_str.pos_x = 32*6;
		park_mode_str.pos_y = 2;
	} else { //TV
		park_mode_str.pos_x = 450;
		park_mode_str.pos_y = 30;
	}
	ap_state_handling_ASCII_str_draw(&park_mode_str,&ascii_str);
}

void ap_video_record_clear_park_mode(void)
{
	ap_state_handling_ASCII_str_draw_exit(&park_mode_str,1);
}

void ap_video_record_resolution_display(void)
{
	STRING_ASCII_INFO ascii_str;

	ascii_str.font_color = 0xffff;
	ascii_str.font_type = 0;
	ascii_str.pos_x = 0;
	ascii_str.pos_y = 0;

	if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
		resolution_str.pos_y = 35;
	} else { //TV
		resolution_str.pos_y = 80;
	}
	ascii_str.buff_h = resolution_str.h = ASCII_draw_char_height;
	if(ap_state_config_video_resolution_get() == 0) {
		ascii_str.str_ptr = "1080FHD";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*7;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*7;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*7;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*7;
  		  #endif
		}
	} else if(ap_state_config_video_resolution_get() == 1) {
		ascii_str.str_ptr = "1080P";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*5;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*5;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*5;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*5;
  		  #endif
		}
	} else if(ap_state_config_video_resolution_get() == 2) {
		ascii_str.str_ptr = "720P";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*4;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*4;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*4;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*4;
  		  #endif
		}
	} else if(ap_state_config_video_resolution_get() == 3) {
		ascii_str.str_ptr = "WVGA";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*4;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*4;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*4;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*4;
  		  #endif
		}
	} else if(ap_state_config_video_resolution_get() == 4) {
		ascii_str.str_ptr = "VGA";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*3;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*3;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*3;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*3;
  		  #endif
		}
	} else {
		ascii_str.str_ptr = "QVGA";
		ascii_str.buff_w = resolution_str.w = ASCII_draw_char_width*4;
		if(ap_display_get_device()==DISP_DEV_TFT) { //TFT
			resolution_str.pos_x = TFT_WIDTH-5-ASCII_draw_char_width*4;
		} else { //TV
		  #if TV_WIDTH == 720
			resolution_str.pos_x = TV_WIDTH-40-ASCII_draw_char_width*4;
  		  #elif TV_WIDTH == 640
			resolution_str.pos_x = TV_WIDTH-20-ASCII_draw_char_width*4;
  		  #endif
		}
	}
	ap_state_handling_ASCII_str_draw(&resolution_str,&ascii_str);
}

void ap_video_record_clear_resolution_str(void)
{
	ap_state_handling_ASCII_str_draw_exit(&resolution_str,1);
}

INT8S ap_video_record_init(INT32U state)
{
	//INT8U night_mode;
	INT8U temp;

	OSQPost(DisplayTaskQ, (void *) MSG_DISPLAY_TASK_EFFECT_INIT);
	if(ap_state_config_video_resolution_get() <= 2) {
		date_time_force_display(1, DISPLAY_DATE_TIME_RECORD);
	} else {
		date_time_force_display(1, DISPLAY_DATE_TIME_RECORD2);
	}

	if(ap_state_config_voice_record_switch_get() != 0) {
		ap_state_handling_icon_clear_cmd(ICON_MIC_OFF, NULL, NULL);
	} else {
		ap_state_handling_icon_show_cmd(ICON_MIC_OFF, NULL, NULL);
	}

	ap_video_record_resolution_display();

	temp = ap_state_config_record_time_get();
	if(temp) {
		ap_state_handling_icon_show_cmd(ICON_VIDEO_RECORD_CYC_1MINUTE+temp-1, NULL, NULL);
	}
	
	temp = ap_state_config_park_mode_G_sensor_get();
	if(temp) {
		ap_video_record_show_park_mode();
	}
		
	temp = ap_state_config_ev_get();
	ap_state_handling_icon_show_cmd(ICON_VIDEO_EV6+temp, NULL, NULL);
	gp_cdsp_set_ev_val(temp);	//0:+2, 1:+5/3, 2:+4/3, 3:+1.0, 4:+2/3, 5:+1/3, 6:+0.0, 7:-1/3, 8:-2/3, 9:-1.0, 10:-4/3, 11:-5/3, 12:-2.0 
/*
#if Enable_Lane_Departure_Warning_System == 1
	temp = ap_state_config_LDW_get(LDW_ON_OFF);
	if(temp){
		ap_state_handling_icon_show_cmd(ICON_VIDEO_LDW_SART, NULL, NULL);
	}
#endif
*/

#if C_BATTERY_DETECT == CUSTOM_ON && USE_ADKEY_NO
	ap_state_handling_current_bat_lvl_show();
	ap_state_handling_current_charge_icon_show();
#endif

#if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
	cyclic_record_timerid = 0xFF;
	next_file_info.file_handle = -1;
	next_file_info.file_handle_b = -1;
#if GPS_TXT
	next_file_info.txt_handle = -1;
#endif
#endif

/*	if(ap_state_handling_night_mode_get()) {
		ap_state_handling_icon_show_cmd(ICON_NIGHT_MODE_ENABLED, NULL, NULL);
		ap_state_handling_icon_clear_cmd(ICON_NIGHT_MODE_DISABLED, NULL, NULL);
		night_mode = 1;
		msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_NIGHT_MODE_SET, &night_mode, sizeof(INT8U), MSG_PRI_NORMAL);
	} else {
		ap_state_handling_icon_show_cmd(ICON_NIGHT_MODE_DISABLED, NULL, NULL);
		ap_state_handling_icon_clear_cmd(ICON_NIGHT_MODE_ENABLED, NULL, NULL);
		night_mode = 0;
		msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_NIGHT_MODE_SET, &night_mode, sizeof(INT8U), MSG_PRI_NORMAL);
	}
*/
	g_lock_current_file_flag = 0;
	g_cycle_record_continuing_flag = 0;
	ap_state_handling_icon_clear_cmd(ICON_LOCKED, NULL, NULL);

	if(back_sensor_plug_status_get())
	{
		if(back_a_car_status_get())
		{
			ap_diplay_back_a_car_mode(1);
		}
		else
		{
			ap_diplay_back_a_car_mode(0);
		}
	}
	else
	{
		ap_disply_mode_set(APP_SHOW_FRONT);
		ap_state_config_display_mode_set(1);
		//ap_state_config_display_mode_set(APP_SHOW_FRONT);//BILLY CHANGE

	}
	ap_video_record_sts_set(0);
	if (ap_state_handling_storage_id_get() == NO_STORAGE) {
		ap_state_handling_icon_show_cmd(ICON_VIDEO_RECORD, ICON_INTERNAL_MEMORY, NULL);
		ap_video_record_sts_set(VIDEO_RECORD_UNMOUNT);
		video_calculate_left_recording_time_disable();
#if C_MOTION_DETECTION == CUSTOM_ON
		if (ap_state_config_md_get()) {
			ap_video_record_md_icon_clear_all();
			ap_video_record_md_disable();
			ap_state_config_md_set(0);
		}
#endif
		return STATUS_FAIL;
	} else {
		ap_state_handling_icon_show_cmd(ICON_VIDEO_RECORD, ICON_SD_CARD, NULL);
		ap_video_record_sts_set(~VIDEO_RECORD_UNMOUNT);
		video_calculate_left_recording_time_enable();
#if C_MOTION_DETECTION == CUSTOM_ON
		if (ap_state_config_md_get()) {
			//ap_state_handling_icon_show_cmd(ICON_MD_STS_0, NULL, NULL);
			ap_state_handling_icon_show_cmd(ICON_MOTION_DETECT, NULL, NULL);
			msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_MOTION_DETECT_START, NULL, NULL, MSG_PRI_NORMAL);
			ap_video_record_sts_set(VIDEO_RECORD_MD);
		}
#endif
		return STATUS_OK;
	}
}

void ap_video_record_exit(void)
{
	ap_video_record_clear_resolution_str();
	ap_video_record_clear_park_mode();

	date_time_force_display(0, DISPLAY_DATE_TIME_RECORD);

}

void ap_video_record_sts_set(INT8S sts)
{
	if (sts > 0) {
		video_record_sts |= sts;
	} else {
		video_record_sts &= sts;
	}
}

#if C_MOTION_DETECTION == CUSTOM_ON
void ap_video_record_md_icon_clear_all(void)
{
  #if 0
	OSQPost(DisplayTaskQ, (void *) (MSG_DISPLAY_TASK_ICON_CLEAR | (ICON_MD_STS_0 | (ICON_MD_STS_1<<8) | (ICON_MD_STS_2<<16))));
	OSQPost(DisplayTaskQ, (void *) (MSG_DISPLAY_TASK_ICON_CLEAR | (ICON_MD_STS_3 | (ICON_MD_STS_4<<8) | (ICON_MD_STS_5<<16))));
  #else
    ap_state_handling_icon_clear_cmd(ICON_MOTION_DETECT, NULL, NULL);
  #endif
}
void ap_video_record_md_tick(INT8U *md_tick)
{
	++*md_tick;
	if (*md_tick > MD_STOP_TIME) {
		*md_tick = 0;
		if (motion_detect_timerid != 0xFF) {
			sys_kill_timer(motion_detect_timerid);
			motion_detect_timerid = 0xFF;
		}
		if(ap_video_record_sts_get() & VIDEO_RECORD_MD) {
			if (video_record_sts & VIDEO_RECORD_BUSY) {
				ap_video_record_func_key_active();
			}
			//ap_state_handling_icon_clear_cmd(ICON_MOTION_DETECT_START, NULL, NULL);
	        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Motion detect md_tick Show icon!\r\n");
			ap_state_handling_icon_show_cmd(ICON_MOTION_DETECT, NULL, NULL);
		}
	}
}

INT8S ap_video_record_md_active(INT8U *md_tick)
{
	*md_tick = 0;
	if (video_record_sts & VIDEO_RECORD_UNMOUNT) {
		return STATUS_FAIL;
	}

	if (!(video_record_sts & VIDEO_RECORD_BUSY)) {
		ap_video_record_func_key_active();
		if (motion_detect_timerid == 0xFF) {
			motion_detect_timerid = VIDEO_PREVIEW_TIMER_ID;
			sys_set_timer((void*)msgQSend, (void*)ApQ, MSG_APQ_MOTION_DETECT_TICK, motion_detect_timerid, MOTION_DETECT_CHECK_TIME_INTERVAL);
		}
	}
	return STATUS_OK;
}

void ap_video_record_md_disable(void)
{
	if (motion_detect_timerid != 0xFF) {
		sys_kill_timer(motion_detect_timerid);
		motion_detect_timerid = 0xFF;
	}
	msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_MOTION_DETECT_STOP, NULL, NULL, MSG_PRI_NORMAL);
	ap_video_record_sts_set(~VIDEO_RECORD_MD);
}

void ap_video_record_md_icon_update(INT8U sts)
{
#if 0
	if (ap_state_config_md_get()) {
		OSQPost(DisplayTaskQ, (void *) (MSG_DISPLAY_TASK_MD_ICON_SHOW | (ICON_MD_STS_0 + sts)));
	}
#endif
}

#endif


INT8S ap_video_record_func_key_active(void)
{
	if (video_record_sts & VIDEO_RECORD_BUSY) {

	  #if C_AUTO_DEL_FILE == CUSTOM_ON
		INT8U type = FALSE;
		msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK_SWITCH, &type, sizeof(INT8U), MSG_PRI_URGENT);
	  #endif

        timer_counter_force_display(0);
		ap_state_handling_led_on();
		ap_peripheral_auto_off_force_disable_set(0);
        video_calculate_left_recording_time_enable();
		if (video_encode_stop() != START_OK) {
			close(curr_file_info.file_handle);
			curr_file_info.file_handle = -1;

		  #if GPS_TXT
			close(curr_file_info.txt_handle);
			curr_file_info.txt_handle = -1;
		  #endif

			if(curr_file_info.file_handle_b >= 0) {
				close(curr_file_info.file_handle_b);
				curr_file_info.file_handle_b = -1;
			}

			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video Record Stop Fail\r\n");

		} else {
			if(g_lock_current_file_flag > 0) {
			  #if RENAME_LOCK_FILE
				CHAR temp_file_name[24];
			  #endif

				_setfattr((CHAR *) curr_file_info.file_path_addr, D_RDONLY);
				if(curr_file_info.file_handle_b >= 0) {
					_setfattr((CHAR *) curr_file_info.file_path_addr_b, D_RDONLY);
				}
				g_lock_current_file_flag = 0;

			  #if RENAME_LOCK_FILE
				gp_memcpy((INT8S *)temp_file_name, (INT8S *)curr_file_info.file_path_addr, sizeof(temp_file_name));
				temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'A';
				_rename((char *)curr_file_info.file_path_addr, temp_file_name);
				gp_memcpy((INT8S *)curr_file_info.file_path_addr, (INT8S *)temp_file_name, sizeof(temp_file_name));

				if(curr_file_info.file_handle_b >= 0) {
					gp_memcpy((INT8S *)temp_file_name, (INT8S *)curr_file_info.file_path_addr_b, sizeof(temp_file_name));
					temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'B';
					_rename((char *)curr_file_info.file_path_addr_b, temp_file_name);
					gp_memcpy((INT8S *)curr_file_info.file_path_addr_b, (INT8S *)temp_file_name, sizeof(temp_file_name));
				}
			  #endif
			}
		}

		UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);

	  #if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
		if (cyclic_record_timerid != 0xFF) {
			sys_kill_timer(cyclic_record_timerid);
			cyclic_record_timerid = 0xFF;
		}
	  #endif

		g_lock_current_file_flag = 0;
		g_cycle_record_continuing_flag = 0;
		ap_state_handling_icon_clear_cmd(ICON_REC, ICON_LOCKED, NULL);
		ap_state_handling_icon_clear_cmd(ICON_VIDEO_LDW_SART, NULL, NULL);

		ap_video_record_sts_set(~VIDEO_RECORD_BUSY);
		msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_TIMER_START, NULL, NULL, MSG_PRI_NORMAL);
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video Record Stop\r\n");
		return STATUS_OK;
	} else {
		if ((video_record_sts & VIDEO_RECORD_UNMOUNT) == 0) {
	  #if C_MOTION_DETECTION == CUSTOM_ON
			INT16U temp;

			if (video_record_sts == 0 || video_record_sts == VIDEO_RECORD_MD) {

				ap_video_record_sts_set(VIDEO_RECORD_BUSY + VIDEO_RECORD_WAIT);

				ap_state_handling_str_draw_exit();
				ap_peripheral_auto_off_force_disable_set(1);

				curr_file_info.file_handle = -1;
				curr_file_info.file_handle_b = -1;
			  #if GPS_TXT
				curr_file_info.txt_handle = -1;
			  #endif

			  #if C_MOTION_DETECTION == CUSTOM_ON
			    if (ap_state_config_md_get())
			    {
					//ap_state_handling_icon_show_cmd(ICON_MD_STS_0, NULL, NULL);
					//ap_state_handling_icon_clear_cmd(ICON_MOTION_DETECT, NULL, NULL);
					//ap_state_handling_icon_show_cmd(ICON_MOTION_DETECT_START, NULL, NULL);
			        if (!(video_record_sts & VIDEO_RECORD_MD))
			        {
						msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_MOTION_DETECT_START, NULL, NULL, MSG_PRI_NORMAL);
						ap_video_record_sts_set(VIDEO_RECORD_MD);
					}

			        if (motion_detect_timerid == 0xFF) 
			        {
						motion_detect_timerid = VIDEO_PREVIEW_TIMER_ID;
						sys_set_timer((void*)msgQSend, (void*)ApQ, MSG_APQ_MOTION_DETECT_TICK, motion_detect_timerid, MOTION_DETECT_CHECK_TIME_INTERVAL);
					}
				}
			  #endif

				temp = ap_state_config_record_time_get();
				temp <<= 8;
				temp |= ap_state_config_video_resolution_get();
				msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_VID_REQ, &temp, sizeof(INT16U), MSG_PRI_NORMAL);
				return STATUS_OK;
			}
		} else if (video_record_sts & VIDEO_RECORD_UNMOUNT) {
			if (ap_state_config_md_get()) {
				if(ap_video_record_sts_get() & VIDEO_RECORD_MD) {
					ap_video_record_md_icon_clear_all();
					ap_video_record_md_disable();
			    	ap_state_config_md_set(0);
				} else {
					//ap_state_handling_icon_show_cmd(ICON_MD_STS_0, NULL, NULL);
					//ap_state_handling_icon_clear_cmd(ICON_MOTION_DETECT_START, NULL, NULL);
					//ap_state_handling_icon_show_cmd(ICON_MOTION_DETECT, NULL, NULL);
					msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_MOTION_DETECT_START, NULL, NULL, MSG_PRI_NORMAL);
					ap_video_record_sts_set(VIDEO_RECORD_MD);
				}
			}
			ap_state_handling_str_draw_exit();
			ap_state_handling_str_draw(STR_INSERT_SDC, WARNING_STR_COLOR);
			msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_DISPLAY_PLEASE_INSERT_SDC, NULL, NULL, MSG_PRI_NORMAL);
			ap_peripheral_auto_off_force_disable_set(0);
	  #else
			ap_video_record_sts_set(VIDEO_RECORD_BUSY);
			ap_peripheral_auto_off_force_disable_set(1);
			curr_file_info.file_handle = -1;
			curr_file_info.file_handle_b = -1;
			curr_file_info.index_handle = -1;
			curr_file_info.index_handle_b = -1;
		  #if GPS_TXT
			curr_file_info.txt_handle = -1;
		  #endif
			msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_VID_REQ, NULL, NULL, MSG_PRI_NORMAL);
	  #endif
		}
	}
	return STATUS_OK;
}

#if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
void ap_video_record_cycle_reply_action(STOR_SERV_FILEINFO *file_info_ptr)
{
	MEDIA_SOURCE src;

	ap_video_record_sts_set(~VIDEO_RECORD_WAIT);

	if (file_info_ptr->file_handle >= 0) {
		gp_memcpy((INT8S *) &next_file_info, (INT8S *) file_info_ptr, sizeof(STOR_SERV_FILEINFO));

		if (next_file_info.file_handle >= 0) {
			src.type_ID.FileHandle = next_file_info.file_handle;
			src.type_ID.FileHandle_b = next_file_info.file_handle_b;
			src.type = SOURCE_TYPE_FS;
			src.Format.VideoFormat = MJPEG;

	        timer_counter_force_display(1);

		  #if GPS_TXT
			if(video_encode_fast_stop_and_start(src, next_file_info.txt_handle) != START_OK)
		  #else
			if(video_encode_fast_stop_and_start(src, -1) != START_OK)
		  #endif
			{
				close(src.type_ID.FileHandle);
				next_file_info.file_handle = -1;

				if(next_file_info.file_handle_b >= 0) {
					close(src.type_ID.FileHandle_b);
					next_file_info.file_handle_b = -1;
				}

			  #if GPS_TXT
				close(next_file_info.txt_handle);
				next_file_info.txt_handle = -1;
			  #endif

				g_lock_current_file_flag = 0;
				g_cycle_record_continuing_flag = 0;

				ap_state_handling_icon_clear_cmd(ICON_LOCKED, NULL, NULL);
				ap_state_handling_icon_clear_cmd(ICON_REC, NULL, NULL);
		        timer_counter_force_display(0);

	            ap_video_record_sts_set(~VIDEO_RECORD_BUSY);
	            msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_TIMER_START, NULL, NULL, MSG_PRI_NORMAL);

				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video Record Fail1\r\n");
				return;

			} else {
				if(g_lock_current_file_flag > 0) {
				  #if RENAME_LOCK_FILE
					CHAR temp_file_name[24];
				  #endif

					_setfattr((CHAR *) curr_file_info.file_path_addr, D_RDONLY);
					if(curr_file_info.file_handle_b >= 0) {
						_setfattr((CHAR *) curr_file_info.file_path_addr_b, D_RDONLY);
					}

				  #if RENAME_LOCK_FILE
					gp_memcpy((INT8S *)temp_file_name, (INT8S *)curr_file_info.file_path_addr, sizeof(temp_file_name));
					temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'A';
					_rename((char *)curr_file_info.file_path_addr, temp_file_name);
					gp_memcpy((INT8S *)curr_file_info.file_path_addr, (INT8S *)temp_file_name, sizeof(temp_file_name));

					if(curr_file_info.file_handle_b >= 0) {
						gp_memcpy((INT8S *)temp_file_name, (INT8S *)curr_file_info.file_path_addr_b, sizeof(temp_file_name));
						temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'B';
						_rename((char *)curr_file_info.file_path_addr_b, temp_file_name);
						gp_memcpy((INT8S *)curr_file_info.file_path_addr_b, (INT8S *)temp_file_name, sizeof(temp_file_name));
					}
				  #endif
				}

				g_lock_current_file_flag--;
				if(g_lock_current_file_flag <= 0) {
					g_lock_current_file_flag = 0;
					ap_state_handling_icon_clear_cmd(ICON_LOCKED, NULL, NULL);
	            }

				gp_memcpy((INT8S *)g_cycle_prev_file_path, (INT8S *)curr_file_info.file_path_addr, 24);
				gp_memcpy((INT8S *)g_cycle_prev_file_path_b, (INT8S *)curr_file_info.file_path_addr_b, 24);

				gp_memcpy((INT8S *)curr_file_info.file_path_addr, (INT8S *)next_file_info.file_path_addr, 24);
				gp_memcpy((INT8S *)curr_file_info.file_path_addr_b, (INT8S *)next_file_info.file_path_addr_b, 24);
			  #if GPS_TXT
				gp_memcpy((INT8S *)curr_file_info.txt_path_addr, (INT8S *)next_file_info.txt_path_addr, 24);
			  #endif
				curr_file_info.file_handle = next_file_info.file_handle;
				curr_file_info.file_handle_b = next_file_info.file_handle_b;
			  #if GPS_TXT
				curr_file_info.txt_handle = next_file_info.txt_handle;
			  #endif
			}

			g_cycle_record_continuing_flag = 1;
			ap_state_handling_icon_show_cmd(ICON_REC, NULL, NULL);
			next_file_info.file_handle = -1;
			next_file_info.file_handle_b = -1;
		  #if GPS_TXT
			next_file_info.txt_handle = -1;
		  #endif

		  #if C_AUTO_DEL_FILE == CUSTOM_ON
			if(ap_state_config_record_time_get()) {
				INT8U type = TRUE;
				msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK_SWITCH, &type, sizeof(INT8U), MSG_PRI_NORMAL);
			}
		  #endif
		}
	} else {
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Cyclic video record open file Fail\r\n");
		if(ap_video_record_sts_get() & VIDEO_RECORD_BUSY) {
			ap_video_record_func_key_active();
		}

	    ap_state_handling_str_draw_exit();
	    ap_state_handling_str_draw(STR_SD_FULL, WARNING_STR_COLOR);
        video_calculate_left_recording_time_disable();
	}
}
#endif

INT8U ap_video_record_sts_get(void)
{
	return	video_record_sts;
}

void ap_video_record_reply_action(STOR_SERV_FILEINFO *file_info_ptr)
{
	MEDIA_SOURCE src;

  #if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
	INT32U time_interval, value;
	INT8U temp[6] = {0, 1, 2, 3, 5, 10};

	ap_video_record_sts_set(~VIDEO_RECORD_WAIT);

	value = temp[ap_state_config_record_time_get()];
	if (value == 0) {
		//time_interval = 10 * VIDEO_RECORD_CYCLE_TIME_INTERVAL;
		time_interval = 5 * VIDEO_RECORD_CYCLE_TIME_INTERVAL;
		// FAT32:60min(<4GB), FAT16:30min(<2GB), but FAT16 SDC is always less than 2GB
	} else {
        time_interval = value * VIDEO_RECORD_CYCLE_TIME_INTERVAL;
    }
  #endif

	if (file_info_ptr) {
		gp_memcpy((INT8S *) &curr_file_info, (INT8S *) file_info_ptr, sizeof(STOR_SERV_FILEINFO));
	}

	src.type_ID.FileHandle = curr_file_info.file_handle;
	src.type_ID.FileHandle_b = curr_file_info.file_handle_b;
	src.type = SOURCE_TYPE_FS;
	src.Format.VideoFormat = MJPEG;
	if (src.type_ID.FileHandle >= 0) {
        timer_counter_force_display(1);
		video_calculate_left_recording_time_disable();
        ap_state_handling_icon_show_cmd(ICON_REC, NULL, NULL);
	  #if GPS_TXT
		if (video_encode_start(src, curr_file_info.txt_handle) != START_OK)
	  #else
		if (video_encode_start(src,  -1) != START_OK)
	  #endif
		{
            timer_counter_force_display(0);
	        video_calculate_left_recording_time_enable();
			ap_peripheral_auto_off_force_disable_set(0);
			ap_state_handling_icon_clear_cmd(ICON_REC, NULL, NULL);

			close(src.type_ID.FileHandle);
			curr_file_info.file_handle = -1;

			if(curr_file_info.file_handle_b >= 0) {
				close(src.type_ID.FileHandle_b);
				curr_file_info.file_handle_b = -1;
			}

		  #if GPS_TXT
			close(curr_file_info.txt_handle);
			curr_file_info.txt_handle = -1;
		  #endif

	        ap_video_record_sts_set(~VIDEO_RECORD_BUSY);
			msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_TIMER_START, NULL, NULL, MSG_PRI_NORMAL);
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video Record Fail\r\n");
		} else {

		  #if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
			if (cyclic_record_timerid == 0xFF) {
				cyclic_record_timerid = VIDEO_RECORD_CYCLE_TIMER_ID;
				sys_set_timer((void*)msgQSend, (void*)ApQ, MSG_APQ_CYCLIC_VIDEO_RECORD, cyclic_record_timerid, time_interval);
			}
		  #endif

		  #if C_AUTO_DEL_FILE == CUSTOM_ON
			if(ap_state_config_record_time_get())
			{
				INT8U type = TRUE;
				msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK_SWITCH, &type, sizeof(INT8U), MSG_PRI_NORMAL);
			}
		  #endif
			ap_state_handling_led_blink_on();
		}
	} else {
        ap_video_record_sts_set(~VIDEO_RECORD_BUSY);
		ap_peripheral_auto_off_force_disable_set(0);

	    ap_state_handling_str_draw_exit();
	    ap_state_handling_str_draw(STR_SD_FULL, WARNING_STR_COLOR);
        video_calculate_left_recording_time_disable();

		msgQSend(StorageServiceQ, MSG_STORAGE_SERVICE_TIMER_START, NULL, NULL, MSG_PRI_NORMAL);
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video Record Stop [NO free space]\r\n");
	}
}

#define MB_PER_MIN_BACK		75		//75MB per min

void video_calculate_left_recording_time_enable(void)
{
	static const INT32U temp1[6] = {200, 200, 160, 130, 100, 50};  //1080FHD, 1080P, 720P, WVGA, VGA, QVGA
	static const INT8U temp2[6] = {5, 1, 2, 3, 5, 10};	//unit: minute

	INT64U freespace, left_recording_time;
	INT8U rec_time_config, rec_resolution_config;
	INT32U MB_per_min, avi_file_size_a, avi_file_size_b, file_size_to_create;

	rec_time_config = ap_state_config_record_time_get();
	if(rec_time_config > 5) rec_time_config = 5;

	rec_resolution_config = ap_state_config_video_resolution_get();
	if(rec_resolution_config > 5) rec_resolution_config = 5;

	MB_per_min = temp1[rec_resolution_config];
	avi_file_size_a = temp2[rec_time_config] * MB_per_min;
	avi_file_size_b = temp2[rec_time_config] * MB_PER_MIN_BACK;	//75MB per minute

	if(back_sensor_plug_status_get()) {
		file_size_to_create = avi_file_size_a + avi_file_size_b;
	} else {
		file_size_to_create = avi_file_size_a;
	}
	file_size_to_create <<= 20;

	freespace = vfsFreeSpace(MINI_DVR_STORAGE_TYPE);
	left_recording_time = freespace / file_size_to_create; //number of file
	left_recording_time *= temp2[rec_time_config]; //minutes
	left_recording_time *= 60; //seconds

	OSQPost(DisplayTaskQ, (void *) (MSG_DISPLAY_TASK_LEFT_REC_TIME_DRAW | left_recording_time));
}

void video_calculate_left_recording_time_disable(void)
{	
	OSQPost(DisplayTaskQ, (void *) (MSG_DISPLAY_TASK_LEFT_REC_TIME_CLEAR));
}

extern INT32U ap_display_timer_rec_time_get(void);
void ap_video_record_lock_current_file(void)
{
	INT8U temp[6] = {0, 1, 2, 3, 5, 10};
	INT8U record_config = temp[ap_state_config_record_time_get()];
	INT32U recording_time;
	
	recording_time = ap_display_timer_rec_time_get();
	if((recording_time < 10) && g_cycle_record_continuing_flag) {
	  #if RENAME_LOCK_FILE
		CHAR temp_file_name[24];
	  #endif

		_setfattr((CHAR *)g_cycle_prev_file_path, D_RDONLY);
		if(curr_file_info.file_handle_b >= 0) {
			_setfattr((CHAR *)g_cycle_prev_file_path_b, D_RDONLY);
		}

	  #if RENAME_LOCK_FILE
		gp_memcpy((INT8S *)temp_file_name, (INT8S *)g_cycle_prev_file_path, sizeof(temp_file_name));
		temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'A';
		_rename((char *)g_cycle_prev_file_path, temp_file_name);
		gp_memcpy((INT8S *)g_cycle_prev_file_path, (INT8S *)temp_file_name, sizeof(temp_file_name));

		if(curr_file_info.file_handle_b >= 0) {
			gp_memcpy((INT8S *)temp_file_name, (INT8S *)g_cycle_prev_file_path_b, sizeof(temp_file_name));
			temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C'; temp_file_name[9] = 'B';
			_rename((char *)g_cycle_prev_file_path_b, temp_file_name);
			gp_memcpy((INT8S *)g_cycle_prev_file_path_b, (INT8S *)temp_file_name, sizeof(temp_file_name));
		}
	  #endif
	}

	if(!record_config){
		g_lock_current_file_flag = 1;
		return;
	}

	if(recording_time > (record_config*60-10)) {
		g_lock_current_file_flag = 2;
	} else {
		g_lock_current_file_flag = 1;	//set file attribute only after close file
	}	
}


INT32S ap_video_record_zoom_inout(INT8U inout)
{
	INT8U  err;
	INT32S nRet, msg;
	
	nRet = STATUS_OK;

  #if 0
	//+++ Not support digital zoom : 0:1080FHD  1:1080P
	err = ap_state_config_video_resolution_get();
	if((err == 0)|| (err == 1))
	{
		return nRet;
	}
  #else
	return nRet;
  #endif
	
	if(inout) {
		POST_MESSAGE(my_AVIEncodeApQ, MSG_AVI_ZOOM_IN, my_avi_encode_ack_m, 5000, msg, err);	
	} else {
		POST_MESSAGE(my_AVIEncodeApQ, MSG_AVI_ZOOM_OUT, my_avi_encode_ack_m, 5000, msg, err);	
	}

Return:	
	return nRet;
}
