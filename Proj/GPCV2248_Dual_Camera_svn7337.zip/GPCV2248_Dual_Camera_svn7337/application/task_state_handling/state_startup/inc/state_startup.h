#include "task_state_handling.h"

extern void state_startup_entry(void *para);

extern void ap_startup_init(void);
