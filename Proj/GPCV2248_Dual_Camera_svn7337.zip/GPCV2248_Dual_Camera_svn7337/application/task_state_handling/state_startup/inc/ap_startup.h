#include "state_startup.h"

extern void ap_startup_init(void);
