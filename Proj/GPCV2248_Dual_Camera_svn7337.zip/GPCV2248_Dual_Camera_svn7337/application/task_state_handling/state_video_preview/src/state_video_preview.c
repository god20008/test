#include "state_video_preview.h"
#include "ap_video_preview.h"
#include "ap_state_handling.h"
#include "ap_state_config.h"
#include "ap_video_record.h"
#include "ap_display.h"
#include "avi_encoder_app.h"
#include "ap_peripheral_handling.h"

//+++
INT8U pic_flag;
INT32U photo_check_time_loop_count = 0;
INT32U photo_check_time_preview_count = 0;

#define CONTINUOUS_SHOOTING_COUNT_MAX	5

//	prototypes
void state_video_preview_init(void);
void state_video_preview_exit(void);

extern void ap_disply_mode_set(INT8U dispMode);

extern INT8U ap_state_config_usb_mode_get(void);

void state_photo_check_timer_isr(void)
{
	photo_check_time_loop_count++;

	/*
		���O���U MSG ���W����
		MSG_APQ_CONNECT_TO_PC / MSG_APQ_MENU_KEY_ACTIVE / MSG_APQ_MODE
	*/	
	if((pic_flag == 2)||(pic_flag == 3)||(pic_flag == 4))
	{
		photo_check_time_loop_count = photo_check_time_preview_count;
	}
	
	if(photo_check_time_loop_count >= photo_check_time_preview_count)
	{
		msgQSend(ApQ, MSG_APQ_CAPTURE_PREVIEW_ON, NULL, NULL, MSG_PRI_NORMAL);	
		timer_stop(TIMER_C);
	}
}

extern INT8U ext_rtc_pwr_on_flag;

void state_video_preview_init(void)
{
	DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("video_preview state init enter\r\n");
	ap_video_preview_init();
}

void state_video_preview_entry(void *para)
{
	EXIT_FLAG_ENUM exit_flag = EXIT_RESUME;
	INT32U msg_id, file_path_addr;
	INT32U *prev_state;
	STAudioConfirm *audio_temp;
	INT8U continuous_shooting_count = 0;
	INT8U photo_check_time_flag;
	INT32U photo_check_time_start;
	INT32U photo_check_time_end;
	INT32U photo_check_time_count_ms;
	INT32U photo_check_ui_setting_ms;
	INT8U temp;

	pic_flag = 0;
	prev_state = para;

	/*
		��ӼҦ��U�ֳt�˵�
		0	��
		1	2��
		2	5��
	*/
	//�s�礣�Ұʧֳt�˵�

	if(ap_state_handling_storage_id_get() == NO_STORAGE) { //not to use burst when no SD card inserted
		photo_check_time_flag = ap_state_config_preview_get();
	} else if(ap_state_config_burst_get()) {
		photo_check_time_flag = 0;
	} else {
		photo_check_time_flag = ap_state_config_preview_get();
	}

	/*
		�qvideo recording / setting �i�ӳ��O�Npreview buffer ��dummy address �ɨ�display address
	*/

	if(ext_rtc_pwr_on_flag) {
		ext_rtc_pwr_on_flag = 0;
		ap_video_capture_mode_switch(1, STATE_VIDEO_PREVIEW);
		video_encode_back_preview_start(1);
	} else {
	  #if ENABLE_SAVE_SENSOR_RAW_DATA
		ap_video_capture_mode_switch(1, STATE_VIDEO_PREVIEW);
	  #else
		ap_video_capture_mode_switch(0, STATE_VIDEO_PREVIEW);
		video_encode_back_preview_start(0);
	  #endif
	}

	state_video_preview_init();
	DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Video_preview_init!\r\n");

	while (exit_flag == EXIT_RESUME) {
		if (msgQReceive(ApQ, &msg_id, (void *) ApQ_para, AP_QUEUE_MSG_MAX_LEN) == STATUS_FAIL) {
			continue;
		}

		switch (msg_id) {
			case EVENT_APQ_ERR_MSG:
				audio_temp = (STAudioConfirm *)ApQ_para;
				if((audio_temp->result == AUDIO_ERR_DEC_FINISH) && (audio_temp->source_type == AUDIO_SRC_TYPE_APP_RS)){
					//gpio_write_io(SPEAKER_EN, DATA_LOW);
				} else {
					audio_confirm_handler((STAudioConfirm *)ApQ_para);
				}
				break;
			case MSG_STORAGE_SERVICE_MOUNT:
				ap_state_handling_storage_id_set(ApQ_para[0]);
        		ap_state_handling_icon_clear_cmd(ICON_INTERNAL_MEMORY, NULL, NULL);
        		ap_state_handling_icon_show_cmd(ICON_SD_CARD, NULL, NULL);
			    ap_state_handling_str_draw_exit();
				left_capture_num = cal_left_capture_num();
				left_capture_num_display(left_capture_num);
        		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("[Video Preview Mount OK]\r\n");
        		break;
        	case MSG_STORAGE_SERVICE_NO_STORAGE:
        		ap_state_handling_storage_id_set(ApQ_para[0]);
        		ap_state_handling_icon_clear_cmd(ICON_SD_CARD, NULL, NULL);
        		ap_state_handling_icon_show_cmd(ICON_INTERNAL_MEMORY, NULL, NULL);
				left_capture_num = cal_left_capture_num();
				left_capture_num_display(left_capture_num);
        		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("[Video Preview Mount FAIL]\r\n");
        		break;

        	case MSG_APQ_MENU_KEY_ACTIVE:
				if(pic_flag == 0) {
				    ap_state_handling_str_draw_exit();
        			OSTimeDly(10);
					vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();
	       		  	OSQPost(StateHandlingQ, (void *) STATE_SETTING);
	        		exit_flag = EXIT_BREAK;
				} else {
					pic_flag = 3;
				}
            	break;

        	case MSG_APQ_PREV_KEY_ACTIVE://MSG_APQ_NEXT_KEY_ACTIVE //BILLY CHANGE

				if(back_sensor_plug_status_get())
				{
	        		if(back_a_car_status_get())
	        		{
		        		temp = ap_display_line_mode_get();
		        		if(temp>=6)
		        		{
		        			temp = 0;
		        		}
		        		else
		        		{
		        			temp = temp + 1;
		        		}
		        		ap_display_line_mode_set(temp);
					}
					else
					{
						temp = ap_state_config_display_mode_get();
						if(temp>=5)
						{
							temp = 1;
						}
						else
						{
						
							temp = temp + 1;
						}
						ap_disply_mode_set(temp);
		        		ap_state_config_display_mode_set(temp);
		        		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Display mode = %d\r\n",temp);
		        	}
	        	}
	        	else
	        	{
					if(pic_flag == 0)
					{
						ap_video_record_zoom_inout(0);
					}
				}
	        	break;
        	case MSG_APQ_NEXT_KEY_ACTIVE:	//MSG_APQ_PREV_KEY_ACTIVE //BILLY CHANGE	
				
        		if(back_a_car_status_get())
	        	{
	        		temp = ap_display_line_mode_get();
	        		if((temp==0)||(temp>6))
	        		{
	        			temp = 6;
	        		}
	        		else
	        		{
	        			temp = temp - 1;
	        		}
	        		ap_display_line_mode_set(temp);
	        	}
	        	else
      			{
					if(pic_flag == 0)
					{
		        		ap_video_record_zoom_inout(1);
		        	}
		        }
        		break;

  	     	case MSG_APQ_MODE:
				if(pic_flag == 0) {
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
					vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();
      		  		OSQPost(StateHandlingQ, (void *) STATE_BROWSE);
	        		exit_flag = EXIT_BREAK;
	        	} else {
	        		pic_flag = 4;
	        	}
	        	break;

        	case MSG_APQ_FUNCTION_KEY_ACTIVE:
#if KEY_FUNTION_TYPE == SAMPLE2
        		break;
#endif
			case MSG_APQ_CAPTURE_KEY_ACTIVE:	
			case MSG_APQ_CAPTURE_CONTINUOUS_SHOOTING:
				if(pic_flag == 0) {
					if(ap_video_preview_func_key_active() < 0) {
						pic_flag = 0;
					} else {
						pic_flag = 1;
						photo_check_time_start = OSTimeGet();
					}
				}
				break;

        	case MSG_STORAGE_SERVICE_PIC_REPLY:
        		if(ap_video_preview_reply_action((STOR_SERV_FILEINFO *) ApQ_para) < 0) {
        			pic_flag = 0;
        			break;
        		}
        		file_path_addr = ((STOR_SERV_FILEINFO *) ApQ_para)->file_path_addr;
        		break;

        	case MSG_STORAGE_SERVICE_PIC_DONE:
        		ap_video_preview_reply_done(file_path_addr);

				// �S���Ұʧֳt�˵�,�����]��MSG_APQ_CAPTURE_PREVIEW_ON
				if(photo_check_time_flag)
				{
					photo_check_time_end = OSTimeGet();
					photo_check_ui_setting_ms = ((photo_check_time_flag*3)-1)*1000; // ms

					photo_check_time_count_ms = (photo_check_time_end-photo_check_time_start)*10; //ms

					//����Ӫ�O�ɶ��p��UI�]�w,�~�Ұ�timer
					if(photo_check_time_count_ms < photo_check_ui_setting_ms)
					{
						photo_check_time_loop_count = 0;
						photo_check_time_preview_count = (photo_check_ui_setting_ms-photo_check_time_count_ms)/100;
						timer_msec_setup(TIMER_C, 100, 0, state_photo_check_timer_isr); // 100 ms
		        		break;
					}
				}
			case MSG_APQ_CAPTURE_PREVIEW_ON:			
        		if(pic_flag == 2) { // Connect To PC
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
					vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();
	        		ap_state_handling_connect_to_pc(STATE_VIDEO_PREVIEW);
        			break;
        		} else if(pic_flag == 3) { // MEMU Key
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
        		  	OSQPost(StateHandlingQ, (void *) STATE_SETTING);
	        		exit_flag = EXIT_BREAK;
        			break;
        		} else if(pic_flag == 4) { // MODE Key
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
      		  		OSQPost(StateHandlingQ, (void *) STATE_BROWSE);
	        		exit_flag = EXIT_BREAK;
        			break;
        		} else if(pic_flag == 5) { // HDMI insert
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
      		  		OSQPost(StateHandlingQ, (void *) STATE_BROWSE);
					msgQSend(ApQ, MSG_APQ_HDMI_PLUG_IN, NULL, NULL, MSG_PRI_NORMAL);
	        		exit_flag = EXIT_BREAK;
        			break;
        		} else if((pic_flag == 6) || (pic_flag == 7)) { // TV plug in/out
					vid_enc_disable_sensor_clock();
					vid_enc_back_preview_stop();
					if(pic_flag == 6) {
						ap_state_handling_tv_init();
					} else {
						ap_state_handling_tv_uninit();
					}

			   		ap_video_capture_mode_switch(0, STATE_VIDEO_PREVIEW);
					video_capture_resolution_display();
					left_capture_num = cal_left_capture_num();
					left_capture_num_display(left_capture_num);

					pic_flag = 0;
					break;
        		}
        		
				/* sensor����,�Nsensor �e�X����Ƥ޾ɨ쩳�hpreview flow */
				#if ENABLE_SAVE_SENSOR_RAW_DATA
		   		ap_video_capture_mode_switch(0, STATE_VIDEO_RECORD);
				#else
		   		ap_video_capture_mode_switch(0, STATE_VIDEO_PREVIEW);
				video_encode_back_preview_start(0);
		   		#endif
				/*
					��ӼҦ��U�s��
				*/
				if(ap_state_config_burst_get() && (ap_state_handling_storage_id_get() != NO_STORAGE))
				{
					continuous_shooting_count++;
					if(continuous_shooting_count < CONTINUOUS_SHOOTING_COUNT_MAX)
					{
        				msgQSend(ApQ, MSG_APQ_CAPTURE_CONTINUOUS_SHOOTING, NULL, NULL, MSG_PRI_NORMAL);
        			}
        			else
        			{
						continuous_shooting_count = 0;
        			}
				}

        		pic_flag = 0;
			
			break;
 		
        	case MSG_APQ_POWER_KEY_ACTIVE:
        	case MSG_APQ_SYS_RESET:
				video_encode_exit();
				OSTimeDly(10);        		
				ap_state_config_hang_mode_set(0x02);	//STATE_VIDEO_PREIVEW
				if(msg_id == MSG_APQ_POWER_KEY_ACTIVE) {
	        		ap_state_handling_power_off(0);
	        	} else {
	        		ap_state_handling_power_off(1);
	        	}
        		break;

#if C_BATTERY_DETECT == CUSTOM_ON
        	case MSG_APQ_BATTERY_LVL_SHOW:
        		ap_state_handling_battery_icon_show(ApQ_para[0]);
        		break;
        	case MSG_APQ_BATTERY_CHARGED_SHOW:
				ap_state_handling_charge_icon_show(1);
        		break;
        	case MSG_APQ_BATTERY_CHARGED_CLEAR:
				ap_state_handling_charge_icon_show(0);
        		break;        		
        	case MSG_APQ_BATTERY_LOW_SHOW:
        		ap_state_handling_clear_all_icon();
        		OSTimeDly(5);
				ap_state_handling_str_draw_exit();
				ap_state_handling_str_draw(STR_BATTERY_LOW, WARNING_STR_COLOR);
				msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_BATTERY_LOW_BLINK_START, NULL, NULL, MSG_PRI_NORMAL);
        		break;
#endif

        	case MSG_APQ_CONNECT_TO_PC:
				if(ap_display_get_device() != DISP_DEV_TFT) break;
				msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TV_POLLING_STOP, NULL, NULL, MSG_PRI_NORMAL);
				OSTimeDly(3);
				if(pic_flag == 0) {
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
					vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();

					ap_disply_mode_set(APP_SHOW_DUMMY);

	        		ap_state_handling_connect_to_pc(STATE_VIDEO_PREVIEW);
	        	} else {
	        		pic_flag = 2;
	        	}
        		break;

        	case MSG_APQ_DISCONNECT_TO_PC:
				msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TV_POLLING_START, NULL, NULL, MSG_PRI_NORMAL);
        		ap_state_handling_disconnect_to_pc();
        		OSTimeDly(100);
				/*
					���Nweb cam��preview �ɥX�h,�A������capture ��preview					
				*/
				pic_flag = 0;
				vid_enc_disable_sensor_clock();

				//ap_disply_mode_set(ap_state_config_display_mode_get());
				if(back_sensor_plug_status_get())
				{
					if(back_a_car_status_get())
					{
						ap_diplay_back_a_car_mode(1);
					}
					else
					{
						ap_diplay_back_a_car_mode(0);
					}
				}
				else
				{
					ap_disply_mode_set(APP_SHOW_FRONT);
					ap_state_config_display_mode_set(1);
				}
				
		   		ap_video_capture_mode_switch(0, STATE_VIDEO_PREVIEW);
				video_encode_back_preview_start(0);
        		break;

			case MSG_APQ_NIGHT_MODE_KEY:
				audio_effect_play(EFFECT_CLICK);
				ap_state_handling_night_mode_switch();
				break;

			case MSG_APQ_USER_CONFIG_STORE:
				ap_state_config_store();
				break;

			case MSG_APQ_AUDIO_EFFECT_UP:
			case MSG_APQ_AUDIO_EFFECT_DOWN:
			    break;

			case MSG_APQ_HDMI_PLUG_IN:
				if(pic_flag == 0) {
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
	        		vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();
      		  		OSQPost(StateHandlingQ, (void *) STATE_BROWSE);
					msgQSend(ApQ, MSG_APQ_HDMI_PLUG_IN, NULL, NULL, MSG_PRI_NORMAL);
	        		exit_flag = EXIT_BREAK;
	        	} else {
	        		pic_flag = 5;
	        	}
			break;

			
			//+++ TV_OUT_D1
			case MSG_APQ_TV_PLUG_OUT:
			case MSG_APQ_TV_PLUG_IN:
				video_capture_resolution_clear();
				left_capture_num_str_clear();

				if(pic_flag == 0) {
				    ap_state_handling_str_draw_exit();
				    OSTimeDly(3);
					vid_enc_disable_sensor_clock();
	 				vid_enc_back_preview_stop();
					if(msg_id == MSG_APQ_TV_PLUG_IN) {
						ap_state_handling_tv_init();
	        		} else {
						ap_state_handling_tv_uninit();
	        		}
			   		ap_video_capture_mode_switch(0, STATE_VIDEO_PREVIEW);
					video_encode_back_preview_start(0);
					video_capture_resolution_display();
					left_capture_num = cal_left_capture_num();
					left_capture_num_display(left_capture_num);
				} else {
					if(msg_id == MSG_APQ_TV_PLUG_IN) {
		        		pic_flag = 6;
		        	} else {
		        		pic_flag = 7;
		        	}
				}
			break;
			//---
			case MSG_APQ_BACK_SENSOR_PLUG_IN:
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BACK SENSOR PLUG IN\r\n");
				temp = ap_state_config_display_mode_get();
				ap_disply_mode_set(temp);
				break;
			case MSG_APQ_BACK_SENSOR_PLUG_OUT:
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BACK SENSOR PLUG OUT\r\n");
				ap_disply_mode_set(APP_SHOW_FRONT);
				ap_state_config_display_mode_set(1);
				break;
			case MSG_APQ_BACK_A_CAR_ON:
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BACK A CAR ON\r\n");
				ap_diplay_back_a_car_mode(1);
				temp = BACK_A_CAR_KEY;
				msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_KEY_REGISTER, &temp, sizeof(INT8U), MSG_PRI_NORMAL);	
				break;
			case MSG_APQ_BACK_A_CAR_OFF:
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BACK A CAR OFF\r\n");
				ap_diplay_back_a_car_mode(0);
				if (s_usbd_pin == 0) {
					temp = GENERAL_KEY;
					msgQSend(PeripheralTaskQ, MSG_PERIPHERAL_TASK_KEY_REGISTER, &temp, sizeof(INT8U), MSG_PRI_NORMAL);
				}
				break;

			default:
				ap_state_common_handling(msg_id);
				break;
		}
	}

	state_video_preview_exit();
	if(photo_check_time_flag)
	{
		timer_stop(TIMER_C);
	}
}

void state_video_preview_exit(void)
{
	ap_video_preview_exit();

	DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Exit video_preview state\r\n");
}
