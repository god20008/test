#include "application.h"

extern const INT16U ALIGN4 hdmi_bat0[];
extern const INT16U ALIGN4 hdmi_bat1[];
extern const INT16U ALIGN4 hdmi_bat2[];
extern const INT16U ALIGN4 hdmi_bat3[];

extern const INT16U ALIGN4 hdmi_charging[];

extern const INT16U ALIGN4 hdmi_avi_file[];
extern const INT16U ALIGN4 hdmi_jpg_file[];
extern const INT16U ALIGN4 hdmi_key[];
extern const INT16U ALIGN4 hdmi_pause[];
extern const INT16U ALIGN4 hdmi_play[];

extern const INT16U ALIGN4 hdmi_red_cu[];
extern const INT16U ALIGN4 hdmi_white_cu[];
extern const INT16U ALIGN4 hdmi_speaker[];
