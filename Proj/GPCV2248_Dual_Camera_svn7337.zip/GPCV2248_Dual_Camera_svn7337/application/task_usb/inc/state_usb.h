#ifndef __STATE_USBD_H__
#define __STATE_USBD_H__

#include "application.h"
#include "Customer.h"

void usb_uninitial(void);

#endif  /*__STATE_CALENDAR_H__*/
