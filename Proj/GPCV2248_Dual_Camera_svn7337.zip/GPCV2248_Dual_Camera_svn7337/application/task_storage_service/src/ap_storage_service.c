#include "ap_storage_service.h"
#include "ap_state_config.h"
#include "ap_state_handling.h"
#include "avi_encoder_app.h"

extern INT8U back_sensor_plug_status_get(void);

#if CREATE_FILE_DEBUG
extern void FatSpeedUpPrintf(INT16S dsk);  //for debug
#endif

INT32S start_sector_of_root = 0;
INT32S start_sector_of_dcim = 0;
INT32S start_sector_of_dcima = 0;
INT32S start_sector_of_dcimb = 0;

static INT8U dual_mode = 0;
static INT8U cyclic_off = 0;
static INT8U rec_time_config, rec_resolution_config;

#define AVI_REC_MAX_BYTE_SIZE   0x70000000  //1879048192 Bytes
#define AP_STG_MAX_FILE_NUMS    625

extern INT8U screen_saver_enable;
extern STOR_SERV_PLAYINFO play_info;

static INT32S g_jpeg_index;
static INT32S g_avi_index;
static INT32S g_wav_index;
static INT32S g_file_index;
static INT16S g_play_index;

static INT32S g_jpeg_index_a;
static INT32S g_jpeg_index_b;
static INT32S g_avi_index_a;
static INT32S g_avi_index_b;

static INT16U g_file_num;
static INT16U g_file_num_a;
static INT16U g_file_num_b;
static INT16U g_trace_cnt;

static INT32S g_file_index_b_max;
static INT16U deleted_num_b_max;

static INT16U g_err_cnt;
static INT32U g_avi_file_time = 0;
static INT32U g_avi_file_time_a = 0;
static INT32U g_avi_file_time_b = 0;
static INT32U g_jpg_file_time;
static INT32U g_jpg_file_time_a;
static INT32U g_jpg_file_time_b;
static INT32U g_wav_file_time;

static INT8U g_avi_index_9999_exist;
static INT16S g_latest_avi_file_index;
static INT16S g_latest_jpg_file_index;
static INT16S g_latest_avi_file_index_a;
static INT16S g_latest_avi_file_index_b;
static INT16S g_latest_jpg_file_index_a;
static INT16S g_latest_jpg_file_index_b;
static INT32U g_avi_file_oldest_time = 0;
static INT16S g_oldest_avi_file_index = 0;

static INT16S temp_oldest_avi_index = 10000;


static CHAR g_file_path[24];
static CHAR g_file_path_b[24];
static CHAR g_next_file_path[24];
static CHAR g_next_file_path_b[24];

#if GPS_TXT
static CHAR g_txt_path[24];
static CHAR g_next_txt_path[24];
#endif

static INT8U curr_storage_id;
static INT8U storage_mount_timerid;

#if C_AUTO_DEL_FILE == CUSTOM_ON
	static INT8U storage_freesize_timerid;
#endif

INT8U usbd_storage_exit;
INT8U device_plug_phase=0;

static INT16U avi_file_table[625];
static INT16U jpg_file_table[625];
static INT16U avi_file_table_b[625];
static INT16U jpg_file_table_b[625];
static INT16U wav_file_table[625];

static INT8U sd_upgrade_file_flag = 0;

static INT32U avi_file_size;
static INT32U avi_file_size_back;

st_storage_file_node_info FNodeInfo[MAX_SLOT_NUMS];

#if C_AUTO_DEL_FILE == CUSTOM_ON
/*static*/ INT8U ap_step_work_start=0;
static INT8U FAT_cache_fetched = 0;
static INT32U num_cache_fetch = 0;
static INT32U cache_fetch_cnt = 0;
static INT32S cluster_to_fetch = 0;
#endif

//	prototypes
INT32S get_file_final_wav_index(void);
INT32S get_file_final_avi_index(void);
INT32S get_file_final_jpeg_index(void);
INT16U get_deleted_file_number(INT8U flag);
void get_file_index(void);

void ap_storage_service_init(void)
{
#if C_AUTO_DEL_FILE == CUSTOM_ON
	storage_freesize_timerid = 0xFF;
#endif
	storage_mount_timerid = STORAGE_SERVICE_MOUNT_TIMER_ID;
	sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_STORAGE_CHECK, storage_mount_timerid, STORAGE_TIME_INTERVAL_MOUNT);
}

INT8U storage_sd_upgrade_file_flag_get(void)
{
	return sd_upgrade_file_flag;
}

#if C_AUTO_DEL_FILE == CUSTOM_ON
void ap_storage_service_freesize_check_switch(INT8U type)
{
	const INT8U temp2[6] = {5, 1, 2, 3, 5, 10};	//unit: minute

	if (type == TRUE) {
		if (storage_freesize_timerid == 0xFF) {
			storage_freesize_timerid = STORAGE_SERVICE_FREESIZE_TIMER_ID;
			FAT_cache_fetched = 0;

			if(temp2[rec_time_config] == 1) { //1min
				sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, 10*128); //begin to delete old files after 10s
			} else {
				sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, ((temp2[rec_time_config]*STORAGE_TIME_INTERVAL_MOUNT*60) - (90*128)));
			}
		}
	} else {
		if (storage_freesize_timerid != 0xFF) {
			sys_kill_timer(storage_freesize_timerid);
			storage_freesize_timerid = 0xFF;
		}
	}
}

#define SDC_CACHE_SIZE          (32*1024)

INT32S ap_storage_service_freesize_check_and_del(void)
{
	INT32U file_size_to_create;
	INT32S i, ret, del_index;
    INT32S  step_ret;
	INT16S del_ret;
	CHAR f_name[24], f_name_b[24];
    struct stat_t buf_tmp, buf_tmp_b;

    if(storage_freesize_timerid == 0xff) return STATUS_OK;

	if(ap_step_work_start == 0) {
		if(cyclic_off == 0) {
			if(dual_mode) {
				file_size_to_create = avi_file_size + avi_file_size_back;
			} else {
				file_size_to_create = avi_file_size;
			}
			file_size_to_create <<= 20;

			i = 0;
			ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
			if(ret < 2) { //delete old files for next recording
				if(cyclic_off) i = 10000;
				for(; i<10000; i++) {
				    del_index = g_oldest_avi_file_index;
					if((del_index & 0x000f) == 0) {
						if((avi_file_table[del_index >> 4] == 0) && (avi_file_table_b[del_index >> 4] == 0)) {
							g_oldest_avi_file_index += 16;
							if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
							i += 15;
							continue;
						}
					}

					if (avi_file_table[del_index >> 4] & (1<<(del_index & 0x000f))) {
						sprintf((char *)f_name, (const char *)"DCIMA\\MOVA%04d.avi", del_index);
						if((stat(f_name, &buf_tmp) == SUCCESS) && (buf_tmp.st_mode != D_RDONLY)) {
							//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name);
				            unlink_step_start();
							del_ret = unlink((CHAR *)f_name);
							if(del_ret < 0) {
								del_ret = unlink((CHAR *)f_name);
							}
							avi_file_table[del_index >> 4] &= ~(1 << (del_index & 0xF));

							if(del_ret >= 0) {
					            ap_step_work_start = 1;
					            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);
								break;
							}
						}
					}
					
					if (avi_file_table_b[del_index >> 4] & (1<<(del_index & 0x000f))) {
						sprintf((char *)f_name_b, (const char *)"DCIMB\\MOVB%04d.avi", del_index);
						if((stat(f_name_b, &buf_tmp_b) == SUCCESS) && (buf_tmp_b.st_mode != D_RDONLY)) {
							//DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name_b);
				            unlink_step_start();
							del_ret = unlink((CHAR *)f_name_b);
							if(del_ret < 0) {
								del_ret = unlink((CHAR *)f_name_b);
							}
							avi_file_table_b[del_index >> 4] &= ~(1 << (del_index & 0xF));

							if(del_ret >= 0) {
					            ap_step_work_start = 1;
					            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);

								del_index += 1;
								if(del_index > 9999) del_index = 0;
								g_oldest_avi_file_index = del_index;
								break;
							}
	    				}
					}

					del_index += 1;
					if(del_index > 9999) del_index = 0;
					g_oldest_avi_file_index = del_index;
				}
			} else if(FAT_cache_fetched == 0) { //prefetch FAT cache
				if(checkfattype (MINI_DVR_STORAGE_TYPE) == FAT32_Type) {
		            ap_step_work_start = 2;
					num_cache_fetch = ((file_size_to_create/GetBytesPerCluster(MINI_DVR_STORAGE_TYPE))*4 + SDC_CACHE_SIZE - 1)/SDC_CACHE_SIZE;
					cache_fetch_cnt = 0;
					cluster_to_fetch = ret;
		            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);
				} else {
					FAT_cache_fetched = 1;
				}
			} else { //write back FAT cache
				ret = UsrCacheSyncStep(MINI_DVR_STORAGE_TYPE);
				if(ret != 1) {
		            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepSync Done\r\n");
					sys_kill_timer(storage_freesize_timerid);
					storage_freesize_timerid = 0xFF;
				} else {
		            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepSync Continue\r\n");
		            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);
				}
			}
		}
	} else if(ap_step_work_start == 1) {
        step_ret = unlink_step_work();
        if(step_ret != 0) {
            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);
            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepDel Continue\r\n");
        } else {
            ap_step_work_start = 0;
			FAT_cache_fetched = 1;
            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepDel Done\r\n");
        }
	} else { //ap_step_work_start == 2
		UsrFatCacheFetchStep(MINI_DVR_STORAGE_TYPE, cluster_to_fetch);
		cluster_to_fetch += SDC_CACHE_SIZE/4;
		
		cache_fetch_cnt++;
		if(cache_fetch_cnt >= num_cache_fetch) {
            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepPrefetch Done\r\n");
	        ap_step_work_start = 0;
			FAT_cache_fetched = 1;
		} else {
            //DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("StepPrefetch Continue\r\n");
            sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_FREESIZE_CHECK, storage_freesize_timerid, BKGROUND_DEL_INTERVAL);
		}
	}
	return STATUS_OK;
}
#endif

void ap_storage_service_file_del(void)
{
	INT32S ret, i;
	struct stat_t buf_tmp;

	close(play_info.file_handle);

	stat(g_file_path, &buf_tmp);
	if(buf_tmp.st_mode & D_RDONLY){
		ret = 0x55;
		msgQSend(ApQ, MSG_APQ_SELECT_FILE_DEL_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
		return;
	}

	if (unlink(g_file_path) < 0) {
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Delete file fail.\r\n");
		ret = STATUS_FAIL;
	} else {
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Delete file OK.\r\n");
#if GPS_TXT
		if(g_file_path[4] = 'A') {
			gp_memcpy((INT8S *)g_txt_path, (INT8S *)g_file_path, sizeof(g_file_path));
			g_txt_path[15] = 't'; g_txt_path[16] = 'x'; g_txt_path[17] = 't'; g_txt_path[18] = 0;
			unlink(g_txt_path);
		}
#endif
		g_file_num = g_file_num_a = g_file_num_b = 0;
		for (i=0; i<AP_STG_MAX_FILE_NUMS; i++) {
			avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
			avi_file_table_b[i] = jpg_file_table_b[i] = 0;
		}

		get_file_final_avi_index();
		get_file_final_jpeg_index();
		get_file_final_wav_index();
		get_file_index();

		if(!g_avi_index_9999_exist) {
			g_oldest_avi_file_index = temp_oldest_avi_index;
			if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
		}

		ret = STATUS_OK;
	}

	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	msgQSend(ApQ, MSG_APQ_SELECT_FILE_DEL_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
}

void ap_storage_service_file_delete_all(void)
{
	struct f_info file_info;
	//struct stat_t buf_tmp;
	INT32S nRet, i, ret;

	chdir("C:\\DCIM\\DCIMA");

//AVI	
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
			//stat((CHAR *) file_info.f_name, &buf_tmp);
			//if(buf_tmp.st_mode & D_RDONLY) {		//skip if it's locked
			if(file_info.f_attrib & _A_RDONLY) {	//modified by wwj, stat() spent too long time
				nRet = _findnext(&file_info);
				if (nRet < 0) {
					break;
				}
				continue;
			}

			unlink((CHAR *) file_info.f_name);
#if GPS_TXT
			if(file_info.f_name[3] = 'A') {
				gp_memcpy((INT8S *)g_txt_path, (INT8S *)file_info.f_name, sizeof(g_txt_path));
				g_txt_path[9] = 't'; g_txt_path[10] = 'x'; g_txt_path[11] = 't'; g_txt_path[12] = 0;
				unlink(g_txt_path);
			}
#endif
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	//JPEG	
	nRet = _findfirst("*.jpg", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
			unlink((CHAR *) file_info.f_name);
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	chdir("C:\\DCIM\\DCIMB");

//AVI	
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
			//stat((CHAR *) file_info.f_name, &buf_tmp);
			//if(buf_tmp.st_mode & D_RDONLY) {		//skip if it's locked
			if(file_info.f_attrib & _A_RDONLY) {	//modified by wwj, stat() spent too long time
				nRet = _findnext(&file_info);
				if (nRet < 0) {
					break;
				}
				continue;
			}

			unlink((CHAR *) file_info.f_name);
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	//JPEG	
	nRet = _findfirst("*.jpg", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
			unlink((CHAR *) file_info.f_name);
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	chdir("C:\\DCIM");

	//WAV
	nRet = _findfirst("*.wav", &file_info, D_ALL);
	if(nRet >= 0) {
		while (1) 
		{
			unlink((CHAR *) file_info.f_name);
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	g_play_index = -1;
	g_file_num = g_file_num_a = g_file_num_b = 0;
	for (i=0; i<AP_STG_MAX_FILE_NUMS; i++) {
		avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
		avi_file_table_b[i] = jpg_file_table_b[i] = 0;
	}

	//Scan again
	get_file_final_avi_index();
	get_file_final_jpeg_index();
	get_file_final_wav_index();
	get_file_index();

	if(!g_avi_index_9999_exist) {
		g_oldest_avi_file_index = temp_oldest_avi_index;
		if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
	}

	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);

	ret = STATUS_OK;
	msgQSend(ApQ, MSG_APQ_FILE_DEL_ALL_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
}

void ap_storage_service_file_lock_one(void)
{
	INT32S ret;

	if ( ((avi_file_table[g_play_index >> 4] & (1 << (g_play_index & 0xF))) && (g_file_path[4] == 'A')) ||
	     ((avi_file_table_b[g_play_index >> 4] & (1 << (g_play_index & 0xF))) && (g_file_path[4] == 'B')) )
	{	//only lock video files
	  #if RENAME_LOCK_FILE
		CHAR temp_file_name[24];
	  #endif

		_setfattr(g_file_path, D_RDONLY);

	  #if RENAME_LOCK_FILE
		gp_memcpy((INT8S *)temp_file_name, (INT8S *)g_file_path, sizeof(temp_file_name));
		temp_file_name[6] = 'L'; temp_file_name[7] = 'O'; temp_file_name[8] = 'C';
		_rename((char *)g_file_path, temp_file_name);
		gp_memcpy((INT8S *)g_file_path, (INT8S *)temp_file_name, sizeof(temp_file_name));
	  #endif
	}
	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	ret = STATUS_OK;
	msgQSend(ApQ, MSG_APQ_FILE_LOCK_ONE_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);	
}

void ap_storage_service_file_lock_all(void)
{
	struct f_info file_info;
	INT32S nRet, ret;

	ret = STATUS_FAIL;
	chdir("C:\\DCIM\\DCIMA");
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
		  #if RENAME_LOCK_FILE
			CHAR temp_file_name[24];
		  #endif

			_setfattr((CHAR *) file_info.f_name, D_RDONLY);

		  #if RENAME_LOCK_FILE
			gp_memcpy((INT8S *)temp_file_name, (INT8S *)file_info.f_name, sizeof(temp_file_name));
			temp_file_name[0] = 'L'; temp_file_name[1] = 'O'; temp_file_name[2] = 'C';
			_rename((char *)file_info.f_name, temp_file_name);
		  #endif

			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
		ret = STATUS_OK;
	}
	
	chdir("C:\\DCIM\\DCIMB");
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
		  #if RENAME_LOCK_FILE
			CHAR temp_file_name[24];
		  #endif

			_setfattr((CHAR *) file_info.f_name, D_RDONLY);

		  #if RENAME_LOCK_FILE
			gp_memcpy((INT8S *)temp_file_name, (INT8S *)file_info.f_name, sizeof(temp_file_name));
			temp_file_name[0] = 'L'; temp_file_name[1] = 'O'; temp_file_name[2] = 'C';
			_rename((char *)file_info.f_name, temp_file_name);
		  #endif

			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
		ret = STATUS_OK;
	}
	chdir("C:\\DCIM");
	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	msgQSend(ApQ, MSG_APQ_FILE_LOCK_ALL_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
}

void ap_storage_service_file_unlock_one(void)
{
	INT32S ret;
	if ( ((avi_file_table[g_play_index >> 4] & (1 << (g_play_index & 0xF))) && (g_file_path[4] == 'A')) ||
	     ((avi_file_table_b[g_play_index >> 4] & (1 << (g_play_index & 0xF))) && (g_file_path[4] == 'B')) )
	{
	  #if RENAME_LOCK_FILE
		CHAR temp_file_name[24];
	  #endif

		_setfattr(g_file_path, D_NORMAL);

	  #if RENAME_LOCK_FILE
		gp_memcpy((INT8S *)temp_file_name, (INT8S *)g_file_path, sizeof(temp_file_name));
		temp_file_name[6] = 'M'; temp_file_name[7] = 'O'; temp_file_name[8] = 'V';
		_rename((char *)g_file_path, temp_file_name);
		gp_memcpy((INT8S *)g_file_path, (INT8S *)temp_file_name, sizeof(temp_file_name));
	  #endif
	}
	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	ret = STATUS_OK;
	msgQSend(ApQ, MSG_APQ_FILE_UNLOCK_ONE_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
}

void ap_storage_service_file_unlock_all(void)
{
	struct f_info file_info;
	INT32S nRet, ret;

	ret = STATUS_FAIL;
	chdir("C:\\DCIM\\DCIMA");
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
		  #if RENAME_LOCK_FILE
			CHAR temp_file_name[24];
		  #endif

			_setfattr((CHAR *) file_info.f_name, D_NORMAL);

		  #if RENAME_LOCK_FILE
			gp_memcpy((INT8S *)temp_file_name, (INT8S *)file_info.f_name, sizeof(temp_file_name));
			temp_file_name[0] = 'M'; temp_file_name[1] = 'O'; temp_file_name[2] = 'V';
			_rename((char *)file_info.f_name, temp_file_name);
		  #endif

			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
		ret = STATUS_OK;
	}
	
	chdir("C:\\DCIM\\DCIMB");
	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if (nRet >= 0) {
		while (1) {
		  #if RENAME_LOCK_FILE
			CHAR temp_file_name[24];
		  #endif

			_setfattr((CHAR *) file_info.f_name, D_NORMAL);

		  #if RENAME_LOCK_FILE
			gp_memcpy((INT8S *)temp_file_name, (INT8S *)file_info.f_name, sizeof(temp_file_name));
			temp_file_name[0] = 'M'; temp_file_name[1] = 'O'; temp_file_name[2] = 'V';
			_rename((char *)file_info.f_name, temp_file_name);
		  #endif

			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
		ret = STATUS_OK;
	}
	chdir("C:\\DCIM");
	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	msgQSend(ApQ, MSG_APQ_FILE_UNLOCK_ALL_REPLY, &ret, sizeof(INT32S), MSG_PRI_NORMAL);
}

void ap_storage_service_timer_start(void)
{
	if (storage_mount_timerid == 0xff) {
		storage_mount_timerid = STORAGE_SERVICE_MOUNT_TIMER_ID;
		sys_set_timer((void*)msgQSend, (void*)StorageServiceQ, MSG_STORAGE_SERVICE_STORAGE_CHECK, storage_mount_timerid, STORAGE_TIME_INTERVAL_MOUNT);
	}
}

void ap_storage_service_timer_stop(void)
{
	if (storage_mount_timerid != 0xff) {
		sys_kill_timer(storage_mount_timerid);
		storage_mount_timerid = 0xff;
	}
}

void ap_storage_service_usb_plug_in(void)
{
	device_plug_phase = 0;
}

#ifdef SDC_DETECT_PIN
extern INT32S ap_peripheral_SDC_at_plug_OUT_detect(void);
extern INT32S ap_peripheral_SDC_at_plug_IN_detect(void);
#endif
INT32S ap_storage_service_storage_mount(void)
{
	INT32S nRet, i;
	INT32U size;
	INT16S fd;
	INT32S start_cluster_of_dcim;
	INT32S start_cluster_of_dcima;
	INT32S start_cluster_of_dcimb;

	if(storage_mount_timerid == 0xff) return	STATUS_FAIL;

	if (device_plug_phase == 0) {
		ap_storage_service_timer_stop();				//prohibit too many MSG_STORAGE_SERVICE_STORAGE_CHECK sent during sd mounting
#ifndef SDC_DETECT_PIN
		nRet = _devicemount(MINI_DVR_STORAGE_TYPE);
#else
		nRet = ap_peripheral_SDC_at_plug_OUT_detect();
//		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("nRet= %d\r\n",nRet);
		if(!nRet){
			 _devicemount(MINI_DVR_STORAGE_TYPE);
		}
#endif
	} else {
#ifndef SDC_DETECT_PIN
		nRet = drvl2_sdc_live_response();
#else
		nRet = ap_peripheral_SDC_at_plug_IN_detect();
#endif
		if(nRet != 0) {
			ap_storage_service_timer_stop();				//prohibit too many MSG_STORAGE_SERVICE_STORAGE_CHECK sent during sd mounting
			nRet = _devicemount(MINI_DVR_STORAGE_TYPE);
		}
	}

	if (nRet < 0) {
		device_plug_phase = 0;  // plug out phase

		if (curr_storage_id != NO_STORAGE) {
		  #if (defined RAMDISK_EN) && (RAMDISK_EN == 1)
			INT16S ret;
		  #endif

			// add by josephhsieh@140717 // �Y�ù��O�@�}�ɡA�n�I�G�I��
			if(screen_saver_enable) {
				screen_saver_enable = 0;
				ap_state_handling_lcd_backlight_switch(1);
			}

		  #if (defined RAMDISK_EN) && (RAMDISK_EN == 1)
			_devicemount(RAMDISK_TYPE);
			ret = sformat(RAMDISK_TYPE, 32*1024*1024/512, C_RAMDISK_SIZE/512);
			if(ret != 0) {
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("RAM disk format fail...\r\n");
			}

			mkdir("D:\\DCIM");
			chdir("D:\\DCIM");
		  #endif

			g_file_index = 0;
			g_play_index = -1;
			g_file_num = g_file_num_a = g_file_num_b = 0;
			for (i=0 ; i<625 ; i++) {
				avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
				avi_file_table_b[i] = jpg_file_table_b[i] = 0;
			}

			curr_storage_id = NO_STORAGE;
			msgQSend(ApQ, MSG_STORAGE_SERVICE_NO_STORAGE, &curr_storage_id, sizeof(INT8U), MSG_PRI_NORMAL);
		}

	  #if (defined RAMDISK_EN) && (RAMDISK_EN == 1)
		else
		{
			chdir("D:\\DCIM");
		}
	  #endif

		ap_storage_service_timer_start();		//enable again
		return STATUS_FAIL;
	} else {
        device_plug_phase = 1;  // plug in phase

		if (curr_storage_id != MINI_DVR_STORAGE_TYPE) {

			// add by josephhsieh@140717 // �Y�ù��O�@�}�ɡA�n�I�G�I��
			if(screen_saver_enable) {
				screen_saver_enable = 0;
	        		ap_state_handling_lcd_backlight_switch(1);
			}

		  #if (defined RAMDISK_EN) && (RAMDISK_EN == 1)
			if(curr_storage_id == NO_STORAGE) {
				_deviceunmount(RAMDISK_TYPE);
			}
		  #endif

			size = vfsFreeSpace(MINI_DVR_STORAGE_TYPE)>>20;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Mount OK, free size [%d]\r\n", size);
			curr_storage_id = MINI_DVR_STORAGE_TYPE;

			mkdir("C:\\DCIM");
			mkdir("C:\\DCIM\\DCIMA");
			mkdir("C:\\DCIM\\DCIMB");
			chdir("C:\\DCIM");

			g_file_num = g_file_num_a = g_file_num_b = 0;
			for (i=0; i<AP_STG_MAX_FILE_NUMS; i++) {
				avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
				avi_file_table_b[i] = jpg_file_table_b[i] = 0;
			}

			get_file_final_avi_index();
			get_file_final_jpeg_index();
			get_file_final_wav_index();
			get_file_index();

			if(!g_avi_index_9999_exist) {
				g_oldest_avi_file_index = temp_oldest_avi_index;
				if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
			}

			if (sd_upgrade_file_flag == 0) {
				chdir("C:\\");
				fd = open((CHAR*)"C:\\gp_cardvr_upgrade.bin", O_RDONLY);
				if (fd < 0) {
					sd_upgrade_file_flag = 1; //no need upgrade
					chdir("C:\\DCIM");
				} else {
					close(fd);
					sd_upgrade_file_flag = 2; //want to upgrade
				}
			}
			msgQSend(ApQ, MSG_STORAGE_SERVICE_MOUNT, &curr_storage_id, sizeof(INT8U), MSG_PRI_NORMAL);
		} else {
			chdir("C:\\DCIM");
		}

		//---------------------------------------------------------
		// Directory Cache Init

		if(start_sector_of_root == 0) {
			start_sector_of_root = UsrGetRootStartSector(MINI_DVR_STORAGE_TYPE);
			fd = UsrOpenDir((CHAR *)"C:\\DCIM", O_RDONLY);
			if(fd >= 0) {
				start_cluster_of_dcim = _GetCluster(fd);
				start_sector_of_dcim = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcim);
				close(fd);
				
				fd = UsrOpenDir((CHAR *)"C:\\DCIM\\DCIMA", O_RDONLY);
				if(fd >= 0) {
					start_cluster_of_dcima = _GetCluster(fd);
					start_sector_of_dcima = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcima);
					close(fd);

					fd = UsrOpenDir((CHAR *)"C:\\DCIM\\DCIMB", O_RDONLY);
					if(fd >= 0) {
						start_cluster_of_dcimb = _GetCluster(fd);
						start_sector_of_dcimb = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcimb);
						close(fd);
					}
				}
			}
		}

		//---------------------------------------------------------

		ap_storage_service_timer_start();		//enable again
		return STATUS_OK;
	}
}


#define MB_PER_MIN_BACK		75		//75MB per min

void ap_storage_service_file_open_handle(INT32U req_type, INT16U usr_config)
{
	const INT32U temp1[6] = {200, 200, 160, 130, 100, 50};  //1080FHD, 1080P, 720P, WVGA, VGA, QVGA
	const INT8U temp2[6] = {5, 1, 2, 3, 5, 10};	//unit: minute

	INT32U reply_type, MB_per_min, file_size_to_create;
	STOR_SERV_FILEINFO file_info;
	CHAR f_name[24], f_name_b[24];
    struct stat_t buf_tmp, buf_tmp_b;
	INT32S del_index, i, ret;

	ap_storage_service_timer_stop();

	while ((avi_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) || (avi_file_table_b[g_file_index >> 4] & (1 << (g_file_index & 0xF))) ||
		(jpg_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) || (jpg_file_table_b[g_file_index >> 4] & (1 << (g_file_index & 0xF))) ||
		(wav_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) )
	{
		g_file_index++;
		if(g_file_index > 9999) {
			g_file_index = 0;
		}
	}

    switch (req_type)
    {
    	case MSG_STORAGE_SERVICE_VID_REQ:
			if(back_sensor_plug_status_get()) {
				dual_mode = 1;
			} else {
				dual_mode = 0;
			}

			rec_time_config = usr_config >> 8;
			if(rec_time_config > 5) rec_time_config = 5;

			if(rec_time_config == 0) cyclic_off = 1;
			else cyclic_off = 0;

			rec_resolution_config = usr_config & 0xff;
			if(rec_resolution_config > 5) rec_resolution_config = 5;

			MB_per_min = temp1[rec_resolution_config];
			avi_file_size = temp2[rec_time_config] * MB_per_min;
			avi_file_size_back = temp2[rec_time_config] * MB_PER_MIN_BACK;	//75MB per minute

			if(dual_mode) {
				file_size_to_create = avi_file_size + avi_file_size_back;
			} else {
				file_size_to_create = avi_file_size;
			}
			file_size_to_create <<= 20;

			i = 0;
			ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
			if(ret < 2) {
				if(cyclic_off) i = 10000;
				for(; i<10000; i++) {
				    del_index = g_oldest_avi_file_index;
					if((del_index & 0x000f) == 0) {
						if((avi_file_table[del_index >> 4] == 0) && (avi_file_table_b[del_index >> 4] == 0)) {
							g_oldest_avi_file_index += 16;
							if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
							i += 15;
							continue;
						}
					}

					if (avi_file_table[del_index >> 4] & (1<<(del_index & 0x000f))) {
						sprintf((char *)f_name, (const char *)"DCIMA\\MOVA%04d.avi", del_index);
						if((stat(f_name, &buf_tmp) == SUCCESS) && (buf_tmp.st_mode != D_RDONLY)) {
							DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name);
							unlink((CHAR *)f_name);
							avi_file_table[del_index >> 4] &= ~(1 << (del_index & 0xF));

							ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
							if(ret >= 2) break;
						}
					}

					if (avi_file_table_b[del_index >> 4] & (1<<(del_index & 0x000f))) {
						sprintf((char *)f_name_b, (const char *)"DCIMB\\MOVB%04d.avi", del_index);
						if((stat(f_name_b, &buf_tmp_b) == SUCCESS) && (buf_tmp_b.st_mode != D_RDONLY)) {
							DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name_b);
							unlink((CHAR *)f_name_b);
							avi_file_table_b[del_index >> 4] &= ~(1 << (del_index & 0xF));

							ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
							if(ret >= 2) {
								del_index += 1;
								if(del_index > 9999) del_index = 0;
								g_oldest_avi_file_index = del_index;
								break;
							}
	    				}
					}

					del_index += 1;
					if(del_index > 9999) del_index = 0;
					g_oldest_avi_file_index = del_index;
				}
			}

			UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);

		  #if CREATE_FILE_DEBUG
			FatSpeedUpPrintf(MINI_DVR_STORAGE_TYPE);
		  #endif

			reply_type = MSG_STORAGE_SERVICE_VID_REPLY;
			if(i >= 10000) {
				file_info.file_handle = -1;
				file_info.file_handle_b = -1;
			} else {
				sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_file_index);
				sprintf((char *)g_file_path_b, (const char *)"DCIMB\\MOVB%04d.avi", g_file_index);
				file_info.file_path_addr = (INT32U) g_file_path;
				file_info.file_path_addr_b = (INT32U) g_file_path_b;
				file_info.file_handle = CreatFileBySize(g_file_path, (avi_file_size << 20));
				if(file_info.file_handle >= 0) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FileName = %s\r\n", file_info.file_path_addr);
					avi_file_table[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
					if(dual_mode) {
						file_info.file_handle_b = CreatFileBySize(g_file_path_b, (avi_file_size_back << 20));
						DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BackFileName = %s\r\n", file_info.file_path_addr_b);
						avi_file_table_b[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
					} else {
						file_info.file_handle_b = -1;
					}

					g_file_index++;
					if(g_file_index == 10000){
						g_file_index = 0;
						g_avi_index_9999_exist = 1;
					}

				  #if GPS_TXT
					gp_memcpy((INT8S *)g_txt_path, (INT8S *)g_file_path, sizeof(g_file_path));
					g_txt_path[15] = 't'; g_txt_path[16] = 'x'; g_txt_path[17] = 't'; g_txt_path[18] = 0;
					file_info.txt_path_addr = (INT32U)g_txt_path;

					F_OS_AdjustCrtTimeEnable();
					file_info.txt_handle = open(g_txt_path, O_WRONLY|O_CREAT|O_TRUNC);
					F_OS_AdjustCrtTimeDisable();
				  #endif

				} else {
					file_info.file_handle_b = -1;
				}

			  #if CREATE_FILE_DEBUG
				FatSpeedUpPrintf(MINI_DVR_STORAGE_TYPE);
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("\r\n");
			  #endif

			}
            break;

        case MSG_STORAGE_SERVICE_PIC_REQ:
			reply_type = MSG_STORAGE_SERVICE_PIC_REPLY;

			if (curr_storage_id != NO_STORAGE) {
			  #if ENABLE_SAVE_SENSOR_RAW_DATA
				sprintf((char *)g_file_path, (const char *)"PICT%04d.dat", g_file_index);
			  #else
				sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_file_index);
				sprintf((char *)g_file_path_b, (const char *)"DCIMB\\PICB%04d.jpg", g_file_index);
			  #endif
				file_info.file_path_addr = (INT32U) g_file_path;
				file_info.file_handle = open (g_file_path, O_WRONLY|O_CREAT|O_TRUNC);
				if (file_info.file_handle >= 0) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FileName = %s\r\n", file_info.file_path_addr);
					jpg_file_table[g_file_index >> 4] |= 1 << (g_file_index & 0xF);

				  #if !ENABLE_SAVE_SENSOR_RAW_DATA
					if(back_sensor_plug_status_get()) {
						file_info.file_path_addr_b = (INT32U) g_file_path_b;
						file_info.file_handle_b = open (g_file_path_b, O_WRONLY|O_CREAT|O_TRUNC);
						DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("Back FileName = %s\r\n", file_info.file_path_addr_b);
						jpg_file_table_b[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
					} else 
				  #endif
					{
						file_info.file_handle_b = -1;
					}

					g_file_index++;
					if(g_file_index == 10000) {
						g_file_index = 0;
						g_avi_index_9999_exist = 1;
					}

				} else {
					file_info.file_handle_b = -1;
				}
			} else {
			  #if (defined RAMDISK_EN) && (RAMDISK_EN == 1)
				g_file_index = 0;
				#if ENABLE_SAVE_SENSOR_RAW_DATA
				sprintf((char *)g_file_path, (const char *)"PICT%04d.dat", g_file_index);
				#else
				sprintf((char *)g_file_path, (const char *)"PICT%04d.jpg", g_file_index);
				#endif
				unlink(g_file_path); //because O_TRUNC is disabled
				file_info.file_path_addr = (INT32U) g_file_path;
				file_info.file_handle = open (g_file_path, O_WRONLY|O_CREAT|O_TRUNC);
				if(file_info.file_handle >= 0) {
					jpg_file_table[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
				}
			  #else
			  	file_info.file_handle = -1;
			  	file_info.file_handle_b = -1;
			  #endif
			}
            break;

    	case MSG_STORAGE_SERVICE_AUD_REQ:
			reply_type = MSG_STORAGE_SERVICE_AUD_REPLY;
		  #if AUD_REC_FORMAT == AUD_FORMAT_WAV
			sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_file_index);//20110927
		  #else
			sprintf((char *)g_file_path, (const char *)"RECR%04d.mp3", g_file_index);//20110927
		  #endif
			file_info.file_handle = open (g_file_path, O_WRONLY|O_CREAT|O_TRUNC);
			if (file_info.file_handle >= 0) {
				file_info.file_path_addr = (INT32U) g_file_path;

				g_file_index++;
				if(g_file_index == 10000){
					g_file_index = 0;
					g_avi_index_9999_exist = 1;
				}

				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FileName = %s\r\n", file_info.file_path_addr);
				wav_file_table[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
			}
			break;

        default:
            DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT ("UNKNOW STORAGE SERVICE\r\n");
            break;
    }
	msgQSend(ApQ, reply_type, &file_info, sizeof(STOR_SERV_FILEINFO), MSG_PRI_NORMAL);
}


#if C_CYCLIC_VIDEO_RECORD == CUSTOM_ON
void ap_storage_service_cyclic_record_file_open_handle(void)
{
	INT32U reply_type;
	STOR_SERV_FILEINFO file_info;
	CHAR f_name[24], f_name_b[24];
    struct stat_t buf_tmp, buf_tmp_b;
	INT32S del_index, i, ret;
	INT32U file_size_to_create;

	ap_storage_service_timer_stop();

	while ((avi_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) || (avi_file_table_b[g_file_index >> 4] & (1 << (g_file_index & 0xF))) ||
		(jpg_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) || (jpg_file_table_b[g_file_index >> 4] & (1 << (g_file_index & 0xF))) ||
		(wav_file_table[g_file_index >> 4] & (1 << (g_file_index & 0xF))) )
	{
		g_file_index++;
		if(g_file_index > 9999) {
			g_file_index = 0;
		}
	}

	if(dual_mode) {
		file_size_to_create = avi_file_size + avi_file_size_back;
	} else {
		file_size_to_create = avi_file_size;
	}
	file_size_to_create <<= 20;

	i = 0;
	ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
	if(ret < 2)	{
		if(cyclic_off) i = 10000;
		for(; i<10000; i++) {
		    del_index = g_oldest_avi_file_index;
			if((del_index & 0x000f) == 0) {
				if((avi_file_table[del_index >> 4] == 0) && (avi_file_table_b[del_index >> 4] == 0)) {
					g_oldest_avi_file_index += 16;
					if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
					i += 15;
					continue;
				}
			}

			if (avi_file_table[del_index >> 4] & (1<<(del_index & 0x000f))) {
				sprintf((char *)f_name, (const char *)"DCIMA\\MOVA%04d.avi", del_index);
				if((stat(f_name, &buf_tmp) == SUCCESS) && (buf_tmp.st_mode != D_RDONLY)) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name);
					unlink((CHAR *)f_name);
					avi_file_table[del_index >> 4] &= ~(1 << (del_index & 0xF));

					ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
					if(ret >= 2) break;
				}
			}

			if (avi_file_table_b[del_index >> 4] & (1<<(del_index & 0x000f))) {
				sprintf((char *)f_name_b, (const char *)"DCIMB\\MOVB%04d.avi", del_index);
				if((stat(f_name_b, &buf_tmp_b) == SUCCESS) && (buf_tmp_b.st_mode != D_RDONLY)) {
					DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("del = %s\r\n", f_name_b);
					unlink((CHAR *)f_name_b);
					avi_file_table_b[del_index >> 4] &= ~(1 << (del_index & 0xF));

					ret = UsrCheckFreeSize(MINI_DVR_STORAGE_TYPE, file_size_to_create);
					if(ret >= 2) {
						del_index += 1;
						if(del_index > 9999) del_index = 0;
						g_oldest_avi_file_index = del_index;
						break;
					}
				}
			}

			del_index += 1;
			if(del_index > 9999) del_index = 0;
			g_oldest_avi_file_index = del_index;
		}
	}

	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);

  #if CREATE_FILE_DEBUG
	FatSpeedUpPrintf(MINI_DVR_STORAGE_TYPE);
  #endif

	reply_type = MSG_STORAGE_SERVICE_VID_CYCLIC_REPLY;
	if(i >= 10000) {
		file_info.file_handle = -1;
		file_info.file_handle_b = -1;
	} else {
		sprintf((char *)g_next_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_file_index);
		sprintf((char *)g_next_file_path_b, (const char *)"DCIMB\\MOVB%04d.avi", g_file_index);
		file_info.file_path_addr = (INT32U) g_next_file_path;
		file_info.file_path_addr_b = (INT32U) g_next_file_path_b;
		file_info.file_handle = CreatFileBySize(g_next_file_path, (avi_file_size << 20));
		if(file_info.file_handle >= 0) {
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("FileName = %s\r\n", file_info.file_path_addr);
			avi_file_table[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
			if(dual_mode) {
				file_info.file_handle_b = CreatFileBySize(g_next_file_path_b, (avi_file_size_back << 20));
				DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("BackFileName = %s\r\n", file_info.file_path_addr_b);
				avi_file_table_b[g_file_index >> 4] |= 1 << (g_file_index & 0xF);
			} else {
				file_info.file_handle_b = -1;
			}

			g_file_index++;
			if(g_file_index == 10000){
				g_file_index = 0;
				g_avi_index_9999_exist = 1;
			}

		  #if GPS_TXT
			gp_memcpy((INT8S *)g_txt_path, (INT8S *)g_next_file_path, sizeof(g_next_file_path));
			g_txt_path[15] = 't'; g_txt_path[16] = 'x'; g_txt_path[17] = 't'; g_txt_path[18] = 0;
			file_info.txt_path_addr = (INT32U)g_txt_path;

			F_OS_AdjustCrtTimeEnable();
			file_info.txt_handle = open(g_txt_path, O_WRONLY|O_CREAT|O_TRUNC);
			F_OS_AdjustCrtTimeDisable();
		  #endif

		} else {
			file_info.file_handle_b = -1;
		}

	  #if CREATE_FILE_DEBUG
		FatSpeedUpPrintf(MINI_DVR_STORAGE_TYPE);
	  #endif

	}
	msgQSend(ApQ, reply_type, &file_info, sizeof(STOR_SERV_FILEINFO), MSG_PRI_NORMAL);
}
#endif

static void select_latest_file_for_browsing(STOR_SERV_PLAYINFO *info_ptr, INT8U select_a_b)
{
	struct stat_t buf_tmp;

	if(g_avi_index_9999_exist) {
		if(select_a_b == 0) { //DCIMA
			if(g_avi_file_time_a > g_jpg_file_time_a)
			{
				if(g_avi_file_time_a > g_wav_file_time)
				{
					info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;
					g_play_index = g_avi_index_a - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_play_index);
				  #if RENAME_LOCK_FILE
					if(stat(g_file_path, &buf_tmp) != SUCCESS) {
						sprintf((char *)g_file_path, (const char *)"DCIMA\\LOCA%04d.avi", g_play_index);
					}
				  #endif
				} else {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					g_play_index = g_wav_index - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
				}
			}
			else
			{
				if(g_jpg_file_time_a > g_wav_file_time)
				{
					info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
					g_play_index = g_jpeg_index_a - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_play_index);
				} else {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					g_play_index = g_wav_index - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
				}
			}
		} else { //DCIMB
			if(g_avi_file_time_b > g_jpg_file_time_b)
			{
				info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;
				g_play_index = g_avi_index_b - 1;
				if(g_play_index < 0) {
					g_play_index = 9999;
				}
				sprintf((char *)g_file_path, (const char *)"DCIMB\\MOVB%04d.avi", g_play_index);
			  #if RENAME_LOCK_FILE
				if(stat(g_file_path, &buf_tmp) != SUCCESS) {
					sprintf((char *)g_file_path, (const char *)"DCIMB\\LOCB%04d.avi", g_play_index);
				}
			  #endif
			}
			else
			{
				info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
				g_play_index = g_jpeg_index_b - 1;
				if(g_play_index < 0) {
					g_play_index = 9999;
				}
				sprintf((char *)g_file_path, (const char *)"DCIMB\\PICB%04d.jpg", g_play_index);
			}
		}
	} else {
		if(select_a_b == 0) { //DCIMA
			if (g_jpeg_index_a > g_avi_index_a) 
			{
				if(g_jpeg_index_a > g_wav_index)
				{
					info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
					g_play_index = g_jpeg_index_a - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_play_index);
				} else {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					g_play_index = g_wav_index - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);				
				}
			} else {
				if(g_avi_index_a > g_wav_index)
				{
					info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;
					g_play_index = g_avi_index_a - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_play_index);
				  #if RENAME_LOCK_FILE
					if(stat(g_file_path, &buf_tmp) != SUCCESS) {
						sprintf((char *)g_file_path, (const char *)"DCIMA\\LOCA%04d.avi", g_play_index);
					}
				  #endif
				} else {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					g_play_index = g_wav_index - 1;
					if(g_play_index < 0) {
						g_play_index = 9999;
					}
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
				}
			}
		} else { //DCIMB
			if (g_jpeg_index_b > g_avi_index_b) 
			{
				info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
				g_play_index = g_jpeg_index_b - 1;
				if(g_play_index < 0) {
					g_play_index = 9999;
				}
				sprintf((char *)g_file_path, (const char *)"DCIMB\\PICB%04d.jpg", g_play_index);
			} else {
				info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;
				g_play_index = g_avi_index_b - 1;
				if(g_play_index < 0) {
					g_play_index = 9999;
				}
				sprintf((char *)g_file_path, (const char *)"DCIMB\\MOVB%04d.avi", g_play_index);
			  #if RENAME_LOCK_FILE
				if(stat(g_file_path, &buf_tmp) != SUCCESS) {
					sprintf((char *)g_file_path, (const char *)"DCIMB\\LOCB%04d.avi", g_play_index);
				}
			  #endif
			}
		}
	}
}



void ap_storage_service_play_req(STOR_SERV_PLAYINFO *info_ptr, INT32U req_msg)
{
	INT16S index_tmp, i = 0, k, l;
	INT8U type = (req_msg & 0xFF), err_flag = ((req_msg & 0xFF00) >> 8);
	INT16U given_play_index = ((req_msg>>16) & 0xFFFF);
	struct stat_t buf_tmp;

	ap_storage_service_timer_stop();

	info_ptr->search_type = type;
	if (type == STOR_SERV_SEARCH_INIT) {
		g_play_index = -1;
	}

	if (g_play_index < 0) {
		INT8U select_a_b;

		g_file_num = g_file_num_a = g_file_num_b = 0;
		for (i=0; i<AP_STG_MAX_FILE_NUMS; i++) {
			avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
			avi_file_table_b[i] = jpg_file_table_b[i] = 0;
		}

		get_file_final_avi_index();
		get_file_final_jpeg_index();
		get_file_final_wav_index();
		get_file_index();

		if(!g_avi_index_9999_exist) {
			g_oldest_avi_file_index = temp_oldest_avi_index;
			if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
		}

		g_play_index = g_file_index_b_max - 1;
		deleted_num_b_max = get_deleted_file_number(1);

		if(g_file_num_a) {
			select_a_b = 0;
			g_trace_cnt = g_file_num_a - 1;
		} else if(g_file_num_b) {
			select_a_b = 1;
			g_trace_cnt = g_file_num_b - 1;
		} else if(g_wav_index) {
			info_ptr->file_type = TK_IMAGE_TYPE_WAV;
			g_play_index = g_wav_index - 1;
			if(g_play_index < 0) {
				g_play_index = 9999;
			}
			sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
		} else {
			info_ptr->err_flag = STOR_SERV_NO_MEDIA;
			msgQSend(ApQ, MSG_STORAGE_SERVICE_BROWSE_REPLY, info_ptr, sizeof(STOR_SERV_PLAYINFO), MSG_PRI_NORMAL);
			return;
		}

		if(g_file_num_a || g_file_num_b) {
			select_latest_file_for_browsing(info_ptr, select_a_b);
		}
	} else {
		if (type == STOR_SERV_SEARCH_PREV) {
			INT8U flag = 0;
			INT8U select_a_b, switch_flag = 0;

			if(g_file_num_a || g_file_num_b) {
				g_trace_cnt--;
				if(g_trace_cnt > 9999) {
					switch_flag = 1;

					if((g_file_path[4] == 'A') && g_file_num_b) {
						g_trace_cnt = g_file_num_b - 1;
						select_a_b = 1;
					} else if((g_file_path[4] == 'B') && g_file_num_a) {
						g_trace_cnt = g_file_num_a - 1;
						select_a_b = 0;
					} else if(g_file_path[4] == 'A') {
						g_trace_cnt = g_file_num_a - 1;
						select_a_b = 0;
					} else {
						g_trace_cnt = g_file_num_b - 1;
						select_a_b = 1;
					}
				} else {
					if(g_file_path[4] == 'A') select_a_b = 0;
					else select_a_b = 1;
				}
			}

			if(switch_flag) {
				select_latest_file_for_browsing(info_ptr, select_a_b);
			} else {
				index_tmp = g_play_index - 1;
				if (index_tmp < 0) {
					index_tmp = 9999;
				}
				k = index_tmp >> 4;
				l = index_tmp & 0xF;
				while (i <= 626) {
					i++;
					if (avi_file_table[k] || jpg_file_table[k] || avi_file_table_b[k] || jpg_file_table_b[k] || wav_file_table[k]) {
						for ( ; l>=0 ; l--) {
							if(select_a_b == 0) {
								if (avi_file_table[k] & (1<<l)) {
									g_play_index = (k << 4) + l;
									info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;

									sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_play_index);
									if(stat(g_file_path, &buf_tmp) != SUCCESS) {
									  #if RENAME_LOCK_FILE
										sprintf((char *)g_file_path, (const char *)"DCIMA\\LOCA%04d.avi", g_play_index);
										if(stat(g_file_path, &buf_tmp) != SUCCESS)
									  #endif
									  	continue;
									}
									flag = 1;
									break;
								} else if (jpg_file_table[k] & (1<<l)) {
									g_play_index = (k << 4) + l;
									info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
									sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_play_index);
									flag = 1;
									break;
								}
							} else {
								if (avi_file_table_b[k] & (1<<l)) {
									g_play_index = (k << 4) + l;
									info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;

									sprintf((char *)g_file_path, (const char *)"DCIMB\\MOVB%04d.avi", g_play_index);
									if(stat(g_file_path, &buf_tmp) != SUCCESS) {
									  #if RENAME_LOCK_FILE
										sprintf((char *)g_file_path, (const char *)"DCIMB\\LOCB%04d.avi", g_play_index);
										if(stat(g_file_path, &buf_tmp) != SUCCESS)
									  #endif
										continue;
									}
									flag = 1;
									break;
								} else if (jpg_file_table_b[k] & (1<<l)) {
									g_play_index = (k << 4) + l;
									info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
									sprintf((char *)g_file_path, (const char *)"DCIMB\\PICB%04d.jpg", g_play_index);
									flag = 1;
									break;
								}
							}

							if (wav_file_table[k] & (1<<l)) {
								g_play_index = (k << 4) + l;
								info_ptr->file_type = TK_IMAGE_TYPE_WAV;
								sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
								flag = 1;
								break;
							}
						}
						if(flag) {
							break;
						}
					}
					l = 0xF;
					k--;
					if (k < 0) {
						k = 624;
					}
				}

				if (i > 626) {
					info_ptr->err_flag = STOR_SERV_NO_MEDIA;
					g_err_cnt = 0;
					msgQSend(ApQ, MSG_STORAGE_SERVICE_BROWSE_REPLY, info_ptr, sizeof(STOR_SERV_PLAYINFO), MSG_PRI_NORMAL);
					return;
				}
			}
		} else if (type == STOR_SERV_SEARCH_NEXT) {
			INT8U flag = 0;
			INT8U select_a_b, switch_flag = 0;

			if(g_file_num_a || g_file_num_b) {
				g_trace_cnt++;
				if(g_file_path[4] == 'A') {
					if(g_trace_cnt >= g_file_num_a) {
						g_trace_cnt = 0;
						switch_flag = 1;

						if(g_file_num_b) {
							select_a_b = 1;
						} else {
							select_a_b = 0;
						}
					} else {
						if(g_file_path[4] == 'A') select_a_b = 0;
						else select_a_b = 1;
					}
				} else {
					if(g_trace_cnt >= g_file_num_b) {
						g_trace_cnt = 0;
						switch_flag = 1;

						if(g_file_num_a) {
							select_a_b = 0;
						} else {
							select_a_b = 1;
						}
					} else {
						if(g_file_path[4] == 'A') select_a_b = 0;
						else select_a_b = 1;
					}
				}
			}

			if(switch_flag) {
				select_latest_file_for_browsing(info_ptr, select_a_b);
			}

			index_tmp = g_play_index + 1;
			if (index_tmp > 9999) {
				index_tmp = 0;
			}
			k = index_tmp >> 4;
			l = index_tmp & 0xF;
			while (i <= 626) {
				i++;
				if (avi_file_table[k] || jpg_file_table[k] || avi_file_table_b[k] || jpg_file_table_b[k] || wav_file_table[k]) {
					for ( ; l<0x10 ; l++) {
						if(select_a_b == 0) {
							if (avi_file_table[k] & (1<<l)) {
								g_play_index = (k << 4) + l;
								info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;

								sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_play_index);
								if(stat(g_file_path, &buf_tmp) != SUCCESS) {
								  #if RENAME_LOCK_FILE
									sprintf((char *)g_file_path, (const char *)"DCIMA\\LOCA%04d.avi", g_play_index);
									if(stat(g_file_path, &buf_tmp) != SUCCESS)
								  #endif
								  	continue;
								}
								flag = 1;
								break;
							} else if (jpg_file_table[k] & (1<<l)) {
								g_play_index = (k << 4) + l;
								info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
								sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_play_index);
								flag = 1;
								break;
							}
						} else {
							if (avi_file_table_b[k] & (1<<l)) {
								g_play_index = (k << 4) + l;
								info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;

								sprintf((char *)g_file_path, (const char *)"DCIMB\\MOVB%04d.avi", g_play_index);
								if(stat(g_file_path, &buf_tmp) != SUCCESS) {
								  #if RENAME_LOCK_FILE
									sprintf((char *)g_file_path, (const char *)"DCIMB\\LOCB%04d.avi", g_play_index);
									if(stat(g_file_path, &buf_tmp) != SUCCESS)
								  #endif
									continue;
								}
								flag = 1;
								break;
							} else if (jpg_file_table_b[k] & (1<<l)) {
								g_play_index = (k << 4) + l;
								info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
								sprintf((char *)g_file_path, (const char *)"DCIMB\\PICB%04d.jpg", g_play_index);
								flag = 1;
								break;
							}
						}

						if (wav_file_table[k] & (1<<l)) {
							g_play_index = (k << 4) + l;
							info_ptr->file_type = TK_IMAGE_TYPE_WAV;
							sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
							flag = 1;
							break;
						}
					}
					if(flag) {
						break;
					}
				}
				l = 0x0;
				k++;
				if (k > 624) {
					k = 0;
				}
			}

			if (i > 626) {
				info_ptr->err_flag = STOR_SERV_NO_MEDIA;
				g_err_cnt = 0;
				msgQSend(ApQ, MSG_STORAGE_SERVICE_BROWSE_REPLY, info_ptr, sizeof(STOR_SERV_PLAYINFO), MSG_PRI_NORMAL);
				return;
			}
		} else {
			INT8U select_a_b;

			if (type == STOR_SERV_SEARCH_GIVEN) {
				g_play_index = given_play_index;
				if(g_file_num_a && (g_play_index >= (g_file_num_b + deleted_num_b_max))) {
					select_a_b = 0;
					g_play_index -= (g_file_num_b + deleted_num_b_max);
					g_trace_cnt = g_play_index - get_deleted_file_number(0);
				} else {
					select_a_b = 1;
					g_trace_cnt = g_play_index - get_deleted_file_number(1);
				}
			} else {
				if(g_file_path[4] == 'A') select_a_b = 0;
				else select_a_b = 1;
			}

			k = g_play_index >> 4;
			l = g_play_index & 0xF;

			if(select_a_b == 0) {
				if (avi_file_table[k] & (1<<l)) {
					info_ptr->file_type = TK_IMAGE_TYPE_MOTION_JPEG;
					sprintf((char *)g_file_path, (const char *)"DCIMA\\MOVA%04d.avi", g_play_index);
				  #if RENAME_LOCK_FILE
					if(stat(g_file_path, &buf_tmp) != SUCCESS) {
						sprintf((char *)g_file_path, (const char *)"DCIMA\\LOCA%04d.avi", g_play_index);
					}
				  #endif
				} else if (jpg_file_table[k] & (1<<l)) {
					info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
					sprintf((char *)g_file_path, (const char *)"DCIMA\\PICA%04d.jpg", g_play_index);
				} else if (wav_file_table[k] & (1<<l)) {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
				}
			} else {
				if (avi_file_table_b[k] & (1<<l)) {
					sprintf((char *)g_file_path, (const char *)"DCIMB\\MOVB%04d.avi", g_play_index);
				  #if RENAME_LOCK_FILE
					if(stat(g_file_path, &buf_tmp) != SUCCESS) {
						sprintf((char *)g_file_path, (const char *)"DCIMB\\LOCB%04d.avi", g_play_index);
					}
				  #endif
				} else if (jpg_file_table_b[k] & (1<<l)) {
					info_ptr->file_type = TK_IMAGE_TYPE_JPEG;
					sprintf((char *)g_file_path, (const char *)"DCIMB\\PICB%04d.jpg", g_play_index);
				} else if (wav_file_table[k] & (1<<l)) {
					info_ptr->file_type = TK_IMAGE_TYPE_WAV;
					sprintf((char *)g_file_path, (const char *)"RECR%04d.wav", g_play_index);
				}
			}
		}
	}

	DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("File Path=%s\r\n", g_file_path);

	info_ptr->file_path_addr = (INT32U) g_file_path;
	info_ptr->file_handle = open(g_file_path, O_RDONLY);
	if (info_ptr->file_handle >= 0) {
		stat(g_file_path, &buf_tmp);
		info_ptr->file_size = buf_tmp.st_size;
		if (!err_flag) {
			info_ptr->err_flag = STOR_SERV_OPEN_OK;
			g_err_cnt = 0;
		} else {
			g_err_cnt++;
			if (g_err_cnt <= g_file_num) {
				info_ptr->err_flag = STOR_SERV_OPEN_OK;
			} else {
				info_ptr->err_flag = STOR_SERV_DECODE_ALL_FAIL;
			}
		}
	} else {
		info_ptr->err_flag = STOR_SERV_OPEN_FAIL;
		g_err_cnt = 0;
	}

	if(g_file_path[4] == 'A') {
		info_ptr->deleted_file_number = get_deleted_file_number(0) + deleted_num_b_max;
	} else {
		info_ptr->deleted_file_number = get_deleted_file_number(1);
	}

	info_ptr->play_index = g_play_index;
	if(g_file_path[4] == 'A') {
		info_ptr->play_index += (g_file_num_b + deleted_num_b_max);
	}
	info_ptr->total_file_number = g_file_num;
	msgQSend(ApQ, MSG_STORAGE_SERVICE_BROWSE_REPLY, info_ptr, sizeof(STOR_SERV_PLAYINFO), MSG_PRI_NORMAL);
}

INT32S get_file_final_avi_index(void)
{
	CHAR  *pdata;
	INT32S nRet, temp;
	INT32U temp_time;
	struct f_info file_info;

	g_file_index_b_max = 0;
	g_avi_index = g_avi_index_a = g_avi_index_b = -1;
	g_avi_index_9999_exist = g_avi_file_time = g_avi_file_oldest_time = 0;
	g_avi_file_time_a = g_avi_file_time_b = 0;

	temp_oldest_avi_index = 10000;

	chdir("C:\\DCIM\\DCIMA");

	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if(nRet >= 0) {
		while (1) {
			pdata = (CHAR *) file_info.f_name;
		  #if !RENAME_LOCK_FILE
			if (gp_strncmp((INT8S *) pdata, (INT8S *) "MOV", 3) == 0)
		  #else
			if ((gp_strncmp((INT8S *) pdata, (INT8S *) "MOV", 3) == 0)
				|| (gp_strncmp((INT8S *) pdata, (INT8S *) "LOC", 3) == 0))
		  #endif
			{
				temp = (*(pdata + 4) - 0x30)*1000;
				temp += (*(pdata + 5) - 0x30)*100;
				temp += (*(pdata + 6) - 0x30)*10;
				temp += (*(pdata + 7) - 0x30);
				if (temp < 10000) {
					avi_file_table[temp >> 4] |= 1 << (temp & 0xF);

					g_file_num_a++;
					if(temp > g_avi_index_a) {
						g_avi_index_a = temp;
					}

					g_file_num++;
					if (temp > g_avi_index) {
						g_avi_index = temp;
					}

					temp_time = (file_info.f_date<<16)|file_info.f_time;
					if((!g_avi_file_time) || (temp_time > g_avi_file_time)) {
						g_avi_file_time = temp_time;
						g_latest_avi_file_index = temp;
					}

					if((!g_avi_file_time_a) || (temp_time > g_avi_file_time_a)) {
						g_avi_file_time_a = temp_time;
						g_latest_avi_file_index_a = temp;
					}

					if( ((!g_avi_file_oldest_time) || (temp_time < g_avi_file_oldest_time)) && ((file_info.f_attrib & _A_RDONLY) == 0) ){
						g_avi_file_oldest_time = temp_time;
						g_oldest_avi_file_index = temp;
					}
					
					if(temp < temp_oldest_avi_index) {
						temp_oldest_avi_index = temp;
					}
				}
			}
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;	
			}
		}
	}

	chdir("C:\\DCIM\\DCIMB");

	nRet = _findfirst("*.avi", &file_info, D_ALL);
	if(nRet >= 0) {
		while (1) {
			pdata = (CHAR *) file_info.f_name;
		  #if !RENAME_LOCK_FILE
			if (gp_strncmp((INT8S *) pdata, (INT8S *) "MOV", 3) == 0)
		  #else
			if ((gp_strncmp((INT8S *) pdata, (INT8S *) "MOV", 3) == 0)
				|| (gp_strncmp((INT8S *) pdata, (INT8S *) "LOC", 3) == 0))
		  #endif
			{
				temp = (*(pdata + 4) - 0x30)*1000;
				temp += (*(pdata + 5) - 0x30)*100;
				temp += (*(pdata + 6) - 0x30)*10;
				temp += (*(pdata + 7) - 0x30);
				if (temp < 10000) {
					avi_file_table_b[temp >> 4] |= 1 << (temp & 0xF);

					g_file_num_b++;
					if(temp > g_avi_index_b) {
						g_avi_index_b = temp;
					}

					g_file_num++;
					if (temp > g_avi_index) {
						g_avi_index = temp;
					}

					temp_time = (file_info.f_date<<16)|file_info.f_time;
					if((!g_avi_file_time) || (temp_time > g_avi_file_time)) {
						g_avi_file_time = temp_time;
						g_latest_avi_file_index = temp;
					}

					if((!g_avi_file_time_b) || (temp_time > g_avi_file_time_b)) {
						g_avi_file_time_b = temp_time;
						g_latest_avi_file_index_b = temp;
					}

					if( ((!g_avi_file_oldest_time) || (temp_time < g_avi_file_oldest_time)) && ((file_info.f_attrib & _A_RDONLY) == 0) ){
						g_avi_file_oldest_time = temp_time;
						g_oldest_avi_file_index = temp;
					}

					if(temp < temp_oldest_avi_index) {
						temp_oldest_avi_index = temp;
					}
				}
			}
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;	
			}
		}
	}

	chdir("C:\\DCIM");

	g_avi_index++;
	g_avi_index_a++;
	g_avi_index_b++;

	g_file_index_b_max = g_avi_index_b;
	if(g_avi_index > 9999) {
		g_avi_index_9999_exist = 1;

		g_avi_index = g_latest_avi_file_index+1;
		if(g_avi_index > 9999) {
			g_avi_index = 0;
		}

		g_avi_index_a = g_latest_avi_file_index_a+1;
		if(g_avi_index_a > 9999) {
			g_avi_index_a = 0;
		}

		g_avi_index_b = g_latest_avi_file_index_b+1;
		if(g_avi_index_b > 9999) {
			g_avi_index_b = 0;
		}
	}
	
	return g_avi_index;
}

INT32S get_file_final_jpeg_index(void)
{
	CHAR  *pdata;
	struct f_info   file_info;
	INT32S nRet, temp;
	INT32U temp_time;
	
	g_jpeg_index = g_jpeg_index_a = g_jpeg_index_b = -1;
	g_jpg_file_time = g_jpg_file_time_a = g_jpg_file_time_b = 0;

	chdir("C:\\DCIM\\DCIMA");

	#if ENABLE_SAVE_SENSOR_RAW_DATA		
	nRet = _findfirst("*.dat", &file_info, D_ALL);
	#else
	nRet = _findfirst("*.jpg", &file_info, D_ALL);
	#endif

	if(nRet >= 0) {
		while (1) {
			pdata = (CHAR*)file_info.f_name;
			if (gp_strncmp((INT8S *) pdata, (INT8S *) "PIC", 3) == 0) {
				temp = (*(pdata + 4) - 0x30)*1000;
				temp += (*(pdata + 5) - 0x30)*100;
				temp += (*(pdata + 6) - 0x30)*10;
				temp += (*(pdata + 7) - 0x30);
				if (temp < 10000) {
					jpg_file_table[temp >> 4] |= 1 << (temp & 0xF);

					g_file_num_a++;
					if(temp > g_jpeg_index_a) {
						g_jpeg_index_a = temp;
					}

					g_file_num++;
					if (temp > g_jpeg_index) {
						g_jpeg_index = temp;
					}

					temp_time = (file_info.f_date<<16)|file_info.f_time;
					if( (!g_jpg_file_time) || (temp_time > g_jpg_file_time) ){
						g_jpg_file_time = temp_time;
						g_latest_jpg_file_index = temp;
					}

					if((!g_jpg_file_time_a) || (temp_time > g_jpg_file_time_a)) {
						g_jpg_file_time_a = temp_time;
						g_latest_jpg_file_index_a = temp;
					}
				}
			}		
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	chdir("C:\\DCIM\\DCIMB");

	#if ENABLE_SAVE_SENSOR_RAW_DATA		
	nRet = _findfirst("*.dat", &file_info, D_ALL);
	#else
	nRet = _findfirst("*.jpg", &file_info, D_ALL);
	#endif

	if(nRet >= 0) {
		while (1) {
			pdata = (CHAR*)file_info.f_name;
			if (gp_strncmp((INT8S *) pdata, (INT8S *) "PIC", 3) == 0) {
				temp = (*(pdata + 4) - 0x30)*1000;
				temp += (*(pdata + 5) - 0x30)*100;
				temp += (*(pdata + 6) - 0x30)*10;
				temp += (*(pdata + 7) - 0x30);
				if (temp < 10000) {
					jpg_file_table_b[temp >> 4] |= 1 << (temp & 0xF);

					g_file_num_b++;
					if(temp > g_jpeg_index_b) {
						g_jpeg_index_b = temp;
					}

					g_file_num++;
					if (temp > g_jpeg_index) {
						g_jpeg_index = temp;
					}

					temp_time = (file_info.f_date<<16)|file_info.f_time;
					if( (!g_jpg_file_time) || (temp_time > g_jpg_file_time) ){
						g_jpg_file_time = temp_time;
						g_latest_jpg_file_index = temp;
					}

					if((!g_jpg_file_time_b) || (temp_time > g_jpg_file_time_b)) {
						g_jpg_file_time_b = temp_time;
						g_latest_jpg_file_index_b = temp;
					}
				}
			}		
			nRet = _findnext(&file_info);
			if (nRet < 0) {
				break;
			}
		}
	}

	chdir("C:\\DCIM");

	g_jpeg_index++;
	g_jpeg_index_a++;
	g_jpeg_index_b++;

	if(g_jpeg_index_b > g_file_index_b_max) {
		g_file_index_b_max = g_jpeg_index_b;
	}

	if( (g_jpeg_index > 9999) || (g_avi_index_9999_exist == 1) ) {
		g_avi_index_9999_exist = 1;

		g_jpeg_index = g_latest_jpg_file_index+1;
		if(g_jpeg_index > 9999) {
			g_jpeg_index = 0;
		}

		g_avi_index = g_latest_avi_file_index+1;
		if(g_avi_index > 9999) {
			g_avi_index = 0;
		}

		g_avi_index_a = g_latest_avi_file_index_a+1;
		if(g_avi_index_a > 9999) {
			g_avi_index_a = 0;
		}

		g_avi_index_b = g_latest_avi_file_index_b+1;
		if(g_avi_index_b > 9999) {
			g_avi_index_b = 0;
		}

		g_jpeg_index_a = g_latest_jpg_file_index_a+1;
		if(g_jpeg_index_a > 9999) {
			g_jpeg_index_a = 0;
		}

		g_jpeg_index_b = g_latest_jpg_file_index_b+1;
		if(g_jpeg_index_b > 9999) {
			g_jpeg_index_b = 0;
		}
	}
	
	return g_jpeg_index;
}

INT32S get_file_final_wav_index(void)
{
	CHAR  *pdata;
	struct f_info   file_info;
    INT16S latest_file_index;
	INT32S nRet, temp;
    INT32U temp_time;

	g_wav_index = -1;
	g_wav_file_time = 0;

	nRet = _findfirst("*.wav", &file_info, D_ALL);
	if (nRet < 0) {
		g_wav_index++;
		return g_wav_index;
	}
	while (1) {
		pdata = (CHAR*)file_info.f_name;
		if (gp_strncmp((INT8S *) pdata, (INT8S *) "RECR", 4) == 0) {
			temp = (*(pdata + 4) - 0x30)*1000;
			temp += (*(pdata + 5) - 0x30)*100;
			temp += (*(pdata + 6) - 0x30)*10;
			temp += (*(pdata + 7) - 0x30);

			if (temp < 10000)
            {
				wav_file_table[temp >> 4] |= 1 << (temp & 0xF);
				g_file_num++;

    			if (temp > g_wav_index) {
    				g_wav_index = temp;
    			}

                temp_time = (file_info.f_date<<16)|file_info.f_time;

                if( (!g_wav_file_time) || (temp_time > g_wav_file_time) ){
					g_wav_file_time = temp_time;
					latest_file_index = temp;
				}
			}
		}

		nRet = _findnext(&file_info);
		if (nRet < 0) {
			break;
		}
	}
	g_wav_index++;
	if( (g_wav_index > 9999) || (g_avi_index_9999_exist == 1) ){
		g_avi_index_9999_exist = 1;

		g_wav_index = latest_file_index+1;
		if(g_wav_index > 9999) {
			g_wav_index = 0;
		}
		
		g_avi_index = g_latest_avi_file_index+1;
		if(g_avi_index > 9999) {
			g_avi_index = 0;
		}

		g_jpeg_index = g_latest_jpg_file_index+1;
		if(g_jpeg_index > 9999) {
			g_jpeg_index = 0;
		}

		g_avi_index_a = g_latest_avi_file_index_a+1;
		if(g_avi_index_a > 9999) {
			g_avi_index_a = 0;
		}

		g_avi_index_b = g_latest_avi_file_index_b+1;
		if(g_avi_index_b > 9999) {
			g_avi_index_b = 0;
		}

		g_jpeg_index_a = g_latest_jpg_file_index_a+1;
		if(g_jpeg_index_a > 9999) {
			g_jpeg_index_a = 0;
		}

		g_jpeg_index_b = g_latest_jpg_file_index_b+1;
		if(g_jpeg_index_b > 9999) {
			g_jpeg_index_b = 0;
		}
	}
	return g_wav_index;
}


void get_file_index(void)
{
	INT32U max_temp;

	if(g_avi_index_9999_exist) {
		if(g_avi_file_time > g_jpg_file_time) {
            max_temp = g_avi_index;
			if (g_avi_file_time > g_wav_file_time) {
            	g_file_index = max_temp;
			} else {
            	g_file_index = g_wav_index;
        	}
		} else {
            max_temp = g_jpeg_index;
			if (g_jpg_file_time > g_wav_file_time) {
            	g_file_index = max_temp;
			} else {
            	g_file_index = g_wav_index;
        	}                        
		}
	} else {
	    if (g_avi_index > g_jpeg_index) {
	        max_temp = g_avi_index;
		} else {
	        max_temp = g_jpeg_index;
	    }

	    if (max_temp > g_wav_index) {
	        g_file_index = max_temp;
		}else{
			g_file_index = g_wav_index;
		}
	}
}



INT16U get_deleted_file_number(INT8U flag)
{
	INT16U i;
	INT16U deleted_file_number = 0;

	if(flag == 0) { //DCIMA
		for(i=0; i<g_play_index+1; i++)
		{
	        if(((avi_file_table[i>>4] & (1<<(i&0xF))) == 0) && 
	          ((jpg_file_table[i>>4] & (1<<(i&0xF))) == 0) &&
	          ((wav_file_table[i>>4] & (1<<(i&0xF))) == 0)) {
				deleted_file_number++;
			}
		}
	} else { //DCIMB
		for(i=0; i<g_play_index+1; i++)
		{
	        if(((avi_file_table_b[i>>4] & (1<<(i&0xF))) == 0) && 
	          ((jpg_file_table_b[i>>4] & (1<<(i&0xF))) == 0)) {
				deleted_file_number++;
			}
		}
	}
	return deleted_file_number;
}

void ap_storage_service_format_req(void)
{
	INT32U i;
	INT16S fd;
	INT32S start_cluster_of_dcim;
	INT32S start_cluster_of_dcima;
	INT32S start_cluster_of_dcimb;

	if(drvl2_sd_sector_number_get()<=2097152) {  // Dominant  1GB card should use FAT16
		_format(MINI_DVR_STORAGE_TYPE, FAT16_Type);
	} else {
		_format(MINI_DVR_STORAGE_TYPE, FAT32_Type);
	}

	mkdir("C:\\DCIM");
	mkdir("C:\\DCIM\\DCIMA");
	mkdir("C:\\DCIM\\DCIMB");
	chdir("C:\\DCIM");

	UsrFlushBuffers(MINI_DVR_STORAGE_TYPE);
	//---------------------------------------------------------
	// Directory Cache Init

	start_sector_of_root = UsrGetRootStartSector(MINI_DVR_STORAGE_TYPE);
	fd = UsrOpenDir((CHAR *)"C:\\DCIM", O_RDONLY);
	if(fd >= 0) {
		start_cluster_of_dcim = _GetCluster(fd);
		start_sector_of_dcim = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcim);
		close(fd);
		
		fd = UsrOpenDir((CHAR *)"C:\\DCIM\\DCIMA", O_RDONLY);
		if(fd >= 0) {
			start_cluster_of_dcima = _GetCluster(fd);
			start_sector_of_dcima = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcima);
			close(fd);

			fd = UsrOpenDir((CHAR *)"C:\\DCIM\\DCIMB", O_RDONLY);
			if(fd >= 0) {
				start_cluster_of_dcimb = _GetCluster(fd);
				start_sector_of_dcimb = Clus2Phy(MINI_DVR_STORAGE_TYPE, start_cluster_of_dcimb);
				close(fd);
			}
		}
	}
	//---------------------------------------------------------

	g_play_index = -1;
	g_file_num = g_file_num_a = g_file_num_b = 0;
	for (i=0; i<AP_STG_MAX_FILE_NUMS; i++) {
		avi_file_table[i] = jpg_file_table[i] = wav_file_table[i] = 0;
		avi_file_table_b[i] = jpg_file_table_b[i] = 0;
	}

	get_file_final_avi_index();
	get_file_final_jpeg_index();
	get_file_final_wav_index();
	get_file_index();

	if(!g_avi_index_9999_exist) {
		g_oldest_avi_file_index = temp_oldest_avi_index;
		if(g_oldest_avi_file_index > 9999) g_oldest_avi_file_index = 0;
	}

	FNodeInfo[SD_SLOT_ID].audio.MaxFileNum = 0;
	msgQSend(ApQ, MSG_STORAGE_SERVICE_FORMAT_REPLY, NULL, NULL, MSG_PRI_NORMAL);
}

void FileSrvRead(P_TK_FILE_SERVICE_STRUCT para)
{
	INT32S read_cnt;
    
    if (para->rev_seek) {
    	if(para->FB_seek)
    	{
	        lseek(para->fd, -para->rev_seek, SEEK_CUR);
	        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("reverse seek- %d\r\n",para->rev_seek);
        }
        else
        {
 	        lseek(para->fd, para->rev_seek, SEEK_CUR);
	        DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("reverse seek+ %d\r\n",para->rev_seek);
       }
    }
	read_cnt = read(para->fd, para->buf_addr, para->buf_size);
	if(para->result_queue)
	{
		OSQPost(para->result_queue, (void *) read_cnt);
	}
}

