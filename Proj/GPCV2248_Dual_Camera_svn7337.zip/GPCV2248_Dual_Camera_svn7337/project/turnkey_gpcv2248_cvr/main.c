#include "main.h"

extern volatile void *NorWakeupVector;
extern volatile void *Wakeup;

#define PERIPHERAL_HANDLING_STACK_SIZE		256
#define STATE_HANDLING_STACK_SIZE			1024
#define DISPLAY_TASK_STACK_SIZE				1024
#define STORAGE_SERVICE_TASK_STACK_SIZE		512
#define USB_TASK_STACK_SIZE					512
#define IDLE_TASK_STACK_SIZE				32
#define C_AUDIO_TASK_STACK_SIZE				1024
#define C_AUDIO_DAC_TASK_STACK_SIZE			256
#define C_FILESRV_TASK_STACK_SIZE	        512

INT32U PeripheralHandlingStack[PERIPHERAL_HANDLING_STACK_SIZE];
INT32U StateHandlingStack[STATE_HANDLING_STACK_SIZE];
INT32U DisplayTaskStack[DISPLAY_TASK_STACK_SIZE];
INT32U AudioTaskStack[C_AUDIO_TASK_STACK_SIZE];
INT32U AudioDacTaskStack[C_AUDIO_DAC_TASK_STACK_SIZE];
INT32U Filesrv[C_FILESRV_TASK_STACK_SIZE];
INT32U StorageServiceTaskStack[STORAGE_SERVICE_TASK_STACK_SIZE];
INT32U USBTaskStack[USB_TASK_STACK_SIZE];
INT32U IdleTaskStack[IDLE_TASK_STACK_SIZE];


#define RECORD_TEST_ENABLE    0

#if RECORD_TEST_ENABLE

#define RECORD_TEST_TASK_PRIORITY    1

#define RECORD_TEST_TASK_STACK_SIZE		256
static INT32U RecordTestTaskStack[RECORD_TEST_TASK_STACK_SIZE];

static void record_test_task_create(void);
static void record_test_task_entry(void *para);

#endif



void idle_task_entry(void *para)
{
	OS_CPU_SR cpu_sr;
	INT16U i;
	while (1) {
OS_ENTER_CRITICAL();
		i=0x5005;
		R_SYSTEM_WAIT = i;
		i = R_CACHE_CTRL;

		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
		ASM(NOP);
OS_EXIT_CRITICAL();	    
	}
}


#if 0
static int checksum(void)
{
	char *p_src = (char *)0;
	char *p_dst = (char *)0x30000200;
	unsigned int size = (700*1024);
	unsigned int sum1 = 0;
	unsigned int sum2 = 0;
	unsigned int ret = 0;
	unsigned int i;

	// Boot Procedure will copy data from SPI area to SDRAM area.
	// This function want to make sure SDRAM data is correct.
	for (i=0;i<size;++i)
	{
		sum1 += (unsigned int)p_src[i];
		sum2 += (unsigned int)p_dst[i];
	}
	
	if (sum1!=sum2)
		ret = 1;
	return ret;
}
#endif


INT8U PowerOn_Low_Check=0;
extern INT8U Check_PowerOn_Battery_Value(void);

void Main(void *free_memory)
{
	INT32U free_memory_start, free_memory_end;
	//INT32U chksum_flag = checksum();

	// Touch those sections so that they won't be removed by linker
	if (!NorWakeupVector && !Wakeup) {
		*((INT32U *) free_memory+1) = 0x0;
	}

	free_memory_start = ((INT32U) free_memory + 3) & (~0x3);	// Align to 4-bytes boundry
	free_memory_end = (INT32U) SDRAM_END_ADDR & ~(0x3);

	// Initiate Operating System
	OSInit();
 
	// Initiate drvier layer 1 modules
	setting_by_iRAM();
    drv_l1_init();
    
    #if POWERON_BATTERY_CHECK ==1
    PowerOn_Low_Check =Check_PowerOn_Battery_Value();
    #endif
    
	timer_freq_setup(TIMER_A, OS_TICKS_PER_SEC, 0, OSTimeTick);

	// Initiate driver layer 2 modules
	drv_l2_init();

	// Initiate gplib layer modules
	gplib_init(free_memory_start, free_memory_end);
	
	// Initiate applications here
	OSTaskCreate(task_peripheral_handling_entry, (void *) 0, &PeripheralHandlingStack[PERIPHERAL_HANDLING_STACK_SIZE - 1], PERIPHERAL_HANDLING_PRIORITY);
	OSTaskCreate(state_handling_entry, (void *) 0, &StateHandlingStack[STATE_HANDLING_STACK_SIZE - 1], STATE_HANDLING_PRIORITY);
	OSTaskCreate(task_display_entry, (void *) 0, &DisplayTaskStack[DISPLAY_TASK_STACK_SIZE - 1], DISPLAY_TASK_PRIORITY);
	OSTaskCreate(task_storage_service_entry, (void *) 0, &StorageServiceTaskStack[STORAGE_SERVICE_TASK_STACK_SIZE - 1], STORAGE_SERVICE_PRIORITY);
	OSTaskCreate(state_usb_entry, (void *) 0, &USBTaskStack[USB_TASK_STACK_SIZE - 1], USB_DEVICE_PRIORITY);

	OSTaskCreate(audio_dac_task_entry, (void *) 0, &AudioDacTaskStack[C_AUDIO_DAC_TASK_STACK_SIZE - 1], DAC_PRIORITY);
	OSTaskCreate(audio_task_entry, (void *) 0, &AudioTaskStack[C_AUDIO_TASK_STACK_SIZE - 1], AUD_DEC_PRIORITY);
	OSTaskCreate(filesrv_task_entry,(void *) 0, &Filesrv[C_FILESRV_TASK_STACK_SIZE - 1], TSK_PRI_FILE_SRV);
/*
#if SUPPORT_JTAG == CUSTOM_OFF
	OSTaskCreate(idle_task_entry, (void *) 0, &IdleTaskStack[IDLE_TASK_STACK_SIZE - 1], (OS_LOWEST_PRIO - 2));
#endif
*/

#if RECORD_TEST_ENABLE
	record_test_task_create();
#endif

	DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("CPU: %d MHz\r\n", INIT_MHZ);
    DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("SDRAM: %d MB\r\n", SDRAM_SIZE>>20);	
    
	OSStart();
}



#if RECORD_TEST_ENABLE

#include "ap_state_config.h"

void record_test_task_create(void)
{
	OSTaskCreate(record_test_task_entry, (void *) 0, &RecordTestTaskStack[RECORD_TEST_TASK_STACK_SIZE - 1], RECORD_TEST_TASK_PRIORITY);
}


extern INT8U ap_video_record_sts_get(void);
#define VIDEO_RECORD_UNMOUNT	0x1
#define VIDEO_RECORD_BUSY		0x2

void record_test_task_entry(void *para)
{
	INT8U data = 0;
	INT32U i;

	OSTimeDly(OS_TICKS_PER_SEC * 10);
	if(ap_video_record_sts_get() & VIDEO_RECORD_BUSY) {
		msgQSend(ApQ, MSG_APQ_FUNCTION_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL); //stop recording
		OSTimeDly(OS_TICKS_PER_SEC * 5);
	}

	while(1) {
		if (ap_video_record_sts_get() & VIDEO_RECORD_UNMOUNT) {
			OSTimeDly(OS_TICKS_PER_SEC * 10);
		} else {
			break;
		}
	}
	
	ap_peripheral_auto_off_force_disable_set(1);  //disable auto off function

	//enter setting mode to format SD card
	msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);

	msgQSend(ApQ, MSG_APQ_PREV_KEY_ACTIVE, &data, sizeof(INT8U), MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_PREV_KEY_ACTIVE, &data, sizeof(INT8U), MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_PREV_KEY_ACTIVE, &data, sizeof(INT8U), MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_PREV_KEY_ACTIVE, &data, sizeof(INT8U), MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	
	msgQSend(ApQ, MSG_APQ_FUNCTION_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_PREV_KEY_ACTIVE, &data, sizeof(INT8U), MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 1);
	msgQSend(ApQ, MSG_APQ_FUNCTION_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
	OSTimeDly(OS_TICKS_PER_SEC * 10);										//wait for formatting finished

	msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);		//exit setting mode
	OSTimeDly(OS_TICKS_PER_SEC * 1);

	ap_peripheral_auto_off_force_disable_set(1);  //disable auto off function
	while(1) {
		INT8U resolution, duration, test_time;

		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("\r\n");
		switch ((*((volatile INT32U *) 0xD0500380)) & 0x7) {
		case 0:
			resolution = 0;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("1080FHD  ");
			break;

		case 1:
			resolution = 1;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("1080P  ");
			break;

		case 2:
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("720P  ");
			break;

		case 3:
			resolution = 3;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("WVGA  ");
			break;

		case 4:
			resolution = 4;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("VGA  ");
			break;

		default:
			resolution = 2;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("720P  ");
			break;
		}


		switch ((*((volatile INT32U *) 0xD0500380)) & 0x7) {
		case 0:
			duration = 4;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("5min\r\n");
			break;

		case 1:
			duration = 1;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("1min\r\n");
			break;

		case 2:
			duration = 2;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("2min\r\n");
			break;

		case 3:
			duration = 3;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("3min\r\n");
			break;

		default:
			duration = 4;
			DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("5min\r\n");
			break;
		}

		//test_time = ((*((volatile INT32U *) 0xD0500380)) & 0x3) * 30 + 30;
		test_time = 10;
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("keep recording %ds\r\n", test_time);
		DBG_PRINT("FILE:%s\r\nLINE:%d\r\n\t",__FILE__,__LINE__);DBG_PRINT("\r\n");

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		ap_state_config_video_resolution_set(resolution);  //1080FHD, 1080P, 720P, WVGA, VGA, QVGA
		ap_state_config_record_time_set(duration);  //off , 1min, 2min, 3min, 5min, 10min

		//update display
		msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
		OSTimeDly(OS_TICKS_PER_SEC * 1);
		msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
		OSTimeDly(OS_TICKS_PER_SEC * 1);
		msgQSend(ApQ, MSG_APQ_MENU_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL);
		OSTimeDly(OS_TICKS_PER_SEC * 1);

		msgQSend(ApQ, MSG_APQ_FUNCTION_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL); //start recording

		for(i=0; i<(test_time/10); i++) { // 1 hour
			OSTimeDly(OS_TICKS_PER_SEC * 10);
		}
		msgQSend(ApQ, MSG_APQ_FUNCTION_KEY_ACTIVE, NULL, NULL, MSG_PRI_NORMAL); //stop recording
		OSTimeDly(OS_TICKS_PER_SEC * 5);
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	}
}

#endif


