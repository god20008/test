#include "bsp.h"

void CPU_TS_TmrInit()
{
}

void CPU_TS_TmrRd()
{
}
