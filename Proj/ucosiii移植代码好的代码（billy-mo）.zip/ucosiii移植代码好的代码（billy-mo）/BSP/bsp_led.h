#ifndef BSP_LED_H__
#define BSP_LED_H__

#include "stm32f10x.h"

void bsp_led_init(void);
void led_flick(void);
void led_flick5(void);

#endif
