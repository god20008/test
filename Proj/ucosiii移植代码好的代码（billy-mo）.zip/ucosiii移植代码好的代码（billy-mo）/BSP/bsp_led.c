#include "bsp_led.h"

void bsp_led_init(void)
{
	GPIO_InitTypeDef led_gpio;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	
	led_gpio.GPIO_Mode = GPIO_Mode_Out_PP;
	led_gpio.GPIO_Pin = GPIO_Pin_6;
	led_gpio.GPIO_Speed= GPIO_Speed_10MHz;
	
	GPIO_Init(GPIOE,&led_gpio);
	
	led_gpio.GPIO_Mode = GPIO_Mode_Out_PP;
	led_gpio.GPIO_Pin = GPIO_Pin_5;
	led_gpio.GPIO_Speed= GPIO_Speed_10MHz;
	
	GPIO_Init(GPIOE,&led_gpio);
	
}
//



//make the led connected to PE6 flick
void led_flick(void)
{
	static u8 led_state = 0;
	
	if(led_state)
	{
		led_state = 0;
		GPIO_SetBits(GPIOE,GPIO_Pin_6);
	}
	else
	{
		led_state = 1;
		GPIO_ResetBits(GPIOE,GPIO_Pin_6);
	}
}


void led_flick5(void)
{
	static u8 led_state = 0;
	
	if(led_state)
	{
		led_state = 0;
		GPIO_SetBits(GPIOE,GPIO_Pin_5);
	}
	else
	{
		led_state = 1;
		GPIO_ResetBits(GPIOE,GPIO_Pin_5);
	}
}
