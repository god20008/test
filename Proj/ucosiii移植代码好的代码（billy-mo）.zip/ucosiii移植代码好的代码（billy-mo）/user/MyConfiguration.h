

#ifndef __MyConfiguration_H
#define __MyConfiguration_H

#include  <stm32f10x.h>

void NVIC_Configuration(u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority,u8 NVIC_Channel);
#endif
