#include "includes.h"
#include "MyConfiguration.h"

static  OS_TCB	TaskStartTCB;
static	CPU_STK	TaskStartStk[128];
static void  TaskStart(void* p_arg);

static  OS_TCB	TaskLedTCB;
static	CPU_STK	TaskLedStk[128];
static void  TaskLed(void* p_arg);

//Ϊ��˵����ô���ź�����������ʱ�� �ö�ʱ����ʱ�����ź������Ƶ���˸��
//��Ϣ��������ѧϰ����������Ӧ�û�������˵���ã��������ݡ�
OS_SEM led_sem;
OS_TMR flick_time;

void flick_time_callback(void *p_tmr, void *p_arg)
{
	OS_ERR err;
	
	OSSemPost(&led_sem,OS_OPT_PEND_BLOCKING,&err);
}

void SysTick_Configuration(void);

int main()
{
	OS_ERR err;
  SystemInit();
	SysTick_Configuration();
	bsp_led_init();
	OSInit(&err);
	OSTaskCreate((OS_TCB     *)&TaskStartTCB,               
                 (CPU_CHAR   *)"Start Task",
                 (OS_TASK_PTR )TaskStart, 
                 (void       *)0,
                 (OS_PRIO     )2,
                 (CPU_STK    *)&TaskStartStk[0],
                 (CPU_STK_SIZE)12,
                 (CPU_STK_SIZE)128,
                 (OS_MSG_QTY  )0,
                 (OS_TICK     )0,
                 (void       *)0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
	
    OSStart(&err);           
}

static	void  TaskStart(void *p_arg)
{
	OS_ERR err;
	
	OSTaskCreate((OS_TCB     *)&TaskLedTCB,               
                 (CPU_CHAR   *)"Task_Led",
                 (OS_TASK_PTR )TaskLed, 
                 (void       *)0,
                 (OS_PRIO     )2,
                 (CPU_STK    *)&TaskLedStk[0],
                 (CPU_STK_SIZE)12,
                 (CPU_STK_SIZE)128,
                 (OS_MSG_QTY  )0,
                 (OS_TICK     )0,
                 (void       *)0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
	
	OSSemCreate(&led_sem,"led_flick",(OS_SEM_CTR)1,&err);						 
	OSTmrCreate(&flick_time,(void *)0,10,2,OS_OPT_TMR_PERIODIC,flick_time_callback,(void *)0,&err);
	OSTmrStart(&flick_time,&err);
								 
	while(1)
	{
		 led_flick();//system working led flick
	   OSTimeDly(500,OS_OPT_TIME_DLY,&err);
	}
}


static	void  TaskLed(void *p_arg)
{
	OS_ERR err;

	while(1)
	{
		OSSemPend(&led_sem,0,OS_OPT_PEND_BLOCKING,(CPU_TS*)0,&err);
		led_flick5();
	}
}
//ϵͳʱ���жϷ�����
void SysTick_Handler(void)
{
		OSIntEnter();				 /* Tell uC/OS-II that we are enter the ISR  */
    OSTimeTick();        /* Call uC/OS-II's OSTimeTick()               */
    OSIntExit();         /* Tell uC/OS-II that we are leaving the ISR  */
}
//ϵͳʱ�����ã����1ms����һ���ж�
void SysTick_Configuration(void)
{
 	SysTick->CTRL&=~(1<<2);//SYSTICKʹ���ⲿʱ��Դ
	SysTick->CTRL|=1<<1;   //����SYSTICK�ж�
	SysTick->LOAD=9000;    //����1ms�ж�
	SysTick->CTRL|=1<<0;   //����SYSTICK
}

